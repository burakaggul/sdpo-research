"""The three SDPO proposal mechanisms, separated from objective evaluation."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray

from .archive import underrepresented_anchor
from .boundary import reflect

FloatArray = NDArray[np.float64]


@dataclass(frozen=True)
class RefoldProposal:
    """A refolding proposal and its subspace diagnostic."""

    candidate: FloatArray
    explained_variance: float
    used_fallback: bool


def elite_centroid(population: FloatArray, values: FloatArray, fraction: float) -> FloatArray:
    """Return inverse-rank weighted centroid of the best ceil(fraction*N) candidates."""
    if not 0.0 < fraction <= 1.0:
        raise ValueError("elite fraction must be in (0,1]")
    count = max(1, int(np.ceil(fraction * population.shape[0])))
    elite = population[np.argsort(values, kind="stable")[:count]]
    weights = 1.0 / np.arange(1.0, count + 1.0)
    weights /= weights.sum()
    return weights @ elite


def chaperone_refold(
    parent: FloatArray,
    population: FloatArray,
    values: FloatArray,
    step_matrix: FloatArray,
    lower: FloatArray,
    upper: FloatArray,
    rng: np.random.Generator,
    *,
    low_rank: int,
    archive_min_steps: int,
    elite_fraction: float,
    attraction: float,
    scale: float,
    isotropic_epsilon: float,
) -> RefoldProposal:
    """Generate a guided low-rank successful-step proposal.

    When fewer than ``archive_min_steps`` exist, the subspace term is replaced by
    range-scaled isotropic Gaussian noise. No covariance state or evolution path is
    maintained, so this is not a CMA-ES update.
    """
    dimension = parent.size
    centroid = elite_centroid(population, values, elite_fraction)
    used_fallback = step_matrix.size == 0 or step_matrix.shape[1] < archive_min_steps
    explained = 0.0
    if used_fallback:
        subspace_step = (upper - lower) * rng.normal(size=dimension)
    else:
        u, singular, _ = np.linalg.svd(step_matrix, full_matrices=False)
        rank = min(low_rank, singular.size, dimension)
        if rank == 0 or float(np.sum(singular**2)) <= 0.0:
            subspace_step = (upper - lower) * rng.normal(size=dimension)
            used_fallback = True
        else:
            explained = float(np.sum(singular[:rank] ** 2) / np.sum(singular**2))
            xi = rng.normal(size=rank)
            subspace_step = u[:, :rank] @ (np.sqrt(singular[:rank]) * xi)
    isotropic = isotropic_epsilon * (upper - lower) * rng.normal(size=dimension)
    proposal = parent + attraction * (centroid - parent) + scale * (subspace_step + isotropic)
    return RefoldProposal(reflect(proposal, lower, upper), explained, used_fallback)


def annealing_proposals(
    parent: FloatArray,
    population: FloatArray,
    stress: float,
    count: int,
    lower: FloatArray,
    upper: FloatArray,
    rng: np.random.Generator,
    *,
    differential_scale: float,
    annealing_scale: float,
    student_t_df: float,
) -> FloatArray:
    """Generate the requested best-of-K differential/heavy-tailed proposals."""
    if count <= 0 or population.shape[0] < 2:
        raise ValueError("annealing requires a positive count and at least two population members")
    if student_t_df <= 0.0:
        raise ValueError("Student-t degrees of freedom must be positive")
    result = np.empty((count, parent.size), dtype=np.float64)
    f_scale = differential_scale * (0.5 + stress)
    tau = annealing_scale * (upper - lower) * (0.25 + 4.0 * stress * (1.0 - stress))
    for row in range(count):
        r1, r2 = rng.choice(population.shape[0], size=2, replace=False)
        heavy_tail = rng.standard_t(df=student_t_df, size=parent.size)
        result[row] = reflect(
            parent + f_scale * (population[r1] - population[r2]) + tau * heavy_tail, lower, upper
        )
    return result


def degradation_replacement(
    archive_points: FloatArray,
    lower: FloatArray,
    upper: FloatArray,
    rng: np.random.Generator,
    uniform_weight: float,
) -> FloatArray:
    """Sample from an underrepresented-anchor Gaussian/uniform mixture."""
    if not 0.0 < uniform_weight <= 1.0:
        raise ValueError("uniform restart weight must be in (0,1]")
    if rng.random() < uniform_weight:
        return rng.uniform(lower, upper)
    anchor = underrepresented_anchor(archive_points, rng)
    diagonal_scale = 0.1 * (upper - lower)
    return reflect(anchor + diagonal_scale * rng.normal(size=lower.size), lower, upper)
