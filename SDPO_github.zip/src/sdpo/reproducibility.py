"""Runtime and source metadata collection for traceable experiments."""

from __future__ import annotations

import importlib.metadata
import os
import platform
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def git_commit(project_root: Path) -> str | None:
    """Return the current commit hash, or None for an uncommitted new repository."""
    process = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=project_root, capture_output=True, text=True, check=False
    )
    return process.stdout.strip() if process.returncode == 0 else None


def runtime_metadata(project_root: Path) -> dict[str, Any]:
    """Collect required runtime metadata without changing external state."""
    packages: dict[str, str] = {}
    for name in (
        "numpy",
        "scipy",
        "pandas",
        "scikit-learn",
        "matplotlib",
        "PyYAML",
        "pytest",
        "ruff",
        "cma",
        "coco-experiment",
    ):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = "not-installed"
    return {
        "timestamp_utc": datetime.now(UTC).isoformat(),
        "git_commit": git_commit(project_root),
        "python_version": sys.version,
        "python_executable": sys.executable,
        "operating_system": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "logical_processors": os.cpu_count(),
        "packages": packages,
    }
