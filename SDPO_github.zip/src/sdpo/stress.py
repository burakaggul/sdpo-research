"""Bounded quality, stagnation, and crowding stress components."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from .neighbors import NeighborGraph, build_neighbor_graph

FloatArray = NDArray[np.float64]


def quality_stress(values: FloatArray) -> FloatArray:
    """Return stable ordinal rank stress in [0, 1]; ties preserve population order.

    Stable ordinal ranking is explicit: equally valued candidates receive consecutive
    ranks in original index order. This preserves the exact formula (rank-1)/(N-1),
    but introduces an index-order tie break that is reported in the mathematical audit.
    """
    f = np.asarray(values, dtype=np.float64)
    if f.ndim != 1 or f.size < 2 or not np.all(np.isfinite(f)):
        raise ValueError("quality stress requires at least two finite objective values")
    order = np.argsort(f, kind="stable")
    ranks = np.empty(f.size, dtype=np.float64)
    ranks[order] = np.arange(f.size, dtype=np.float64)
    return ranks / float(f.size - 1)


def stagnation_stress(counters: NDArray[np.integer], scale: int) -> FloatArray:
    """Map nonnegative stagnation counters to [0, 1]."""
    c = np.asarray(counters)
    if scale <= 0:
        raise ValueError("stagnation scale must be positive")
    if c.ndim != 1 or np.any(c < 0):
        raise ValueError("stagnation counters must be a nonnegative one-dimensional array")
    return np.minimum(1.0, c.astype(np.float64) / float(scale))


def normalized_distances(
    population: FloatArray, lower: FloatArray, upper: FloatArray
) -> FloatArray:
    """Compute the dense pairwise distance matrix used to identify sparse k-NN edges."""
    x = np.asarray(population, dtype=np.float64)
    if x.ndim != 2 or x.shape[1] != lower.size:
        raise ValueError("population must have shape (n_candidates, dimension)")
    scaled = (x - lower) / (upper - lower)
    delta = scaled[:, None, :] - scaled[None, :, :]
    return np.linalg.norm(delta, axis=2)


def crowding_stress(
    population: FloatArray,
    lower: FloatArray,
    upper: FloatArray,
    k: int,
    epsilon: float = 1e-12,
) -> FloatArray:
    """Compute crowding stress in (0, 1] from mean normalized k-NN distance."""
    neighbors = build_neighbor_graph(population, lower, upper, k, backend="brute")
    return crowding_from_neighbors(neighbors, epsilon)


def crowding_from_neighbors(neighbors: NeighborGraph, epsilon: float = 1e-12) -> FloatArray:
    """Compute bounded crowding from an already constructed neighbor list."""
    mean_distance = np.mean(neighbors.distances, axis=1)
    median_distance = float(np.median(mean_distance))
    result = 1.0 / (1.0 + mean_distance / (median_distance + epsilon))
    return np.clip(result, np.finfo(np.float64).tiny, 1.0)


def raw_stress(
    rank: FloatArray,
    stagnation: FloatArray,
    crowding: FloatArray,
    weights: tuple[float, float, float],
) -> FloatArray:
    """Form the convex weighted raw stress state."""
    w = np.asarray(weights, dtype=np.float64)
    if w.shape != (3,) or np.any(w < 0.0) or not np.isclose(np.sum(w), 1.0, atol=1e-12):
        raise ValueError("stress weights must be three nonnegative values summing to one")
    if rank.shape != stagnation.shape or rank.shape != crowding.shape:
        raise ValueError("stress components must have identical shapes")
    q = w[0] * rank + w[1] * stagnation + w[2] * crowding
    return np.clip(q, 0.0, 1.0)


def is_improvement(old: float, new: float, epsilon_abs: float, epsilon_rel: float) -> bool:
    """Apply the specified absolute-relative strict improvement test."""
    return bool(old - new > epsilon_abs + epsilon_rel * abs(old))
