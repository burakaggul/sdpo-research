"""Leakage-safe preprocessing namespace; implementation awaits verified raw schemas."""


def pending_schema_error(dataset: str) -> None:
    raise RuntimeError(
        f"preprocessing for {dataset} is gated until downloaded files and their schema are audited"
    )
