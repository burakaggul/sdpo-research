"""Configurable deterministic neighborhood construction for population graphs."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np
from numpy.typing import NDArray
from scipy.spatial import cKDTree, distance

FloatArray = NDArray[np.float64]
IntArray = NDArray[np.int64]
NeighborBackend = Literal["brute", "ckdtree", "sklearn"]


@dataclass(frozen=True)
class NeighborGraph:
    """Exactly k outgoing neighbors and their normalized Euclidean distances."""

    indices: IntArray
    distances: FloatArray
    backend: str
    approximate_epsilon: float

    @property
    def n_candidates(self) -> int:
        return self.indices.shape[0]

    @property
    def k(self) -> int:
        return self.indices.shape[1]

    @property
    def storage_bytes(self) -> int:
        return self.indices.nbytes + self.distances.nbytes


def _validate(population: FloatArray, lower: FloatArray, upper: FloatArray, k: int) -> FloatArray:
    x = np.asarray(population, dtype=np.float64)
    if x.ndim != 2 or lower.ndim != 1 or upper.shape != lower.shape:
        raise ValueError("population and one-dimensional bounds have incompatible shapes")
    if x.shape[1] != lower.size or not 1 <= k < x.shape[0]:
        raise ValueError("require population shape (N,d) and 1 <= k < N")
    if np.any(upper <= lower) or not np.all(np.isfinite(x)):
        raise ValueError("bounds must have positive widths and population must be finite")
    return (x - lower) / (upper - lower)


def _canonicalize_row(
    candidate_indices: IntArray,
    candidate_distances: FloatArray,
    self_index: int,
    k: int,
) -> tuple[IntArray, FloatArray]:
    keep = candidate_indices != self_index
    indices = np.asarray(candidate_indices[keep], dtype=np.int64)
    distances_row = np.asarray(candidate_distances[keep], dtype=np.float64)
    if indices.size < k:
        raise RuntimeError("neighbor backend did not return enough non-self candidates")
    order = np.lexsort((indices, distances_row))[:k]
    return indices[order], distances_row[order]


def _canonicalize_all(
    raw_indices: IntArray, raw_distances: FloatArray, k: int
) -> tuple[IntArray, FloatArray]:
    n = raw_indices.shape[0]
    result_indices = np.empty((n, k), dtype=np.int64)
    result_distances = np.empty((n, k), dtype=np.float64)
    for row in range(n):
        indices, distances_row = _canonicalize_row(raw_indices[row], raw_distances[row], row, k)
        result_indices[row] = indices
        result_distances[row] = distances_row
    return result_indices, result_distances


def _brute_neighbors(scaled: FloatArray, k: int, chunk_size: int) -> tuple[IntArray, FloatArray]:
    """Exact chunked brute force: O(N^2 d) time and O(chunk*N + Nk) memory."""
    if chunk_size <= 0:
        raise ValueError("brute-force chunk size must be positive")
    n = scaled.shape[0]
    all_indices = np.arange(n, dtype=np.int64)
    result_indices = np.empty((n, k), dtype=np.int64)
    result_distances = np.empty((n, k), dtype=np.float64)
    for start in range(0, n, chunk_size):
        stop = min(start + chunk_size, n)
        block = distance.cdist(scaled[start:stop], scaled, metric="euclidean")
        for local, row_index in enumerate(range(start, stop)):
            row = block[local]
            row[row_index] = np.inf
            threshold = float(np.partition(row, k - 1)[k - 1])
            candidates = all_indices[row <= threshold]
            candidate_distances = row[candidates]
            indices, distances_row = _canonicalize_row(
                candidates, candidate_distances, row_index, k
            )
            result_indices[row_index] = indices
            result_distances[row_index] = distances_row
    return result_indices, result_distances


def _tree_neighbors(
    scaled: FloatArray, k: int, approximate_epsilon: float
) -> tuple[IntArray, FloatArray]:
    if approximate_epsilon < 0.0:
        raise ValueError("cKDTree approximation epsilon must be nonnegative")
    tree = cKDTree(scaled, compact_nodes=True, balanced_tree=True)
    raw_distances, raw_indices = tree.query(scaled, k=k + 1, eps=approximate_epsilon, workers=1)
    return _canonicalize_all(raw_indices, raw_distances, k)


def _sklearn_neighbors(scaled: FloatArray, k: int, algorithm: str) -> tuple[IntArray, FloatArray]:
    try:
        from sklearn.neighbors import NearestNeighbors
    except ImportError as error:  # pragma: no cover
        raise RuntimeError("the sklearn backend requires scikit-learn") from error
    if algorithm not in {"auto", "brute", "kd_tree", "ball_tree"}:
        raise ValueError("sklearn algorithm must be auto, brute, kd_tree, or ball_tree")
    model = NearestNeighbors(n_neighbors=k + 1, algorithm=algorithm, metric="euclidean", n_jobs=1)
    raw_distances, raw_indices = model.fit(scaled).kneighbors(scaled, return_distance=True)
    return _canonicalize_all(raw_indices, raw_distances, k)


def build_neighbor_graph(
    population: FloatArray,
    lower: FloatArray,
    upper: FloatArray,
    k: int,
    *,
    backend: NeighborBackend = "ckdtree",
    sklearn_algorithm: str = "auto",
    approximate_epsilon: float = 0.0,
    brute_chunk_size: int = 256,
) -> NeighborGraph:
    """Build a reproducible neighbor list using the requested backend.

    ``ckdtree`` is exact when ``approximate_epsilon=0``. Tree query complexity has no
    dimension-independent subquadratic guarantee; high-dimensional behavior can approach
    brute force. Approximation is opt-in and is not used for reported exact experiments.
    """
    scaled = _validate(population, lower, upper, k)
    if backend == "brute":
        indices, distances_result = _brute_neighbors(scaled, k, brute_chunk_size)
    elif backend == "ckdtree":
        indices, distances_result = _tree_neighbors(scaled, k, approximate_epsilon)
    elif backend == "sklearn":
        if approximate_epsilon != 0.0:
            raise ValueError("approximation epsilon is supported only by cKDTree")
        indices, distances_result = _sklearn_neighbors(scaled, k, sklearn_algorithm)
    else:
        raise ValueError(f"unknown neighbor backend: {backend}")
    return NeighborGraph(indices, distances_result, backend, approximate_epsilon)
