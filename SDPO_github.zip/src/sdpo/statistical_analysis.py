"""Preregistered nonparametric procedures for the confirmatory BBOB study."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import stats


@dataclass(frozen=True)
class AlignedFriedmanResult:
    """Result and audit intermediates for Friedman's aligned-ranks test."""

    statistic: float
    p_value: float
    degrees_of_freedom: int
    aligned_rank_sums_by_treatment: np.ndarray
    aligned_rank_sums_by_block: np.ndarray


@dataclass(frozen=True)
class PairedWilcoxonResult:
    """Paired Wilcoxon result for differences defined as first minus second."""

    statistic: float
    p_value: float
    rank_biserial: float
    positive_rank_sum: float
    negative_rank_sum: float
    nonzero_pairs: int


def aligned_friedman(data: np.ndarray) -> AlignedFriedmanResult:
    """Compute the Garcia et al. Friedman aligned-ranks omnibus test.

    Rows are paired blocks and columns are treatments. Average ranks are used
    for ties. The asymptotic reference distribution is chi-square with k-1 df.
    """
    values = np.asarray(data, dtype=float)
    if values.ndim != 2:
        raise ValueError("data must be a two-dimensional block-by-treatment matrix")
    n, k = values.shape
    if n < 2 or k < 2:
        raise ValueError("aligned Friedman requires at least two blocks and treatments")
    if not np.all(np.isfinite(values)):
        raise ValueError("data must contain only finite values")

    aligned = values - values.mean(axis=1, keepdims=True)
    ranks = stats.rankdata(aligned.ravel(), method="average").reshape(n, k)
    treatment_sums = ranks.sum(axis=0)
    block_sums = ranks.sum(axis=1)

    nk = n * k
    numerator = (k - 1) * (np.square(treatment_sums).sum() - (k * n**2 / 4.0) * (nk + 1) ** 2)
    denominator = nk * (nk + 1) * (2 * nk + 1) / 6.0 - np.square(block_sums).sum() / k
    if np.isclose(denominator, 0.0):
        statistic = 0.0
        p_value = 1.0
    else:
        statistic = float(max(0.0, numerator / denominator))
        p_value = float(stats.chi2.sf(statistic, k - 1))
    return AlignedFriedmanResult(
        statistic=statistic,
        p_value=p_value,
        degrees_of_freedom=k - 1,
        aligned_rank_sums_by_treatment=treatment_sums,
        aligned_rank_sums_by_block=block_sums,
    )


def holm_adjust(p_values: np.ndarray) -> np.ndarray:
    """Return Holm family-wise-error adjusted p-values in original order."""
    values = np.asarray(p_values, dtype=float)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("p_values must be a non-empty one-dimensional array")
    if not np.all(np.isfinite(values)) or np.any((values < 0) | (values > 1)):
        raise ValueError("p-values must be finite and lie in [0, 1]")

    order = np.argsort(values, kind="stable")
    sorted_values = values[order]
    scaled = (values.size - np.arange(values.size)) * sorted_values
    adjusted_sorted = np.minimum(1.0, np.maximum.accumulate(scaled))
    adjusted = np.empty_like(adjusted_sorted)
    adjusted[order] = adjusted_sorted
    return adjusted


def paired_wilcoxon(differences: np.ndarray) -> PairedWilcoxonResult:
    """Run a two-sided paired Wilcoxon test and matched-pairs rank-biserial effect.

    Exact zeros are discarded (Wilcox convention). A positive effect means that
    positive first-minus-second differences carry more absolute-rank mass.
    """
    values = np.asarray(differences, dtype=float)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("differences must be a non-empty one-dimensional array")
    if not np.all(np.isfinite(values)):
        raise ValueError("differences must contain only finite values")

    nonzero = values[values != 0.0]
    if nonzero.size == 0:
        return PairedWilcoxonResult(0.0, 1.0, 0.0, 0.0, 0.0, 0)

    ranks = stats.rankdata(np.abs(nonzero), method="average")
    positive = float(ranks[nonzero > 0].sum())
    negative = float(ranks[nonzero < 0].sum())
    rank_biserial = (positive - negative) / (positive + negative)
    test = stats.wilcoxon(
        nonzero,
        zero_method="wilcox",
        alternative="two-sided",
        method="auto",
    )
    return PairedWilcoxonResult(
        statistic=float(test.statistic),
        p_value=float(test.pvalue),
        rank_biserial=float(rank_biserial),
        positive_rank_sum=positive,
        negative_rank_sum=negative,
        nonzero_pairs=int(nonzero.size),
    )
