"""Atomic, non-overwriting JSON/CSV result writers."""

from __future__ import annotations

import csv
import gzip
import io
import json
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any

import numpy as np


def _json_default(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(f"cannot serialize {type(value).__name__}")


def atomic_json(path: Path, payload: dict[str, Any], *, overwrite: bool = False) -> None:
    """Atomically write JSON, refusing silent overwrite by default."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite completed result: {path}")
    with NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, default=_json_default)
        handle.write("\n")
        temporary = Path(handle.name)
    os.replace(temporary, path)


def atomic_csv(path: Path, rows: list[dict[str, Any]], *, overwrite: bool = False) -> None:
    """Atomically write homogeneous dictionaries as CSV."""
    if not rows:
        raise ValueError("cannot write an empty CSV without an explicit schema")
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite completed result: {path}")
    with NamedTemporaryFile(
        "w", encoding="utf-8", newline="", dir=path.parent, delete=False
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
        temporary = Path(handle.name)
    os.replace(temporary, path)


def atomic_gzip_csv(path: Path, rows: list[dict[str, Any]], *, overwrite: bool = False) -> None:
    """Atomically write homogeneous dictionaries as a reproducible gzip CSV."""
    if not rows:
        raise ValueError("cannot write an empty CSV without an explicit schema")
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite completed result: {path}")
    with NamedTemporaryFile("wb", dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
    try:
        with temporary.open("wb") as binary:
            with gzip.GzipFile(filename="", mode="wb", fileobj=binary, mtime=0) as zipped:
                with io.TextIOWrapper(zipped, encoding="utf-8", newline="") as text:
                    writer = csv.DictWriter(text, fieldnames=list(rows[0]))
                    writer.writeheader()
                    writer.writerows(rows)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    os.replace(temporary, path)
