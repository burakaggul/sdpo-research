"""Benchmark integration boundary.

Only transparent development functions are currently enabled. CEC 2022 and COCO/BBOB
must be integrated from license-checked official or verified implementations.
"""

from .objectives import DEVELOPMENT_FUNCTIONS

__all__ = ["DEVELOPMENT_FUNCTIONS"]


def require_verified_suite(name: str) -> None:
    """Refuse to run an unverified approximation of a named benchmark suite."""
    raise RuntimeError(
        f"{name} is not integrated: obtain and verify the official implementation and license; "
        "no approximate functions will be substituted"
    )
