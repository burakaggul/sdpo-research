"""Evaluation-efficiency credit and stress-conditioned operator probabilities."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]
OPERATORS = ("F", "A", "D")


def operator_probabilities(
    stress: float, credits: FloatArray, eta: float, beta: float
) -> FloatArray:
    """Return stable-softmax probabilities for F, A, and D in that order."""
    if not 0.0 <= stress <= 1.0 or credits.shape != (3,):
        raise ValueError("stress must be in [0,1] and credits must have shape (3,)")
    response = np.array([1.0 - stress, 4.0 * stress * (1.0 - stress), stress])
    logits = eta * credits + beta * response
    logits -= np.max(logits)
    probabilities = np.exp(logits)
    return probabilities / np.sum(probabilities)


def normalized_gain(parent: float, child: float, evaluations: int, epsilon: float = 1e-12) -> float:
    """Return accepted improvement normalized by parent magnitude and evaluations."""
    if evaluations <= 0:
        raise ValueError("operator evaluation count must be positive")
    return max(0.0, parent - child) / (abs(parent) + epsilon) / evaluations


def update_credits(
    credits: FloatArray, gains: dict[str, list[float]], learning_rate: float
) -> FloatArray:
    """EMA-update sampled operators; retain old credit when an operator has no samples."""
    if credits.shape != (3,) or not 0.0 <= learning_rate <= 1.0:
        raise ValueError("invalid credit vector or learning rate")
    updated = credits.copy()
    for index, name in enumerate(OPERATORS):
        samples = gains.get(name, [])
        if samples:
            updated[index] = (1.0 - learning_rate) * credits[index] + learning_rate * float(
                np.median(samples)
            )
    return updated
