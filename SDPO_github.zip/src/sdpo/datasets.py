"""Dataset availability checks that never synthesize missing IEEE DataPort data."""

from pathlib import Path


def require_dataset(directory: Path) -> list[Path]:
    """Return real files or raise an actionable manual-download error."""
    files = [path for path in directory.rglob("*") if path.is_file() and path.name != ".gitkeep"]
    if not files:
        raise FileNotFoundError(
            f"no dataset files found under {directory}; follow data/README_DOWNLOAD.md"
        )
    return sorted(files)
