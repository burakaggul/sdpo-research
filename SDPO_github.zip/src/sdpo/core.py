"""Mathematically explicit, evaluation-budgeted SDPO optimization loop."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from time import perf_counter

import numpy as np
from numpy.typing import NDArray

from .archive import StepArchive
from .boundary import in_bounds
from .credit import OPERATORS, normalized_gain, operator_probabilities, update_credits
from .graph import diffuse, sparse_transition_matrix
from .neighbors import build_neighbor_graph
from .operators import annealing_proposals, chaperone_refold, degradation_replacement
from .stress import (
    crowding_from_neighbors,
    is_improvement,
    quality_stress,
    raw_stress,
    stagnation_stress,
)

FloatArray = NDArray[np.float64]
Objective = Callable[[FloatArray], float]


@dataclass(frozen=True)
class SDPOConfig:
    """Fixed configuration for a single deterministic SDPO run."""

    population_size: int = 20
    evaluation_budget: int = 1000
    seed: int = 0
    stress_weights: tuple[float, float, float] = (0.4, 0.3, 0.3)
    stagnation_scale: int = 10
    epsilon_abs: float = 1e-12
    epsilon_rel: float = 1e-10
    graph_k: int = 4
    graph_sigma: float = 0.25
    diffusion_rho: float = 0.35
    neighbor_backend: str = "ckdtree"
    neighbor_algorithm: str = "auto"
    neighbor_approximate_epsilon: float = 0.0
    brute_chunk_size: int = 256
    beta: float = 2.0
    eta: float = 1.0
    policy_adaptive_weight: float = 1.0
    credit_learning_rate: float = 0.2
    max_annealing_proposals: int = 3
    student_t_df: float = 3.0
    differential_scale: float = 0.5
    annealing_scale: float = 0.05
    low_rank: int = 3
    archive_min_steps: int = 3
    archive_max_steps: int = 100
    elite_fraction: float = 0.2
    refold_attraction: float = 0.35
    refold_scale: float = 0.15
    isotropic_epsilon: float = 0.05
    degradation_stress_threshold: float = 0.75
    degradation_stagnation_threshold: int = 12
    uniform_restart_weight: float = 0.1


@dataclass(frozen=True)
class TrajectoryPoint:
    evaluations: int
    best_objective: float


@dataclass
class SDPOResult:
    """Complete result and mechanism evidence from one run."""

    best_solution: FloatArray
    best_objective: float
    evaluations: int
    termination_reason: str
    seed: int
    elapsed_seconds: float
    trajectory: list[TrajectoryPoint]
    diagnostics: list[dict[str, object]]
    final_population: FloatArray
    final_values: FloatArray
    final_credits: FloatArray
    config: dict[str, object] = field(default_factory=dict)


class EvaluationBudget:
    """The sole gateway to objective calls, guaranteeing exact accounting."""

    def __init__(self, objective: Objective, limit: int) -> None:
        if limit <= 0:
            raise ValueError("evaluation budget must be positive")
        self.objective = objective
        self.limit = limit
        self.count = 0

    @property
    def remaining(self) -> int:
        return self.limit - self.count

    def evaluate(self, candidate: FloatArray) -> float:
        if self.remaining <= 0:
            raise RuntimeError("objective evaluation requested after budget exhaustion")
        value = float(self.objective(candidate.copy()))
        self.count += 1
        if not np.isfinite(value):
            raise FloatingPointError(
                f"objective returned non-finite value at evaluation {self.count}"
            )
        return value


def _validate(config: SDPOConfig, lower: FloatArray, upper: FloatArray) -> None:
    if lower.ndim != 1 or lower.shape != upper.shape or lower.size == 0 or np.any(upper <= lower):
        raise ValueError(
            "finite one-dimensional lower/upper bounds with lower < upper are required"
        )
    if not np.all(np.isfinite(lower)) or not np.all(np.isfinite(upper)):
        raise ValueError("bounds must be finite")
    if config.population_size < 3 or config.evaluation_budget < config.population_size:
        raise ValueError("population must be >=3 and budget must cover initialization")
    if not 1 <= config.graph_k < config.population_size:
        raise ValueError("graph_k must satisfy 1 <= graph_k < population_size")
    if config.max_annealing_proposals < 1 or config.low_rank < 1 or config.archive_min_steps < 1:
        raise ValueError("proposal count, low rank, and archive minimum must be positive")
    if not 0.0 <= config.policy_adaptive_weight <= 1.0:
        raise ValueError("policy_adaptive_weight must lie in [0,1]")


def optimize(
    objective: Objective, lower: FloatArray, upper: FloatArray, config: SDPOConfig
) -> SDPOResult:
    """Minimize a finite scalar objective under a strict function-evaluation budget.

    Degradation has a hard chronic-stress gate. If D is sampled for an ineligible
    candidate, the choice is conditionally resampled over F/A and logged as a gate
    fallback. This preserves the stated trigger while making the distinction from the
    unmasked softmax explicit.
    """
    lower = np.asarray(lower, dtype=np.float64)
    upper = np.asarray(upper, dtype=np.float64)
    _validate(config, lower, upper)
    start = perf_counter()
    rng = np.random.default_rng(config.seed)
    evaluator = EvaluationBudget(objective, config.evaluation_budget)
    population = rng.uniform(lower, upper, size=(config.population_size, lower.size))
    values = np.empty(config.population_size, dtype=np.float64)
    trajectory: list[TrajectoryPoint] = []
    best_value = np.inf
    best_solution = population[0].copy()

    def evaluate_and_trace(candidate: FloatArray) -> float:
        nonlocal best_value, best_solution
        value = evaluator.evaluate(candidate)
        if value < best_value:
            best_value = value
            best_solution = candidate.copy()
        trajectory.append(TrajectoryPoint(evaluator.count, best_value))
        return value

    for index in range(config.population_size):
        values[index] = evaluate_and_trace(population[index])

    stagnation = np.zeros(config.population_size, dtype=np.int64)
    credits = np.zeros(3, dtype=np.float64)
    step_archive = StepArchive(config.archive_max_steps)
    diversity_archive = population.copy()
    previous_stress: FloatArray | None = None
    diagnostics: list[dict[str, object]] = []
    iteration = 0

    while evaluator.remaining > 0:
        rank = quality_stress(values)
        stalled = stagnation_stress(stagnation, config.stagnation_scale)
        neighbors = build_neighbor_graph(
            population,
            lower,
            upper,
            config.graph_k,
            backend=config.neighbor_backend,
            sklearn_algorithm=config.neighbor_algorithm,
            approximate_epsilon=config.neighbor_approximate_epsilon,
            brute_chunk_size=config.brute_chunk_size,
        )
        crowding = crowding_from_neighbors(neighbors)
        q = raw_stress(rank, stalled, crowding, config.stress_weights)
        transition = sparse_transition_matrix(neighbors, config.graph_sigma)
        h = (
            q.copy()
            if previous_stress is None
            else diffuse(q, previous_stress, transition, config.diffusion_rho)
        )
        previous_stress = h.copy()
        gains: dict[str, list[float]] = {name: [] for name in OPERATORS}

        for index in range(config.population_size):
            if evaluator.remaining <= 0:
                break
            probabilities = operator_probabilities(
                float(h[index]), credits, config.eta, config.beta
            )
            probabilities = (
                config.policy_adaptive_weight * probabilities
                + (1.0 - config.policy_adaptive_weight) / 3.0
            )
            selected = int(rng.choice(3, p=probabilities))
            gate_fallback = False
            eligible_degradation = bool(
                h[index] > config.degradation_stress_threshold
                and stagnation[index] > config.degradation_stagnation_threshold
            )
            if selected == 2 and not eligible_degradation:
                conditional = probabilities[:2] / probabilities[:2].sum()
                selected = int(rng.choice(2, p=conditional))
                gate_fallback = True
            operator = OPERATORS[selected]
            parent = population[index].copy()
            parent_value = float(values[index])
            explained_variance = 0.0
            archive_fallback = False

            if operator == "F":
                proposal = chaperone_refold(
                    parent,
                    population,
                    values,
                    step_archive.matrix(),
                    lower,
                    upper,
                    rng,
                    low_rank=config.low_rank,
                    archive_min_steps=config.archive_min_steps,
                    elite_fraction=config.elite_fraction,
                    attraction=config.refold_attraction,
                    scale=config.refold_scale,
                    isotropic_epsilon=config.isotropic_epsilon,
                )
                candidate = proposal.candidate
                explained_variance = proposal.explained_variance
                archive_fallback = proposal.used_fallback
                child_value = evaluate_and_trace(candidate)
                consumed = 1
            elif operator == "A":
                desired = 1 + int(
                    np.floor(config.max_annealing_proposals * 4.0 * h[index] * (1.0 - h[index]))
                )
                consumed = min(desired, evaluator.remaining)
                proposals = annealing_proposals(
                    parent,
                    population,
                    float(h[index]),
                    consumed,
                    lower,
                    upper,
                    rng,
                    differential_scale=config.differential_scale,
                    annealing_scale=config.annealing_scale,
                    student_t_df=config.student_t_df,
                )
                proposal_values = np.array([evaluate_and_trace(row) for row in proposals])
                best_proposal = int(np.argmin(proposal_values))
                candidate = proposals[best_proposal]
                child_value = float(proposal_values[best_proposal])
            else:
                candidate = degradation_replacement(
                    diversity_archive, lower, upper, rng, config.uniform_restart_weight
                )
                child_value = evaluate_and_trace(candidate)
                consumed = 1

            accepted = child_value <= parent_value
            strict = is_improvement(
                parent_value, child_value, config.epsilon_abs, config.epsilon_rel
            )
            if accepted:
                population[index] = candidate
                values[index] = child_value
                diversity_archive = np.vstack((diversity_archive, candidate))[
                    -config.archive_max_steps :
                ]
            if strict:
                # The low-rank archive contains productive steps only; neutral greedy
                # acceptances belong in the diversity archive but not the success model.
                step_archive.add(candidate - parent)
            stagnation[index] = 0 if strict else stagnation[index] + 1
            if strict:
                gains[operator].append(normalized_gain(parent_value, child_value, consumed))
            diagnostics.append(
                {
                    "iteration": iteration,
                    "candidate": index,
                    "evaluations": evaluator.count,
                    "operator": operator,
                    "operator_evaluations": consumed,
                    "accepted": accepted,
                    "strict_improvement": strict,
                    "raw_stress": float(q[index]),
                    "diffused_stress": float(h[index]),
                    "probability_F": float(probabilities[0]),
                    "probability_A": float(probabilities[1]),
                    "probability_D": float(probabilities[2]),
                    "degradation_gate_fallback": gate_fallback,
                    "archive_fallback": archive_fallback,
                    "explained_variance": explained_variance,
                    "population_diversity": float(np.mean(np.std(population, axis=0))),
                }
            )
        credits = update_credits(credits, gains, config.credit_learning_rate)
        iteration += 1

    if not in_bounds(population, lower, upper):
        raise AssertionError("internal error: final population violates bounds")
    return SDPOResult(
        best_solution=best_solution,
        best_objective=float(best_value),
        evaluations=evaluator.count,
        termination_reason="evaluation_budget_exhausted",
        seed=config.seed,
        elapsed_seconds=perf_counter() - start,
        trajectory=trajectory,
        diagnostics=diagnostics,
        final_population=population,
        final_values=values,
        final_credits=credits,
        config=asdict(config),
    )
