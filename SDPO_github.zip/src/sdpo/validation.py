"""Reusable run-integrity assertions."""

from __future__ import annotations

import numpy as np

from .boundary import in_bounds
from .core import SDPOResult


def validate_result(result: SDPOResult, lower: np.ndarray, upper: np.ndarray, budget: int) -> None:
    """Raise when a run violates smoke-test acceptance criteria."""
    best = np.array([point.best_objective for point in result.trajectory])
    if result.evaluations != budget or len(result.trajectory) != budget:
        raise AssertionError("function-evaluation accounting is not exact")
    if not np.all(np.isfinite(best)) or np.any(np.diff(best) > 0.0):
        raise AssertionError("best-so-far trajectory is non-finite or non-monotonic")
    if not in_bounds(result.final_population, lower, upper):
        raise AssertionError("final population violates search bounds")
