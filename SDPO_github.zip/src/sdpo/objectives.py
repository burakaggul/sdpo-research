"""Transparent development objectives; these are not substitutes for CEC/BBOB."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]


def sphere(x: FloatArray) -> float:
    return float(np.sum(x**2))


def rosenbrock(x: FloatArray) -> float:
    return float(np.sum(100.0 * (x[1:] - x[:-1] ** 2) ** 2 + (1.0 - x[:-1]) ** 2))


def rastrigin(x: FloatArray) -> float:
    return float(10.0 * x.size + np.sum(x**2 - 10.0 * np.cos(2.0 * np.pi * x)))


def ackley(x: FloatArray) -> float:
    mean_square = np.mean(x**2)
    mean_cosine = np.mean(np.cos(2.0 * np.pi * x))
    return float(-20.0 * np.exp(-0.2 * np.sqrt(mean_square)) - np.exp(mean_cosine) + 20.0 + np.e)


def schwefel(x: FloatArray) -> float:
    return float(418.9828872724338 * x.size - np.sum(x * np.sin(np.sqrt(np.abs(x)))))


DEVELOPMENT_FUNCTIONS = {
    "sphere": (sphere, -5.12, 5.12),
    "rosenbrock": (rosenbrock, -5.0, 10.0),
    "rastrigin": (rastrigin, -5.12, 5.12),
    "ackley": (ackley, -32.768, 32.768),
    "schwefel": (schwefel, -500.0, 500.0),
}
