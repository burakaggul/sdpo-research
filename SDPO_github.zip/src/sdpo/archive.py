"""Bounded successful-step and diversity archives."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]


@dataclass
class StepArchive:
    """FIFO archive of accepted displacement vectors."""

    max_size: int
    steps: list[FloatArray] = field(default_factory=list)

    def add(self, step: FloatArray) -> None:
        self.steps.append(np.asarray(step, dtype=np.float64).copy())
        if len(self.steps) > self.max_size:
            del self.steps[: len(self.steps) - self.max_size]

    def matrix(self) -> FloatArray:
        """Return accepted steps as the columns prescribed by the formulation."""
        if not self.steps:
            return np.empty((0, 0), dtype=np.float64)
        return np.column_stack(self.steps)


def underrepresented_anchor(points: FloatArray, rng: np.random.Generator) -> FloatArray:
    """Select the archive point with greatest nearest-neighbor distance.

    A single-point archive has no density information, so it is returned directly.
    Exact ties are broken randomly by the explicit run generator.
    """
    x = np.asarray(points, dtype=np.float64)
    if x.ndim != 2 or x.shape[0] == 0:
        raise ValueError("diversity archive must contain at least one point")
    if x.shape[0] == 1:
        return x[0].copy()
    distances = np.linalg.norm(x[:, None, :] - x[None, :, :], axis=2)
    np.fill_diagonal(distances, np.inf)
    nearest = np.min(distances, axis=1)
    candidates = np.flatnonzero(np.isclose(nearest, np.max(nearest)))
    return x[int(rng.choice(candidates))].copy()
