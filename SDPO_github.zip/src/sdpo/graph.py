"""Sparse-neighborhood graph construction and bounded stress diffusion."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from scipy.sparse import csr_matrix, issparse, spmatrix

from .neighbors import NeighborGraph, build_neighbor_graph

FloatArray = NDArray[np.float64]


def transition_matrix(
    population: FloatArray,
    lower: FloatArray,
    upper: FloatArray,
    k: int,
    sigma: float,
) -> FloatArray:
    """Compatibility wrapper returning a dense exact-brute transition matrix."""
    neighbors = build_neighbor_graph(population, lower, upper, k, backend="brute")
    return sparse_transition_matrix(neighbors, sigma).toarray()


def sparse_transition_matrix(neighbors: NeighborGraph, sigma: float) -> csr_matrix:
    """Store the directed row-stochastic graph in O(Nk) CSR memory."""
    if sigma <= 0.0 or not np.isfinite(sigma):
        raise ValueError("graph sigma must be finite and positive")
    weights = np.exp(-(neighbors.distances**2) / (2.0 * sigma**2))
    row_sums = np.sum(weights, axis=1)
    if np.any(row_sums <= 0.0) or not np.all(np.isfinite(row_sums)):
        raise FloatingPointError("graph weights underflowed; increase graph sigma")
    weights /= row_sums[:, None]
    indptr = np.arange(0, neighbors.n_candidates * neighbors.k + 1, neighbors.k)
    return csr_matrix(
        (weights.ravel(), neighbors.indices.ravel(), indptr),
        shape=(neighbors.n_candidates, neighbors.n_candidates),
    )


def diffuse(
    raw: FloatArray,
    previous: FloatArray,
    transition: FloatArray | spmatrix,
    rho: float,
) -> FloatArray:
    """Apply h_next=(1-rho)q+rho P h while checking the preconditions."""
    if not 0.0 <= rho < 1.0:
        raise ValueError("diffusion rho must satisfy 0 <= rho < 1")
    if raw.ndim != 1 or raw.shape != previous.shape or transition.shape != (raw.size, raw.size):
        raise ValueError("raw, previous, and transition dimensions are inconsistent")
    if np.any(raw < 0.0) or np.any(raw > 1.0) or np.any(previous < 0.0) or np.any(previous > 1.0):
        raise ValueError("raw and previous stress must lie in [0, 1]")
    negative = (
        bool(transition.data.size and np.any(transition.data < 0.0))
        if issparse(transition)
        else bool(np.any(transition < 0.0))
    )
    row_sums = np.asarray(transition.sum(axis=1)).ravel()
    if negative or not np.allclose(row_sums, 1.0, atol=1e-12):
        raise ValueError("transition matrix must be nonnegative and row-stochastic")
    result = (1.0 - rho) * raw + rho * np.asarray(transition @ previous).ravel()
    return np.clip(result, 0.0, 1.0)
