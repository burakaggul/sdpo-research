"""Deterministic fixed-cardinality latent-to-binary decoding."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray


def top_b_decode(latent: NDArray[np.floating], budget: int) -> NDArray[np.int8]:
    """Select exactly the top B finite entries, breaking ties by lower index."""
    x = np.asarray(latent, dtype=np.float64)
    if x.ndim != 1 or not np.all(np.isfinite(x)):
        raise ValueError("latent vector must be one-dimensional and finite")
    if not 0 <= budget <= x.size:
        raise ValueError("feature budget must lie between zero and latent dimension")
    selected = np.lexsort((np.arange(x.size), -x))[:budget]
    result = np.zeros(x.size, dtype=np.int8)
    result[selected] = 1
    return result
