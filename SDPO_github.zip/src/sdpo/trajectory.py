"""Predeclared bounded-size best-so-far trajectory checkpoints."""

from __future__ import annotations

import numpy as np


def checkpoint_evaluations(
    budget: int,
    *,
    dense_prefix: int = 100,
    logarithmic_points: int = 2000,
) -> np.ndarray:
    """Return deterministic evaluation indices including 1 and the exact budget.

    The first ``dense_prefix`` evaluations are retained. Remaining checkpoints are
    geometrically spaced. The number of on-disk rows is therefore bounded independently
    of a potentially very large evaluation budget.
    """
    if budget < 1 or dense_prefix < 0 or logarithmic_points < 0:
        raise ValueError("budget must be positive and checkpoint controls nonnegative")
    prefix_end = min(budget, dense_prefix)
    prefix = np.arange(1, prefix_end + 1, dtype=np.int64)
    if prefix_end == budget:
        return prefix
    if logarithmic_points == 0:
        return np.unique(np.concatenate((prefix, np.array([budget], dtype=np.int64))))
    start = max(prefix_end + 1, 1)
    geometric = np.rint(
        np.geomspace(start, budget, num=logarithmic_points, dtype=np.float64)
    ).astype(np.int64)
    return np.unique(np.concatenate((prefix, geometric, np.array([budget], dtype=np.int64))))


def sample_best_so_far(
    trajectory: list[tuple[int, float]], checkpoints: np.ndarray
) -> list[dict[str, int | float]]:
    """Sample a complete, monotonic per-evaluation trajectory at declared checkpoints."""
    if not trajectory:
        raise ValueError("trajectory cannot be empty")
    evaluations = np.asarray([row[0] for row in trajectory], dtype=np.int64)
    best = np.asarray([row[1] for row in trajectory], dtype=np.float64)
    if np.any(np.diff(evaluations) <= 0) or np.any(np.diff(best) > 0):
        raise ValueError("trajectory must have increasing evaluations and non-increasing best")
    if checkpoints[0] < evaluations[0] or checkpoints[-1] > evaluations[-1]:
        raise ValueError("checkpoints fall outside the recorded trajectory")
    positions = np.searchsorted(evaluations, checkpoints, side="right") - 1
    return [
        {"evaluations": int(checkpoint), "best_objective": float(best[position])}
        for checkpoint, position in zip(checkpoints, positions, strict=True)
    ]
