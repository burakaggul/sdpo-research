"""Boundary-handling operations shared by SDPO components."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]


def validate_bounds(lower: FloatArray, upper: FloatArray) -> None:
    """Raise a clear error unless bounds are finite, aligned, and nonempty."""
    if lower.ndim != 1 or upper.ndim != 1 or lower.shape != upper.shape:
        raise ValueError("lower and upper bounds must be one-dimensional arrays of equal shape")
    if lower.size == 0 or not np.all(np.isfinite(lower)) or not np.all(np.isfinite(upper)):
        raise ValueError("bounds must be nonempty and finite")
    if np.any(upper <= lower):
        raise ValueError("every upper bound must be strictly greater than its lower bound")


def reflect(values: FloatArray, lower: FloatArray, upper: FloatArray) -> FloatArray:
    """Reflect arbitrary finite values into the closed box without rejection sampling."""
    validate_bounds(lower, upper)
    x = np.asarray(values, dtype=np.float64)
    if x.shape[-1] != lower.size:
        raise ValueError("the last candidate dimension must match the bound dimension")
    if not np.all(np.isfinite(x)):
        raise ValueError("candidate values must be finite before boundary reflection")
    width = upper - lower
    phase = np.mod(x - lower, 2.0 * width)
    return lower + np.where(phase <= width, phase, 2.0 * width - phase)


def in_bounds(values: FloatArray, lower: FloatArray, upper: FloatArray) -> bool:
    """Return whether every candidate coordinate lies in the closed box."""
    x = np.asarray(values)
    return bool(np.all(x >= lower) and np.all(x <= upper))
