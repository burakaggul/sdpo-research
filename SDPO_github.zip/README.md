# sdpo-research

Reproducible CPU research implementation of Stress-Diffusion Proteostasis Optimization (SDPO),
a graph-diffused adaptive operator portfolio for continuous black-box search. The repository
contains the audited 11,520-run COCO/BBOB confirmatory study, a completed matched-budget
ablation, modern adaptive-DE comparator extensions, and a separately frozen large-scale
validation study. Biological vocabulary is a design abstraction; novelty and performance
claims are deliberately bounded by the recorded literature and artifact audits.

## Verify the implementation

```powershell
python -m pip install -e .
python scripts/verify_environment.py
python -m pytest
python scripts/run_smoke_tests.py --config configs/laptop.yaml
```

The experiment drivers are resumable and use exact objective-call accounting. See
`reports/project_status.md`, `reports/experimental_audit.md`, and the manuscript data-availability
statement for evidence boundaries, hashes, and reproduction commands.
