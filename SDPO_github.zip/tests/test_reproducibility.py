import numpy as np

from sdpo.core import SDPOConfig, optimize
from sdpo.objectives import rastrigin


def _run(seed: int):
    return optimize(
        rastrigin,
        np.full(5, -5.12),
        np.full(5, 5.12),
        SDPOConfig(population_size=12, evaluation_budget=160, seed=seed, graph_k=3),
    )


def test_same_seed_replays_exact_search() -> None:
    first, second = _run(99), _run(99)
    assert first.best_objective == second.best_objective
    assert np.array_equal(first.best_solution, second.best_solution)
    assert np.array_equal(first.final_population, second.final_population)
    assert [p.best_objective for p in first.trajectory] == [
        p.best_objective for p in second.trajectory
    ]
    assert first.diagnostics == second.diagnostics


def test_different_seed_changes_search_behavior() -> None:
    first, second = _run(99), _run(100)
    assert not np.array_equal(first.final_population, second.final_population)
    assert [p.best_objective for p in first.trajectory] != [
        p.best_objective for p in second.trajectory
    ]
