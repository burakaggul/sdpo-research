import numpy as np

from sdpo.boundary import in_bounds, reflect


def test_reflection_handles_multiple_box_widths() -> None:
    lower = np.array([-1.0, 0.0])
    upper = np.array([1.0, 2.0])
    reflected = reflect(np.array([[9.25, -13.0], [-8.5, 21.5]]), lower, upper)
    assert in_bounds(reflected, lower, upper)
