import numpy as np

from sdpo.graph import diffuse, transition_matrix


def test_transition_is_row_stochastic_and_diffusion_preserves_bounds() -> None:
    rng = np.random.default_rng(7)
    population = rng.uniform(-2.0, 3.0, size=(9, 4))
    p = transition_matrix(population, np.full(4, -2.0), np.full(4, 3.0), 3, 0.4)
    q = rng.uniform(size=9)
    h = rng.uniform(size=9)
    result = diffuse(q, h, p, 0.6)
    assert np.all(p >= 0.0)
    assert np.allclose(p.sum(axis=1), 1.0)
    assert np.all((result >= 0.0) & (result <= 1.0))


def test_row_stochastic_map_is_nonexpansive_in_infinity_norm() -> None:
    rng = np.random.default_rng(8)
    population = rng.uniform(size=(7, 3))
    p = transition_matrix(population, np.zeros(3), np.ones(3), 2, 0.3)
    a, b = rng.normal(size=7), rng.normal(size=7)
    assert np.max(np.abs(p @ a - p @ b)) <= np.max(np.abs(a - b)) + 1e-14
