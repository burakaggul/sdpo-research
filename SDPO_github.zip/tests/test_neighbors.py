import numpy as np

from sdpo.graph import diffuse, sparse_transition_matrix
from sdpo.neighbors import build_neighbor_graph


def test_exact_backends_agree_without_distance_ties() -> None:
    rng = np.random.default_rng(2026)
    population = rng.uniform(-3.0, 4.0, size=(31, 6))
    lower, upper = np.full(6, -3.0), np.full(6, 4.0)
    brute = build_neighbor_graph(population, lower, upper, 5, backend="brute", brute_chunk_size=7)
    tree = build_neighbor_graph(population, lower, upper, 5, backend="ckdtree")
    sklearn = build_neighbor_graph(
        population, lower, upper, 5, backend="sklearn", sklearn_algorithm="brute"
    )
    assert np.array_equal(tree.indices, brute.indices)
    assert np.array_equal(sklearn.indices, brute.indices)
    assert np.allclose(tree.distances, brute.distances, atol=1e-14)
    assert np.allclose(sklearn.distances, brute.distances, atol=1e-14)


def test_sparse_graph_has_nk_entries_and_bounded_diffusion() -> None:
    rng = np.random.default_rng(2027)
    population = rng.uniform(size=(40, 8))
    neighbors = build_neighbor_graph(population, np.zeros(8), np.ones(8), 4)
    transition = sparse_transition_matrix(neighbors, 0.4)
    q, h = rng.uniform(size=40), rng.uniform(size=40)
    result = diffuse(q, h, transition, 0.35)
    assert transition.nnz == 40 * 4
    assert np.allclose(np.asarray(transition.sum(axis=1)).ravel(), 1.0)
    assert np.all((result >= 0.0) & (result <= 1.0))


def test_exact_ckdtree_is_deterministic() -> None:
    rng = np.random.default_rng(2028)
    population = rng.normal(size=(50, 10))
    lower, upper = np.full(10, -5.0), np.full(10, 5.0)
    first = build_neighbor_graph(population, lower, upper, 7, backend="ckdtree")
    second = build_neighbor_graph(population, lower, upper, 7, backend="ckdtree")
    assert np.array_equal(first.indices, second.indices)
    assert np.array_equal(first.distances, second.distances)
