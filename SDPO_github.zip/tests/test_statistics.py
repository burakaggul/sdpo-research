import numpy as np

from sdpo.credit import normalized_gain, update_credits


def test_credit_is_improvement_per_evaluation_and_missing_samples_retain_credit() -> None:
    assert np.isclose(normalized_gain(10.0, 8.0, 2), 0.1)
    old = np.array([0.2, 0.3, 0.4])
    updated = update_credits(old, {"F": [0.5], "A": [], "D": []}, 0.5)
    assert np.allclose(updated, [0.35, 0.3, 0.4])
