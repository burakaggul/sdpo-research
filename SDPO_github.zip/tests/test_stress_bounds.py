import numpy as np

from sdpo.stress import crowding_stress, quality_stress, raw_stress, stagnation_stress


def test_all_stress_components_are_bounded() -> None:
    population = np.array([[0.0, 0.0], [0.0, 0.0], [0.5, 0.5], [1.0, 1.0]])
    rank = quality_stress(np.array([1.0, 1.0, 2.0, 3.0]))
    stalled = stagnation_stress(np.array([0, 2, 10, 20]), 10)
    crowding = crowding_stress(population, np.zeros(2), np.ones(2), 2)
    combined = raw_stress(rank, stalled, crowding, (0.4, 0.3, 0.3))
    assert np.all((rank >= 0.0) & (rank <= 1.0))
    assert np.all((stalled >= 0.0) & (stalled <= 1.0))
    assert np.all((crowding > 0.0) & (crowding <= 1.0))
    assert np.all((combined >= 0.0) & (combined <= 1.0))
