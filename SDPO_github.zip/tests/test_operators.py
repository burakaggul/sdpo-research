import numpy as np

from sdpo.boundary import in_bounds
from sdpo.core import SDPOConfig, optimize
from sdpo.operators import annealing_proposals, chaperone_refold, degradation_replacement


def test_all_operator_candidates_remain_in_bounds() -> None:
    rng = np.random.default_rng(11)
    lower, upper = np.full(4, -1.0), np.full(4, 1.0)
    population = rng.uniform(lower, upper, size=(8, 4))
    values = np.sum(population**2, axis=1)
    refold = chaperone_refold(
        population[0],
        population,
        values,
        np.empty((0, 0)),
        lower,
        upper,
        rng,
        low_rank=2,
        archive_min_steps=3,
        elite_fraction=0.25,
        attraction=0.4,
        scale=0.2,
        isotropic_epsilon=0.05,
    )
    annealed = annealing_proposals(
        population[0],
        population,
        0.5,
        4,
        lower,
        upper,
        rng,
        differential_scale=0.5,
        annealing_scale=2.0,
        student_t_df=2.0,
    )
    degraded = degradation_replacement(population, lower, upper, rng, 0.2)
    assert in_bounds(refold.candidate, lower, upper)
    assert in_bounds(annealed, lower, upper)
    assert in_bounds(degraded, lower, upper)


def test_low_rank_operator_reports_insufficient_archive_fallback() -> None:
    rng = np.random.default_rng(12)
    population = rng.uniform(-1.0, 1.0, size=(6, 3))
    proposal = chaperone_refold(
        population[0],
        population,
        np.sum(population**2, axis=1),
        np.ones((3, 2)),
        np.full(3, -1.0),
        np.ones(3),
        rng,
        low_rank=2,
        archive_min_steps=3,
        elite_fraction=0.5,
        attraction=0.3,
        scale=0.1,
        isotropic_epsilon=0.05,
    )
    assert proposal.used_fallback
    assert proposal.explained_variance == 0.0


def test_chronic_gate_can_activate_degradation_without_harming_elitism() -> None:
    result = optimize(
        lambda x: 1.0,
        np.full(3, -1.0),
        np.ones(3),
        SDPOConfig(
            population_size=10,
            evaluation_budget=300,
            seed=31,
            graph_k=3,
            degradation_stress_threshold=0.0,
            degradation_stagnation_threshold=0,
        ),
    )
    assert any(row["operator"] == "D" for row in result.diagnostics)
    assert result.best_objective == 1.0
