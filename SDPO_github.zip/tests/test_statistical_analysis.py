import numpy as np

from sdpo.statistical_analysis import aligned_friedman, holm_adjust, paired_wilcoxon


def test_aligned_friedman_matches_hand_checked_fixture() -> None:
    # After block alignment, the pooled average ranks are
    # [[2, 5, 8], [5, 2, 8], [8, 5, 2]]. Direct substitution in Garcia
    # et al.'s numerator and denominator gives T = 0.6.
    data = np.array([[1.0, 2.0, 3.0], [2.0, 1.0, 3.0], [3.0, 2.0, 1.0]])
    result = aligned_friedman(data)
    assert np.allclose(result.aligned_rank_sums_by_treatment, [15.0, 12.0, 18.0])
    assert np.isclose(result.statistic, 0.6)


def test_aligned_friedman_is_invariant_to_block_offsets() -> None:
    data = np.array([[1.0, 2.0, 4.0], [5.0, 1.0, 0.0], [2.0, 2.5, 8.0]])
    shifted = data + np.array([[100.0], [-7.0], [0.25]])
    first = aligned_friedman(data)
    second = aligned_friedman(shifted)
    assert np.isclose(first.statistic, second.statistic)
    assert np.isclose(first.p_value, second.p_value)


def test_aligned_friedman_all_equal_is_neutral() -> None:
    result = aligned_friedman(np.ones((6, 4)))
    assert result.statistic == 0.0
    assert result.p_value == 1.0


def test_holm_adjust_preserves_order_and_step_down_monotonicity() -> None:
    adjusted = holm_adjust(np.array([0.01, 0.04, 0.03]))
    assert np.allclose(adjusted, [0.03, 0.06, 0.06])


def test_paired_wilcoxon_zero_case_and_effect_direction() -> None:
    neutral = paired_wilcoxon(np.zeros(4))
    assert neutral.p_value == 1.0
    assert neutral.rank_biserial == 0.0
    assert neutral.nonzero_pairs == 0

    positive = paired_wilcoxon(np.array([1.0, 2.0, 3.0]))
    negative = paired_wilcoxon(np.array([-1.0, -2.0, -3.0]))
    assert positive.rank_biserial == 1.0
    assert negative.rank_biserial == -1.0
