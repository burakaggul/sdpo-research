import numpy as np

from sdpo.binary_decoder import top_b_decode


def test_top_b_decoder_selects_exactly_b_with_deterministic_ties() -> None:
    decoded = top_b_decode(np.array([0.4, 0.9, 0.9, 0.2, 0.9]), 2)
    assert decoded.sum() == 2
    assert np.array_equal(np.flatnonzero(decoded), np.array([1, 2]))
