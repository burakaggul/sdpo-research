import gzip
from pathlib import Path

import pytest

from sdpo.logging_utils import atomic_gzip_csv


def test_atomic_gzip_csv_is_readable_reproducible_and_refuses_overwrite(tmp_path: Path) -> None:
    path = tmp_path / "trajectory.csv.gz"
    rows = [{"evaluations": 1, "best": 2.0}, {"evaluations": 2, "best": 1.0}]
    atomic_gzip_csv(path, rows)
    first = path.read_bytes()
    assert gzip.decompress(first).decode() == "evaluations,best\r\n1,2.0\r\n2,1.0\r\n"
    with pytest.raises(FileExistsError):
        atomic_gzip_csv(path, rows)
    atomic_gzip_csv(path, rows, overwrite=True)
    assert path.read_bytes() == first
