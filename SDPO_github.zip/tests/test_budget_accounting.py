import numpy as np
import pytest

from sdpo.core import EvaluationBudget, SDPOConfig, optimize
from sdpo.objectives import sphere


@pytest.mark.parametrize("budget", [12, 13, 37, 101])
def test_exact_function_evaluation_count_for_arbitrary_tail_budget(budget: int) -> None:
    calls = 0

    def counted(x: np.ndarray) -> float:
        nonlocal calls
        calls += 1
        return sphere(x)

    result = optimize(
        counted,
        np.full(3, -5.0),
        np.full(3, 5.0),
        SDPOConfig(population_size=12, evaluation_budget=budget, seed=4, graph_k=3),
    )
    assert calls == budget == result.evaluations == len(result.trajectory)
    best = np.array([point.best_objective for point in result.trajectory])
    assert np.all(np.diff(best) <= 0.0)


def test_budget_gateway_refuses_overrun() -> None:
    budget = EvaluationBudget(sphere, 1)
    budget.evaluate(np.zeros(2))
    with pytest.raises(RuntimeError, match="budget exhaustion"):
        budget.evaluate(np.zeros(2))
