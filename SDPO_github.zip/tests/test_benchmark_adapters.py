import os
from pathlib import Path

import numpy as np
import pytest

from sdpo.benchmark_adapters import CEC2022Adapter, CocoBbobAdapter
from sdpo.core import EvaluationBudget


def test_coco_bbob_direct_call_is_deterministic_and_counted() -> None:
    pytest.importorskip("cocoex")
    adapter = CocoBbobAdapter(function=1, dimension=10, instance=1)
    try:
        point = np.zeros(10)
        first = adapter(point)
        second = adapter(point)
        assert first == second
        assert adapter.calls == adapter.native_evaluations == 2
    finally:
        adapter.close()


def test_coco_counter_aligns_with_project_budget_gateway() -> None:
    pytest.importorskip("cocoex")
    adapter = CocoBbobAdapter(function=3, dimension=10, instance=1)
    try:
        budget = EvaluationBudget(adapter, 7)
        for _ in range(7):
            budget.evaluate(np.zeros(10))
        assert budget.count == adapter.calls == adapter.native_evaluations == 7
    finally:
        adapter.close()


def test_coco_largescale_adapter_is_counted_and_has_finite_reference() -> None:
    pytest.importorskip("cocoex")
    adapter = CocoBbobAdapter(function=1, dimension=80, instance=1, suite_name="bbob-largescale")
    try:
        value = adapter(np.zeros(80))
        assert np.isfinite(value)
        assert adapter.native_evaluations == 1
    finally:
        adapter.close()
    fopt = CocoBbobAdapter.reference_fopt(1, 80, 1, suite_name="bbob-largescale")
    assert np.isfinite(fopt)


def test_cec2022_external_source_call_is_deterministic_and_counted() -> None:
    source = os.environ.get("SDPO_CEC2022_ROOT")
    if not source:
        pytest.skip("official CEC 2022 source is not vendored; set SDPO_CEC2022_ROOT")
    adapter = CEC2022Adapter(Path(source), function=1, dimension=10)
    point = np.zeros(10)
    first = adapter(point)
    second = adapter(point)
    assert first == second
    assert adapter.calls == 2
    assert first >= adapter.bias
