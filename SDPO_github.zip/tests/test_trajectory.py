import numpy as np
import pytest

from sdpo.trajectory import checkpoint_evaluations, sample_best_so_far


def test_checkpoint_schedule_is_bounded_deterministic_and_has_endpoints() -> None:
    first = checkpoint_evaluations(1_000_000, dense_prefix=100, logarithmic_points=2000)
    second = checkpoint_evaluations(1_000_000, dense_prefix=100, logarithmic_points=2000)
    assert np.array_equal(first, second)
    assert first[0] == 1 and first[-1] == 1_000_000
    assert np.all(np.diff(first) > 0)
    assert len(first) <= 2101
    assert np.array_equal(first[:100], np.arange(1, 101))


def test_sample_best_so_far_preserves_declared_values() -> None:
    trajectory = [(index, float(10 - index // 3)) for index in range(1, 11)]
    sampled = sample_best_so_far(trajectory, np.array([1, 3, 4, 10]))
    assert [row["evaluations"] for row in sampled] == [1, 3, 4, 10]
    assert [row["best_objective"] for row in sampled] == [10.0, 9.0, 9.0, 7.0]


def test_invalid_nonmonotonic_trajectory_is_rejected() -> None:
    with pytest.raises(ValueError):
        sample_best_so_far([(1, 1.0), (2, 2.0)], np.array([1, 2]))
