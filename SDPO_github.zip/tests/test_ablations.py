import numpy as np
import pytest

from sdpo.ablations import ABLATION_VARIANTS, ablation_config
from sdpo.competitors import sdpo_ablation
from sdpo.core import SDPOConfig
from sdpo.objectives import sphere


def test_all_frozen_ablation_configs_are_valid_and_one_factor_named() -> None:
    base = SDPOConfig(population_size=10, evaluation_budget=40, graph_k=3)
    configs = {name: ablation_config(base, name) for name in ABLATION_VARIANTS}
    assert configs["no_diff"].diffusion_rho == 0.0
    assert configs["no_credit"].eta == 0.0
    assert configs["isotropic"].archive_min_steps > configs["isotropic"].archive_max_steps
    assert configs["no_degradation"].degradation_stress_threshold == 1.0
    assert configs["random_policy"].eta == configs["random_policy"].beta == 0.0
    assert configs["uniform_restart"].uniform_restart_weight == 1.0
    for name in ("no_stagnation", "no_crowding", "no_rank_stress"):
        assert np.isclose(sum(configs[name].stress_weights), 1.0)


def test_ablation_wrapper_preserves_exact_budget() -> None:
    result = sdpo_ablation(
        sphere,
        np.full(3, -5.0),
        np.full(3, 5.0),
        41,
        7,
        variant="no_diff",
        population_size=10,
    )
    assert result.evaluations == len(result.trajectory) == 41
    assert result.parameters["ablation_variant"] == "no_diff"


def test_unknown_ablation_is_rejected() -> None:
    with pytest.raises(ValueError, match="unknown SDPO ablation"):
        ablation_config(SDPOConfig(), "not_a_variant")
