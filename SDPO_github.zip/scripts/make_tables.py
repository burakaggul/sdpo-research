"""Generate publication tables from validated confirmatory BBOB artifacts."""

from __future__ import annotations

import csv
import json
import math
import os
from collections import defaultdict
from pathlib import Path
from statistics import mean, median, stdev
from tempfile import NamedTemporaryFile

import numpy as np
from scipy.stats import rankdata

from sdpo.logging_utils import atomic_csv

ROOT = Path(__file__).resolve().parents[1]
SUMMARY = ROOT / "results" / "tables" / "bbob_summary.csv"
AUDIT = ROOT / "results" / "metadata" / "bbob_manifest_audit.csv"
FUNCTION_MEDIANS = ROOT / "results" / "statistics" / "function_median_log_error.csv"
PAIRWISE = ROOT / "results" / "statistics" / "pairwise_wilcoxon_holm.csv"
OMNIBUS = ROOT / "results" / "statistics" / "aligned_friedman.csv"
RAW = ROOT / "results" / "raw" / "bbob"
TABLES = ROOT / "results" / "tables"
MANUSCRIPT_TABLES = ROOT / "manuscript" / "tables"
ALGORITHMS = ("CMA-ES-Restart", "DE-rand-1-bin", "SDPO-Full", "Random-Search")
FUNCTION_FAMILIES = {
    "separable": range(1, 6),
    "low_or_moderate_conditioning": range(6, 10),
    "high_conditioning_unimodal": range(10, 15),
    "multimodal_adequate_global_structure": range(15, 20),
    "multimodal_weak_global_structure": range(20, 25),
}


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _quantile(values: list[float], q: float) -> float:
    return float(np.quantile(np.asarray(values, dtype=np.float64), q, method="linear"))


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        handle.write(text)
        temporary = Path(handle.name)
    os.replace(temporary, path)


def build_integrity() -> list[dict[str, object]]:
    grouped: dict[tuple[str, int], list[dict[str, str]]] = defaultdict(list)
    for row in _read_csv(AUDIT):
        grouped[(row["algorithm"], int(row["dimension"]))].append(row)
    output = []
    for (algorithm, dimension), rows in sorted(grouped.items()):
        passed = sum(row["status"] == "passed" for row in rows)
        output.append(
            {
                "algorithm": algorithm,
                "dimension": dimension,
                "expected_runs": 720,
                "audited_runs": len(rows),
                "passed_runs": passed,
                "failed_runs": len(rows) - passed,
                "counter_disagreements": sum(bool(row["errors"]) for row in rows),
                "decision": "PASS" if len(rows) == passed == 720 else "FAIL",
            }
        )
    if len(output) != 16 or any(row["decision"] != "PASS" for row in output):
        raise AssertionError("algorithm/dimension integrity table did not pass")
    return output


def build_descriptive() -> list[dict[str, object]]:
    grouped: dict[tuple[int, int, str], list[float]] = defaultdict(list)
    for row in _read_csv(SUMMARY):
        error = max(float(row["final_error"]), 0.0)
        grouped[(int(row["function"]), int(row["dimension"]), row["algorithm"])].append(
            math.log10(error + 1e-12)
        )
    output = []
    for (function, dimension, algorithm), values in sorted(grouped.items()):
        finite = [value for value in values if math.isfinite(value)]
        if len(values) != 30 or len(finite) != 30:
            raise AssertionError("descriptive group must contain 30 finite values")
        q1, q3 = _quantile(finite, 0.25), _quantile(finite, 0.75)
        output.append(
            {
                "function": function,
                "dimension": dimension,
                "algorithm": algorithm,
                "count": len(values),
                "finite_count": len(finite),
                "median_log10_error": median(finite),
                "q1_log10_error": q1,
                "q3_log10_error": q3,
                "iqr_log10_error": q3 - q1,
                "mean_log10_error": mean(finite),
                "sample_sd_log10_error": stdev(finite),
                "min_log10_error": min(finite),
                "max_log10_error": max(finite),
                "success_count": "",
                "success_definition": "not_declared_for_confirmatory_analysis",
            }
        )
    if len(output) != 384:
        raise AssertionError("expected 384 function/dimension/algorithm groups")
    return output


def build_ranks() -> list[dict[str, object]]:
    rows = _read_csv(FUNCTION_MEDIANS)
    lookup = {
        (int(row["dimension"]), int(row["function"]), row["algorithm"]): float(
            row["median_log10_error"]
        )
        for row in rows
    }
    output = []
    for dimension in (5, 10, 20, 40):
        rank_rows = []
        for function in range(1, 25):
            values = [lookup[(dimension, function, algorithm)] for algorithm in ALGORITHMS]
            rank_rows.append(rankdata(values, method="average"))
        matrix = np.asarray(rank_rows)
        for index, algorithm in enumerate(ALGORITHMS):
            output.append(
                {
                    "dimension": dimension,
                    "algorithm": algorithm,
                    "ranking_unit": "function-level median log10 error; lower is better",
                    "n_function_blocks": 24,
                    "mean_rank": float(np.mean(matrix[:, index])),
                    "median_rank": float(np.median(matrix[:, index])),
                    "best_rank_count": int(np.sum(matrix[:, index] == 1.0)),
                }
            )
    return output


def build_family_summary() -> list[dict[str, object]]:
    rows = _read_csv(FUNCTION_MEDIANS)
    lookup = {
        (int(row["dimension"]), int(row["function"]), row["algorithm"]): float(
            row["median_log10_error"]
        )
        for row in rows
    }
    output = []
    for dimension in (5, 10, 20, 40):
        for family, functions in FUNCTION_FAMILIES.items():
            for comparator in ("CMA-ES-Restart", "DE-rand-1-bin", "Random-Search"):
                differences = [
                    lookup[(dimension, function, "SDPO-Full")]
                    - lookup[(dimension, function, comparator)]
                    for function in functions
                ]
                output.append(
                    {
                        "dimension": dimension,
                        "family": family,
                        "function_range": f"{min(functions)}-{max(functions)}",
                        "comparator": comparator,
                        "n_functions": len(differences),
                        "median_sdpo_minus_comparator_log10_error": median(differences),
                        "sdpo_better_function_count": sum(value < 0 for value in differences),
                        "exact_tie_function_count": sum(value == 0 for value in differences),
                        "sdpo_worse_function_count": sum(value > 0 for value in differences),
                        "evidence_status": "secondary_descriptive_not_multiplicity_tested",
                    }
                )
    return output


def build_runtime() -> list[dict[str, object]]:
    grouped: dict[tuple[int, str], list[float]] = defaultdict(list)
    for row in _read_csv(SUMMARY):
        grouped[(int(row["dimension"]), row["algorithm"])].append(float(row["elapsed_seconds"]))
    output = []
    for (dimension, algorithm), values in sorted(grouped.items()):
        if len(values) != 720:
            raise AssertionError("runtime group must contain 720 runs")
        q1, q3 = _quantile(values, 0.25), _quantile(values, 0.75)
        output.append(
            {
                "dimension": dimension,
                "algorithm": algorithm,
                "n_runs": len(values),
                "median_seconds": median(values),
                "q1_seconds": q1,
                "q3_seconds": q3,
                "iqr_seconds": q3 - q1,
                "mean_seconds": mean(values),
                "sample_sd_seconds": stdev(values),
                "min_seconds": min(values),
                "max_seconds": max(values),
                "caveat": "four-worker workstation wall time; hardware and load dependent",
            }
        )
    return output


def build_cma_restarts() -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    details = []
    grouped: dict[int, list[dict[str, object]]] = defaultdict(list)
    for path in sorted(RAW.glob("cma_es_restart_*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        parameters = payload["parameters"]
        reasons = parameters["restart_reasons"]
        row = {
            "problem_id": payload["problem_id"],
            "function": payload["function"],
            "dimension": payload["dimension"],
            "instance": payload["instance"],
            "seed": payload["seed"],
            "restarts": parameters["restarts"],
            "stop_restarts": reasons["stop"],
            "numerical_failure_restarts": reasons["numerical_failure"],
            "partial_final_generation": parameters[
                "partial_final_generation_evaluated_without_tell"
            ],
        }
        details.append(row)
        grouped[int(payload["dimension"])].append(row)
    if len(details) != 2880:
        raise AssertionError("expected 2880 CMA restart records")
    summary = []
    for dimension, rows in sorted(grouped.items()):
        restart_values = [int(row["restarts"]) for row in rows]
        summary.append(
            {
                "dimension": dimension,
                "n_runs": len(rows),
                "runs_with_restart": sum(value > 0 for value in restart_values),
                "total_restarts": sum(restart_values),
                "median_restarts": median(restart_values),
                "max_restarts": max(restart_values),
                "stop_restarts": sum(int(row["stop_restarts"]) for row in rows),
                "numerical_failure_restarts": sum(
                    int(row["numerical_failure_restarts"]) for row in rows
                ),
                "runs_with_partial_final_generation": sum(
                    int(row["partial_final_generation"]) > 0 for row in rows
                ),
            }
        )
    return details, summary


def render_manuscript_tables(runtime: list[dict[str, object]]) -> None:
    summary_rows = _read_csv(SUMMARY)
    errors: dict[tuple[int, str], list[float]] = defaultdict(list)
    for row in summary_rows:
        errors[(int(row["dimension"]), row["algorithm"])].append(
            math.log10(max(float(row["final_error"]), 0.0) + 1e-12)
        )
    lines = [
        r"\begin{tabular}{rrrrr}",
        r"\toprule",
        r"Dimension & CMA-ES-Restart & DE-rand-1-bin & SDPO-Full & Random Search \\",
        r"\midrule",
    ]
    for dimension in (5, 10, 20, 40):
        values = [median(errors[(dimension, algorithm)]) for algorithm in ALGORITHMS]
        lines.append(f"{dimension} & " + " & ".join(f"{value:.3f}" for value in values) + r" \\")
    lines.extend((r"\bottomrule", r"\end{tabular}"))
    _write_text(MANUSCRIPT_TABLES / "primary_performance_generated.tex", "\n".join(lines) + "\n")

    pairwise = _read_csv(PAIRWISE)
    omnibus = sorted(_read_csv(OMNIBUS), key=lambda row: int(row["dimension"]))
    comparator_order = {"CMA-ES-Restart": 0, "DE-rand-1-bin": 1, "Random-Search": 2}
    pairwise.sort(key=lambda row: (int(row["dimension"]), comparator_order[row["comparator"]]))
    lines = [
        r"\begin{tabular}{rrrr}",
        r"\toprule",
        r"Dimension & Aligned Friedman $Q$ & df & $p$ \\",
        r"\midrule",
    ]
    for row in omnibus:
        lines.append(
            f"{row['dimension']} & {float(row['statistic']):.3f} & "
            f"{row['degrees_of_freedom']} & ${float(row['p_value']):.2e}$ " + r"\\"
        )
    lines.extend((r"\bottomrule", r"\end{tabular}", r"\par\medskip"))
    lines.extend(
        [
            r"\begin{tabular}{rlrrr}",
            r"\toprule",
            r"Dimension & Comparator & Holm $p$ & Median difference & $r_{rb}$ \\",
            r"\midrule",
        ]
    )
    for row in pairwise:
        comparator = row["comparator"].replace("Random-Search", "Random Search")
        lines.append(
            f"{row['dimension']} & {comparator} & ${float(row['holm_adjusted_p_value']):.2e}$ & "
            f"{float(row['median_difference_sdpo_minus_comparator']):.3f} & "
            f"{float(row['rank_biserial_sdpo_minus_comparator']):.3f} " + r"\\"
        )
    lines.extend((r"\bottomrule", r"\end{tabular}"))
    _write_text(MANUSCRIPT_TABLES / "confirmatory_generated.tex", "\n".join(lines) + "\n")

    runtime_lookup = {(int(row["dimension"]), str(row["algorithm"])): row for row in runtime}
    lines = [
        r"\begin{tabular}{rrrrr}",
        r"\toprule",
        r"Dimension & CMA-ES-Restart & DE-rand-1-bin & SDPO-Full & Random Search \\",
        r"\midrule",
    ]
    for dimension in (5, 10, 20, 40):
        values = [
            float(runtime_lookup[(dimension, algorithm)]["median_seconds"])
            for algorithm in ALGORITHMS
        ]
        lines.append(f"{dimension} & " + " & ".join(f"{value:.2f}" for value in values) + r" \\")
    lines.extend((r"\bottomrule", r"\end{tabular}"))
    _write_text(MANUSCRIPT_TABLES / "runtime_generated.tex", "\n".join(lines) + "\n")


def main() -> None:
    integrity = build_integrity()
    descriptive = build_descriptive()
    ranks = build_ranks()
    family_summary = build_family_summary()
    runtime = build_runtime()
    cma_detail, cma_summary = build_cma_restarts()
    atomic_csv(TABLES / "artifact_integrity_by_algorithm_dimension.csv", integrity, overwrite=True)
    atomic_csv(TABLES / "descriptive_final_error.csv", descriptive, overwrite=True)
    atomic_csv(TABLES / "algorithm_ranks_by_dimension.csv", ranks, overwrite=True)
    atomic_csv(TABLES / "bbob_family_summary.csv", family_summary, overwrite=True)
    atomic_csv(TABLES / "runtime_summary.csv", runtime, overwrite=True)
    atomic_csv(TABLES / "cma_restart_diagnostics.csv", cma_detail, overwrite=True)
    atomic_csv(TABLES / "cma_restart_summary.csv", cma_summary, overwrite=True)
    render_manuscript_tables(runtime)
    print(
        "generated: 16 integrity, 384 descriptive, 16 rank, 16 runtime, "
        "2880 CMA detail, and 4 CMA summary rows"
    )


if __name__ == "__main__":
    main()
