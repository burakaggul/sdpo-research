raise SystemExit("Sensitivity analysis is gated until benchmark configuration is frozen.")
