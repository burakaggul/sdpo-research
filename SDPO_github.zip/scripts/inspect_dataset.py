from pathlib import Path

from sdpo.datasets import require_dataset

if __name__ == "__main__":
    require_dataset(Path("data/raw"))
