"""Generate checkpoint-resolved BBOB ECDF, ERT, and target-attainment artifacts."""

from __future__ import annotations

import csv
import gzip
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TARGETS = 10.0 ** np.linspace(2.0, -8.0, 51)
NAMESPACES = ("bbob", "extension_bbob")


def _load_bundle(
    item: tuple[str, Path, Path],
) -> list[dict[str, object]]:
    namespace, raw_path, trajectory_path = item
    payload = json.loads(raw_path.read_text(encoding="utf-8"))
    with gzip.open(trajectory_path, "rt", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    evaluations = np.asarray([int(row["evaluations"]) for row in rows], dtype=np.int64)
    best = np.asarray([float(row["best_objective"]) for row in rows])
    error = np.maximum(best - float(payload["reference_fopt"]), 0.0)
    records: list[dict[str, object]] = []
    for target in TARGETS:
        reached = np.flatnonzero(error <= target)
        attainment = int(evaluations[reached[0]]) if reached.size else None
        records.append(
            {
                "namespace": namespace,
                "algorithm": payload["algorithm"],
                "function": int(payload["function"]),
                "dimension": int(payload["dimension"]),
                "instance": int(payload["instance"]),
                "seed": int(payload["seed"]),
                "budget": int(payload["evaluation_budget"]),
                "target": float(target),
                "attainment_evaluations": attainment,
                "success": attainment is not None,
            }
        )
    return records


def _load_runs() -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    bundles: list[tuple[str, Path, Path]] = []
    for namespace in NAMESPACES:
        if namespace != "bbob":
            status_path = ROOT / "results" / "logs" / f"{namespace}_status.json"
            if not status_path.is_file():
                continue
            status = json.loads(status_path.read_text(encoding="utf-8"))
            if status.get("state") != "complete":
                continue
        raw_root = ROOT / "results" / "raw" / namespace
        trajectory_root = ROOT / "results" / "trajectories" / namespace
        if not raw_root.exists():
            continue
        for raw_path in sorted(raw_root.glob("*.json")):
            trajectory_path = trajectory_root / f"{raw_path.stem}.csv.gz"
            if not trajectory_path.is_file():
                raise FileNotFoundError(f"missing trajectory for {raw_path.name}")
            bundles.append((namespace, raw_path, trajectory_path))
    with ThreadPoolExecutor(max_workers=16) as executor:
        for bundle_records in executor.map(_load_bundle, bundles, chunksize=32):
            records.extend(bundle_records)
    if not records:
        raise RuntimeError("no BBOB run bundles found")
    return records


def _ert(attainment: pd.DataFrame) -> pd.DataFrame:
    group_columns = ["algorithm", "dimension", "function", "target"]
    rows: list[dict[str, object]] = []
    for keys, group in attainment.groupby(group_columns, sort=True):
        successful = group["success"].astype(bool)
        successes = int(successful.sum())
        cost = np.where(
            successful,
            group["attainment_evaluations"].fillna(group["budget"]),
            group["budget"],
        ).astype(float)
        rows.append(
            {
                **dict(zip(group_columns, keys, strict=True)),
                "runs": int(len(group)),
                "successes": successes,
                "success_rate": successes / len(group),
                "ert_evaluations": float(cost.sum() / successes) if successes else np.nan,
            }
        )
    return pd.DataFrame(rows)


def _ecdf(attainment: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for (algorithm, dimension), group in attainment.groupby(["algorithm", "dimension"], sort=True):
        maximum = float(np.log10(group["budget"].iloc[0] / dimension))
        for log_evals_per_dimension in np.linspace(0.0, maximum, 201):
            threshold = dimension * 10.0**log_evals_per_dimension
            solved = group["attainment_evaluations"].notna() & (
                group["attainment_evaluations"] <= threshold
            )
            rows.append(
                {
                    "algorithm": algorithm,
                    "dimension": int(dimension),
                    "log10_evaluations_per_dimension": log_evals_per_dimension,
                    "fraction_run_target_pairs": float(solved.mean()),
                    "run_target_pairs": int(len(group)),
                }
            )
    return pd.DataFrame(rows)


def _target_summary(attainment: pd.DataFrame) -> pd.DataFrame:
    summary = (
        attainment.groupby(["algorithm", "dimension", "target"], sort=True)
        .agg(
            runs=("success", "size"),
            successes=("success", "sum"),
            median_attainment_evaluations=("attainment_evaluations", "median"),
        )
        .reset_index()
    )
    summary["success_rate"] = summary["successes"] / summary["runs"]
    return summary


def _plot(ecdf: pd.DataFrame, output_root: Path) -> None:
    dimensions = sorted(ecdf["dimension"].unique())
    figure, axes = plt.subplots(2, 2, figsize=(8.0, 6.2), sharex=True, sharey=True)
    for axis, dimension in zip(axes.flat, dimensions, strict=False):
        subset = ecdf[ecdf["dimension"] == dimension]
        for algorithm, group in subset.groupby("algorithm", sort=True):
            axis.plot(
                group["log10_evaluations_per_dimension"],
                group["fraction_run_target_pairs"],
                label=algorithm,
                linewidth=1.5,
            )
        axis.set_title(f"d = {dimension}")
        axis.grid(alpha=0.25)
    for axis in axes[-1, :]:
        axis.set_xlabel(r"$\log_{10}(\mathrm{evaluations}/d)$")
    for axis in axes[:, 0]:
        axis.set_ylabel("Fraction of run-target pairs")
    handles, labels = axes.flat[0].get_legend_handles_labels()
    figure.legend(handles, labels, loc="upper center", ncol=3, frameon=False)
    figure.suptitle("BBOB checkpoint-resolved target attainment", y=0.995)
    figure.tight_layout(rect=(0, 0, 1, 0.93))
    for suffix in ("pdf", "svg"):
        figure.savefig(output_root.with_suffix(f".{suffix}"), bbox_inches="tight")
    figure.savefig(output_root.with_suffix(".png"), dpi=600, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    tables = ROOT / "results" / "tables"
    figures = ROOT / "results" / "figures"
    tables.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    attainment = pd.DataFrame(_load_runs())
    # When the modern-comparator extension is available, retain the identical paired
    # instance/seed subset for every algorithm.  This prevents the ECDF from comparing
    # the two new algorithms (12 runs/function) with a broader legacy sample.
    if "extension_bbob" in set(attainment["namespace"]):
        paired_primary = (attainment["namespace"] == "bbob") & (
            attainment["instance"].isin([1, 2, 3])
            & attainment["seed"].isin([20260718, 20260719, 20260720, 20260721])
        )
        attainment = attainment[
            (attainment["namespace"] == "extension_bbob") | paired_primary
        ].copy()
    ert = _ert(attainment)
    ecdf = _ecdf(attainment)
    target_summary = _target_summary(attainment)
    attainment.to_csv(tables / "bbob_target_attainment_runs.csv", index=False)
    ert.to_csv(tables / "bbob_ert_by_function.csv", index=False)
    ecdf.to_csv(tables / "bbob_ecdf.csv", index=False)
    target_summary.to_csv(tables / "bbob_target_summary.csv", index=False)
    _plot(ecdf, figures / "fig08_bbob_ecdf")
    metadata = {
        "targets": TARGETS.tolist(),
        "target_range": "10^2 through 10^-8, 51 log-spaced values",
        "attainment_resolution": "first retained trajectory checkpoint at or below target",
        "attainment_bias": "conservative; true first hit may precede retained checkpoint",
        "ert_definition": "sum(success cost + full budget for failures) / successes",
        "namespaces": list(NAMESPACES),
        "paired_subset": (
            "instances 1--3 and seeds 20260718--20260721 for all algorithms"
            if "extension_bbob" in set(attainment["namespace"])
            else "not applied because the comparator extension was unavailable"
        ),
        "run_target_rows": int(len(attainment)),
    }
    (ROOT / "results" / "metadata" / "bbob_target_analysis.json").write_text(
        json.dumps(metadata, indent=2) + "\n", encoding="utf-8"
    )
    print(
        f"target analysis: runs={len(attainment) // len(TARGETS)} "
        f"run-target rows={len(attainment)} ERT rows={len(ert)}"
    )


if __name__ == "__main__":
    main()
