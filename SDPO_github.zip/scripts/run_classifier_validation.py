raise SystemExit("Classifier validation is blocked until real dataset optimization outputs exist.")
