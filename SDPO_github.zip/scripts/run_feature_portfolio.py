raise SystemExit(
    "Feature-portfolio optimization is blocked until real IEEE DataPort files pass audit."
)
