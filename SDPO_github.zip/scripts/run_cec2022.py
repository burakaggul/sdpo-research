from sdpo.benchmarks import require_verified_suite

if __name__ == "__main__":
    require_verified_suite("CEC 2022")
