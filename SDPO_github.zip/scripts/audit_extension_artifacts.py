"""Audit the modern-comparator and untouched-validation result bundles."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import math
import os
from itertools import product
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any

import yaml

from sdpo.logging_utils import atomic_csv, atomic_json

ROOT = Path(__file__).resolve().parents[1]
MODE = {
    "comparative_extension": ("extension_bbob", "secondary_comparator_extension"),
    "untouched_validation": (
        "validation_bbob_largescale",
        "untouched_external_validation",
    ),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--skip-hashes", action="store_true")
    return parser.parse_args()


def _stem(
    algorithm: str,
    function: int,
    instance: int,
    dimension: int,
    seed: int,
    suite_name: str,
) -> str:
    normalized = algorithm.lower().replace("-", "_")
    suite_tag = "bbob" if suite_name == "bbob" else "bbob_largescale"
    return f"{normalized}_{suite_tag}_f{function:03d}_i{instance:02d}_d{dimension}_s{seed}"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _close(left: float, right: float) -> bool:
    return math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-12)


def _read_trajectory(path: Path) -> tuple[int, int, float, bool]:
    row_count = 0
    last_evaluation = 0
    last_best = math.inf
    monotonic = True
    with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != ["evaluations", "best_objective"]:
            raise ValueError(f"unexpected trajectory header: {reader.fieldnames}")
        for row in reader:
            evaluation = int(row["evaluations"])
            best = float(row["best_objective"])
            if not math.isfinite(best) or evaluation <= last_evaluation:
                raise ValueError("non-finite objective or non-increasing checkpoint")
            if best > last_best and not _close(best, last_best):
                monotonic = False
            last_evaluation = evaluation
            last_best = best
            row_count += 1
    if row_count == 0:
        raise ValueError("empty trajectory")
    return row_count, last_evaluation, last_best, monotonic


def _summary_index(path: Path) -> tuple[dict[tuple[Any, ...], dict[str, str]], list[str]]:
    index: dict[tuple[Any, ...], dict[str, str]] = {}
    errors: list[str] = []
    with path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            key = (
                row["algorithm"],
                int(row["function"]),
                int(row["dimension"]),
                int(row["instance"]),
                int(row["seed"]),
            )
            if key in index:
                errors.append(f"duplicate summary key: {key}")
            index[key] = row
    return index, errors


def _write_text_atomic(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        handle.write(content)
        temporary = Path(handle.name)
    os.replace(temporary, path)


def main() -> None:
    args = parse_args()
    config_path = args.config if args.config.is_absolute() else ROOT / args.config
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    mode = str(config.get("experiment_mode", ""))
    if mode not in MODE:
        raise ValueError(f"unsupported experiment_mode: {mode}")
    namespace, run_type = MODE[mode]
    suite_name = str(config.get("suite_name", "bbob"))
    framework = str(config.get("framework_label", "COCO/BBOB"))
    raw_root = ROOT / "results" / "raw" / namespace
    trajectory_root = ROOT / "results" / "trajectories" / namespace
    summary_path = ROOT / "results" / "tables" / f"{namespace}_summary.csv"
    status_path = ROOT / "results" / "logs" / f"{namespace}_status.json"

    expected: dict[str, tuple[str, int, int, int, int]] = {}
    for function, dimension, instance, seed, algorithm in product(
        map(int, config["functions"]),
        map(int, config["dimensions"]),
        map(int, config["instances"]),
        map(int, config["seeds"]),
        map(str, config["algorithms"]),
    ):
        stem = _stem(algorithm, function, instance, dimension, seed, suite_name)
        expected[stem] = (algorithm, function, dimension, instance, seed)

    actual_raw = {path.stem: path for path in raw_root.glob("*.json")}
    actual_trajectory = {
        path.name.removesuffix(".csv.gz"): path for path in trajectory_root.glob("*.csv.gz")
    }
    summary, global_errors = _summary_index(summary_path)
    status = json.loads(status_path.read_text(encoding="utf-8"))
    rows: list[dict[str, Any]] = []

    for stem, key in sorted(expected.items()):
        algorithm, function, dimension, instance, seed = key
        raw_path = actual_raw.get(stem)
        trajectory_path = actual_trajectory.get(stem)
        errors: list[str] = []
        budget = int(config["evaluation_budget_multiplier"]) * dimension
        payload: dict[str, Any] = {}
        trajectory_rows = 0
        trajectory_end = 0
        raw_hash = ""
        trajectory_hash = ""

        if raw_path is None:
            errors.append("missing raw JSON")
        if trajectory_path is None:
            errors.append("missing trajectory gzip")
        if raw_path is not None:
            try:
                payload = json.loads(raw_path.read_text(encoding="utf-8"))
                problem_id = (
                    f"bbob_f{function:03d}_i{instance:02d}_d{dimension:02d}"
                    if suite_name == "bbob"
                    else f"bbob_f{function:03d}_i{instance:02d}_d{dimension:04d}"
                )
                expected_fields = {
                    "schema_version": 1,
                    "run_type": run_type,
                    "framework": framework,
                    "framework_version": "2.8.2",
                    "problem_id": problem_id,
                    "function": function,
                    "dimension": dimension,
                    "instance": instance,
                    "seed": seed,
                    "algorithm": algorithm,
                    "evaluation_budget": budget,
                    "evaluations": budget,
                    "framework_native_evaluations": budget,
                    "termination_reason": "evaluation_budget_exhausted",
                }
                for field, expected_value in expected_fields.items():
                    if payload.get(field) != expected_value:
                        errors.append(
                            f"{field}={payload.get(field)!r}, expected={expected_value!r}"
                        )
                for field in (
                    "best_objective",
                    "reference_fopt",
                    "final_error",
                    "elapsed_seconds",
                ):
                    if not math.isfinite(float(payload.get(field, math.nan))):
                        errors.append(f"non-finite {field}")
                recomputed_error = max(
                    float(payload.get("best_objective", math.nan))
                    - float(payload.get("reference_fopt", math.nan)),
                    0.0,
                )
                if not _close(recomputed_error, float(payload.get("final_error", math.nan))):
                    errors.append("final_error disagrees with best_objective-reference_fopt")
                if not args.skip_hashes:
                    raw_hash = _sha256(raw_path)
            except Exception as exc:  # noqa: BLE001
                errors.append(f"raw parse/validation error: {type(exc).__name__}: {exc}")

        if trajectory_path is not None:
            try:
                trajectory_rows, trajectory_end, trajectory_best, monotonic = _read_trajectory(
                    trajectory_path
                )
                if trajectory_end != budget:
                    errors.append(f"trajectory endpoint={trajectory_end}, expected={budget}")
                if not monotonic:
                    errors.append("best-so-far trajectory is not monotonic")
                stored_rows = int(payload.get("trajectory_policy", {}).get("stored_rows", -1))
                if trajectory_rows != stored_rows:
                    errors.append(
                        f"trajectory rows={trajectory_rows}, payload stored_rows={stored_rows}"
                    )
                if payload and not _close(trajectory_best, float(payload["best_objective"])):
                    errors.append("trajectory final best disagrees with raw best_objective")
                if not args.skip_hashes:
                    trajectory_hash = _sha256(trajectory_path)
            except Exception as exc:  # noqa: BLE001
                errors.append(f"trajectory parse/validation error: {type(exc).__name__}: {exc}")

        summary_key = (algorithm, function, dimension, instance, seed)
        summary_row = summary.get(summary_key)
        if summary_row is None:
            errors.append("missing summary row")
        elif payload:
            for field in (
                "evaluation_budget",
                "evaluations",
                "framework_native_evaluations",
                "best_objective",
                "reference_fopt",
                "final_error",
                "elapsed_seconds",
            ):
                if not _close(float(summary_row[field]), float(payload[field])):
                    errors.append(f"summary {field} disagrees with raw payload")

        rows.append(
            {
                "stem": stem,
                "algorithm": algorithm,
                "function": function,
                "dimension": dimension,
                "instance": instance,
                "seed": seed,
                "budget": budget,
                "trajectory_rows": trajectory_rows,
                "trajectory_endpoint": trajectory_end,
                "raw_sha256": raw_hash,
                "trajectory_sha256": trajectory_hash,
                "status": "passed" if not errors else "failed",
                "errors": " | ".join(errors),
            }
        )

    extra_raw = sorted(set(actual_raw) - set(expected))
    extra_trajectory = sorted(set(actual_trajectory) - set(expected))
    failed_units = sum(row["status"] == "failed" for row in rows)
    global_errors.extend(f"unexpected raw artifact: {stem}" for stem in extra_raw)
    global_errors.extend(f"unexpected trajectory artifact: {stem}" for stem in extra_trajectory)
    if len(summary) != len(expected):
        global_errors.append(f"summary rows={len(summary)}, expected={len(expected)}")
    if not (
        status.get("completed_runs") == len(expected)
        and status.get("failed_runs") == 0
        and status.get("state") == "complete"
        and status.get("total_runs") == len(expected)
    ):
        global_errors.append(f"status file is not complete/zero-failure: {status}")

    passed = failed_units == 0 and not global_errors
    summary_payload = {
        "audit_schema_version": 1,
        "config": str(config_path.relative_to(ROOT)),
        "namespace": namespace,
        "expected_runs": len(expected),
        "raw_files": len(actual_raw),
        "trajectory_files": len(actual_trajectory),
        "summary_rows": len(summary),
        "passed_runs": len(rows) - failed_units,
        "failed_runs": failed_units,
        "extra_raw": len(extra_raw),
        "extra_trajectories": len(extra_trajectory),
        "hashes_computed": not args.skip_hashes,
        "global_errors": global_errors,
        "verdict": "PASS" if passed else "FAIL",
    }
    metadata_root = ROOT / "results" / "metadata"
    atomic_csv(metadata_root / f"{namespace}_manifest_audit.csv", rows, overwrite=True)
    atomic_json(metadata_root / f"{namespace}_manifest_audit.json", summary_payload, overwrite=True)
    report = f"""# {namespace.replace("_", " ").title()} Artifact Integrity Audit

Verdict: **{summary_payload["verdict"]}**

The audit reconstructs the frozen manifest from `{config_path.relative_to(ROOT)}` and validates
every raw JSON/trajectory pair independently of manuscript prose.

## Counts

- Expected units: {len(expected):,}
- Raw JSON / gzip trajectory / summary rows:
  {len(actual_raw):,} / {len(actual_trajectory):,} / {len(summary):,}
- Fully passed / failed units: {len(rows) - failed_units:,} / {failed_units:,}
- Unexpected raw / trajectory files: {len(extra_raw):,} / {len(extra_trajectory):,}
- SHA-256 hashes computed: {not args.skip_hashes}

## Checks

Identity and provenance fields, exact budgets and counters, termination, finite objectives,
recomputed final error, gzip readability, checkpoint ordering and endpoint, best-so-far
monotonicity, stored-row count, final trajectory value, summary agreement, and file hashes.

## Global errors

{chr(10).join(f"- {error}" for error in global_errors) if global_errors else "- None."}
"""
    _write_text_atomic(ROOT / "reports" / f"{namespace}_artifact_integrity.md", report)
    print(json.dumps(summary_payload, indent=2))
    if not passed:
        raise SystemExit(f"{namespace} artifact audit failed")


if __name__ == "__main__":
    main()
