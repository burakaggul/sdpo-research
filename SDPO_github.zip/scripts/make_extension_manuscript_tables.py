"""Render comparator-extension, validation, and target summaries as LaTeX tables."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
STATISTICS = ROOT / "results" / "statistics"
TABLES = ROOT / "results" / "tables"
OUTPUT = ROOT / "manuscript" / "tables"


def _p(value: float) -> str:
    if value < 0.001:
        exponent = int(np.floor(np.log10(value)))
        coefficient = value / (10.0**exponent)
        return f"${coefficient:.2f}\\times10^{{{exponent}}}$"
    return f"{value:.4f}"


def _write(path: Path, lines: list[str]) -> None:
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _pairwise() -> None:
    extension = pd.read_csv(STATISTICS / "extension_pairwise_holm.csv")
    validation = pd.read_csv(STATISTICS / "validation_pairwise_holm.csv")
    lines = [
        r"\begin{tabular}{rrrrrrl}",
        r"\toprule",
        r"Study & $d$ & Comparator & $\Delta$ & $r_{rb}$ & Holm $p$ & Decision \\",
        r"\midrule",
    ]
    for study, frame in (("Extension", extension), ("Validation", validation)):
        for _, row in frame.sort_values(["dimension", "comparator"]).iterrows():
            comparator = str(row["comparator"]).replace("-", r"\mbox{-}")
            decision = "Reject" if bool(row["reject_after_holm"]) else "Retain"
            lines.append(
                f"{study} & {int(row['dimension'])} & {comparator} & "
                f"{row['median_difference_focal_minus_comparator']:.3f} & "
                f"{row['rank_biserial_focal_minus_comparator']:.3f} & "
                f"{_p(float(row['holm_adjusted_p_value']))} & {decision} \\\\"
            )
        lines.append(r"\midrule")
    lines[-1] = r"\bottomrule"
    lines.append(r"\end{tabular}")
    _write(OUTPUT / "extension_validation_generated.tex", lines)


def _target() -> None:
    target_summary = pd.read_csv(TABLES / "bbob_target_summary.csv")
    ert = pd.read_csv(TABLES / "bbob_ert_by_function.csv")
    target_index = (target_summary["target"] - 1e-2).abs().argmin()
    target_value = float(target_summary.iloc[target_index]["target"])
    selected = target_summary[np.isclose(target_summary["target"], target_value)].copy()
    ert_selected = ert[np.isclose(ert["target"], target_value)].copy()
    function_ert = (
        ert_selected.groupby(["algorithm", "dimension"], sort=True)
        .agg(
            median_finite_ert=("ert_evaluations", "median"),
            functions_with_success=("successes", lambda values: int((values > 0).sum())),
        )
        .reset_index()
    )
    selected = selected.merge(function_ert, on=["algorithm", "dimension"], validate="one_to_one")
    lines = [
        r"\begin{tabular}{rlrrrr}",
        r"\toprule",
        r"$d$ & Algorithm & Successes & Runs & Functions hit & Median finite ERT \\",
        r"\midrule",
    ]
    for _, row in selected.sort_values(["dimension", "algorithm"]).iterrows():
        algorithm = str(row["algorithm"]).replace("-", r"\mbox{-}")
        median_ert = row["median_finite_ert"]
        rendered_ert = "--" if not np.isfinite(median_ert) else f"{median_ert:,.0f}"
        lines.append(
            f"{int(row['dimension'])} & {algorithm} & {int(row['successes'])} & "
            f"{int(row['runs'])} & {int(row['functions_with_success'])}/24 & "
            f"{rendered_ert} \\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    _write(OUTPUT / "target_summary_generated.tex", lines)


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    _pairwise()
    _target()
    print("wrote extension, validation, and target manuscript tables")


if __name__ == "__main__":
    main()
