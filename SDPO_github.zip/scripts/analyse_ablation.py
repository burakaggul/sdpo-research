"""Audit and analyse the frozen matched-budget SDPO ablation after completion.

This script is deliberately fail-closed: it writes no inferential output unless the runner
status is complete and every expected raw/trajectory pair passes identity, counter, endpoint,
finiteness, monotonicity, and SHA-256 checks.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import json
import math
import os
from collections import defaultdict
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any

import matplotlib
import numpy as np
import yaml
from PIL import Image

from sdpo.logging_utils import atomic_csv, atomic_json
from sdpo.statistical_analysis import holm_adjust, paired_wilcoxon

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "ablation.yaml"
STATUS = ROOT / "results" / "logs" / "ablation_bbob_status.json"
RAW = ROOT / "results" / "raw" / "ablation_bbob"
TRAJECTORIES = ROOT / "results" / "trajectories" / "ablation_bbob"
BASELINE = ROOT / "results" / "tables" / "bbob_summary.csv"
METADATA = ROOT / "results" / "metadata"
STATISTICS = ROOT / "results" / "statistics"
TABLES = ROOT / "results" / "tables"
FIGURES = ROOT / "results" / "figures"
MANUSCRIPT_TABLES = ROOT / "manuscript" / "tables"
MANUSCRIPT_FIGURES = ROOT / "manuscript" / "figures"
ALPHA = 0.05
OFFSET = 1e-12


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _expected_keys(config: dict[str, Any]) -> set[tuple[int, int, int, int, str]]:
    return {
        (int(function), int(dimension), int(instance), int(seed), algorithm)
        for function in config["functions"]
        for dimension in config["dimensions"]
        for instance in config["instances"]
        for seed in config["seeds"]
        for algorithm in config["algorithms"]
    }


def _trajectory_audit(path: Path, budget: int, best_objective: float) -> tuple[int, str]:
    previous_evaluation = 0
    previous_best = math.inf
    rows = 0
    with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != ["evaluations", "best_objective"]:
            raise ValueError(f"unexpected trajectory schema: {path}")
        for row in reader:
            evaluation = int(row["evaluations"])
            best = float(row["best_objective"])
            if evaluation <= previous_evaluation or evaluation > budget:
                raise ValueError(f"invalid trajectory evaluation order: {path}")
            if not math.isfinite(best) or best > previous_best + 1e-12:
                raise ValueError(f"invalid best-so-far trajectory: {path}")
            previous_evaluation = evaluation
            previous_best = best
            rows += 1
    if not rows or previous_evaluation != budget:
        raise ValueError(f"trajectory endpoint does not equal budget: {path}")
    if not math.isclose(previous_best, best_objective, rel_tol=1e-12, abs_tol=1e-12):
        raise ValueError(f"trajectory/raw endpoint disagreement: {path}")
    return rows, _sha256(path)


def _audit(config: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    status = json.loads(STATUS.read_text(encoding="utf-8"))
    expected = _expected_keys(config)
    if status.get("state") != "complete" or status.get("completed_runs") != len(expected):
        raise SystemExit(
            f"Ablation is not complete ({status.get('completed_runs')}/{len(expected)}; "
            f"state={status.get('state')}); no analysis output was written."
        )
    raw_paths = sorted(RAW.glob("*.json"))
    trajectory_paths = {
        path.name.removesuffix(".csv.gz"): path for path in TRAJECTORIES.glob("*.csv.gz")
    }
    if len(raw_paths) != len(expected) or len(trajectory_paths) != len(expected):
        raise SystemExit(
            f"Expected {len(expected)} raw/trajectory files; found "
            f"{len(raw_paths)}/{len(trajectory_paths)}."
        )

    audited: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []
    observed: set[tuple[int, int, int, int, str]] = set()
    for raw_path in raw_paths:
        payload = json.loads(raw_path.read_text(encoding="utf-8"))
        key = (
            int(payload["function"]),
            int(payload["dimension"]),
            int(payload["instance"]),
            int(payload["seed"]),
            payload["algorithm"],
        )
        if key not in expected or key in observed:
            raise SystemExit(f"Unexpected or duplicate ablation identity: {key}")
        observed.add(key)
        budget = 10000 * key[1]
        counters = (
            int(payload["evaluation_budget"]),
            int(payload["evaluations"]),
            int(payload["framework_native_evaluations"]),
        )
        final_error = float(payload["final_error"])
        best = float(payload["best_objective"])
        reference = float(payload["reference_fopt"])
        if (
            counters != (budget, budget, budget)
            or payload["termination_reason"] != "evaluation_budget_exhausted"
            or payload["run_type"] != "secondary_posthoc_ablation"
            or not all(math.isfinite(value) for value in (final_error, best, reference))
            or final_error < 0
            or not math.isclose(final_error, max(best - reference, 0.0), abs_tol=1e-12)
        ):
            raise SystemExit(f"Raw ablation integrity failure: {raw_path}")
        stem = raw_path.stem
        trajectory_path = trajectory_paths.get(stem)
        if trajectory_path is None:
            raise SystemExit(f"Missing trajectory for {raw_path.name}")
        stored_rows, trajectory_hash = _trajectory_audit(trajectory_path, budget, best)
        declared_rows = int(payload["trajectory_policy"]["stored_rows"])
        if stored_rows != declared_rows:
            raise SystemExit(f"Stored-row disagreement for {raw_path.name}")
        variant = payload["parameters"]["ablation_variant"]
        rows.append(
            {
                "function": key[0],
                "dimension": key[1],
                "instance": key[2],
                "seed": key[3],
                "algorithm": key[4],
                "variant": variant,
                "final_error": final_error,
                "log10_error": math.log10(final_error + OFFSET),
                "elapsed_seconds": float(payload["elapsed_seconds"]),
            }
        )
        audited.append(
            {
                "function": key[0],
                "dimension": key[1],
                "instance": key[2],
                "seed": key[3],
                "algorithm": key[4],
                "budget": budget,
                "stored_rows": stored_rows,
                "raw_sha256": _sha256(raw_path),
                "trajectory_sha256": trajectory_hash,
                "status": "PASS",
            }
        )
    if observed != expected:
        raise SystemExit(f"Ablation manifest mismatch: missing {len(expected - observed)} keys")
    return rows, audited


def _baseline_rows(config: dict[str, Any]) -> list[dict[str, Any]]:
    expected = {
        (int(function), int(dimension), int(config["instances"][0]), int(seed))
        for function in config["functions"]
        for dimension in config["dimensions"]
        for seed in config["seeds"]
    }
    rows: list[dict[str, Any]] = []
    observed: set[tuple[int, int, int, int]] = set()
    with BASELINE.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            key = (
                int(row["function"]),
                int(row["dimension"]),
                int(row["instance"]),
                int(row["seed"]),
            )
            if row["algorithm"] != "SDPO-Full" or key not in expected:
                continue
            if key in observed:
                raise SystemExit(f"Duplicate full-baseline identity: {key}")
            observed.add(key)
            error = float(row["final_error"])
            budget = 10000 * key[1]
            if (
                int(row["evaluation_budget"]) != budget
                or int(row["evaluations"]) != budget
                or int(row["framework_native_evaluations"]) != budget
                or not math.isfinite(error)
                or error < 0
            ):
                raise SystemExit(f"Invalid full-baseline row: {key}")
            rows.append(
                {
                    "function": key[0],
                    "dimension": key[1],
                    "instance": key[2],
                    "seed": key[3],
                    "algorithm": "SDPO-Full",
                    "variant": "full",
                    "final_error": error,
                    "log10_error": math.log10(error + OFFSET),
                    "elapsed_seconds": float(row["elapsed_seconds"]),
                }
            )
    if observed != expected:
        raise SystemExit(f"Full-baseline subset mismatch: missing {len(expected - observed)} keys")
    return rows


def _analyse(
    config: dict[str, Any], rows: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    grouped: dict[tuple[int, int, str], list[float]] = defaultdict(list)
    for row in rows:
        grouped[(row["dimension"], row["function"], row["variant"])].append(row["log10_error"])
    variants = [algorithm.removeprefix("SDPO-Ablation-") for algorithm in config["algorithms"]]
    medians: list[dict[str, Any]] = []
    lookup: dict[tuple[int, int, str], float] = {}
    for dimension in map(int, config["dimensions"]):
        for function in map(int, config["functions"]):
            for variant in ["full", *variants]:
                values = grouped[(dimension, function, variant)]
                if len(values) != len(config["seeds"]):
                    raise SystemExit(
                        f"Expected {len(config['seeds'])} runs for "
                        f"d{dimension}/f{function}/{variant}; found {len(values)}"
                    )
                median = float(np.median(values))
                lookup[(dimension, function, variant)] = median
                medians.append(
                    {
                        "dimension": dimension,
                        "function": function,
                        "variant": variant,
                        "n_paired_runs": len(values),
                        "median_log10_error": median,
                    }
                )

    comparisons: list[dict[str, Any]] = []
    functions = list(map(int, config["functions"]))
    for dimension in map(int, config["dimensions"]):
        interim: list[tuple[str, np.ndarray, Any]] = []
        full = np.array([lookup[(dimension, function, "full")] for function in functions])
        for variant in variants:
            ablated = np.array([lookup[(dimension, function, variant)] for function in functions])
            differences = full - ablated
            interim.append((variant, differences, paired_wilcoxon(differences)))
        adjusted = holm_adjust(np.array([result.p_value for _, _, result in interim]))
        for (variant, differences, result), adjusted_p in zip(interim, adjusted, strict=True):
            comparisons.append(
                {
                    "dimension": dimension,
                    "variant": variant,
                    "n_function_blocks": len(functions),
                    "nonzero_pairs": result.nonzero_pairs,
                    "raw_p_value": result.p_value,
                    "holm_adjusted_p_value": float(adjusted_p),
                    "reject_after_holm": bool(adjusted_p < ALPHA),
                    "median_difference_full_minus_variant": float(np.median(differences)),
                    "rank_biserial_full_minus_variant": result.rank_biserial,
                    "interpretation": (
                        "full smaller/better"
                        if result.rank_biserial < 0
                        else "variant smaller/better"
                        if result.rank_biserial > 0
                        else "neutral"
                    ),
                }
            )
    return medians, comparisons


def _write_table(rows: list[dict[str, Any]]) -> None:
    lines = [
        r"\begin{tabular}{rlrrrl}",
        r"\toprule",
        r"$d$ & Ablation & Median $\Delta$ & $r_{rb}$ & Holm $p$ & Decision \\",
        r"\midrule",
    ]
    for row in rows:
        label = row["variant"].replace("_", r"\_")
        decision = "reject" if row["reject_after_holm"] else "retain"
        lines.append(
            f"{row['dimension']} & {label} & "
            f"{row['median_difference_full_minus_variant']:.3f} & "
            f"{row['rank_biserial_full_minus_variant']:.3f} & "
            f"${row['holm_adjusted_p_value']:.2e}$ & {decision} \\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}", ""])
    target = MANUSCRIPT_TABLES / "ablation_generated.tex"
    target.write_text("\n".join(lines), encoding="utf-8")


def _write_figure(rows: list[dict[str, Any]]) -> None:
    variants = list(dict.fromkeys(row["variant"] for row in rows))
    dimensions = list(dict.fromkeys(int(row["dimension"]) for row in rows))
    y = np.arange(len(variants))
    fig, axes = plt.subplots(1, len(dimensions), figsize=(11.0, 5.8), sharey=True)
    axes = np.atleast_1d(axes)
    for axis, dimension in zip(axes, dimensions, strict=True):
        subset = {row["variant"]: row for row in rows if int(row["dimension"]) == dimension}
        effects = [
            float(subset[variant]["rank_biserial_full_minus_variant"]) for variant in variants
        ]
        colors = [
            "#0072B2" if value < 0 else "#D55E00" if value > 0 else "#777777" for value in effects
        ]
        axis.axvline(0, color="black", linewidth=0.8)
        axis.barh(y, effects, color=colors, alpha=0.8)
        for index, variant in enumerate(variants):
            if subset[variant]["reject_after_holm"]:
                axis.text(effects[index], index, " *", va="center", fontsize=10)
        axis.set_title(f"d = {dimension}")
        axis.set_xlim(-1.05, 1.05)
        axis.set_xlabel("Rank-biserial effect\n(full minus ablation)")
        axis.grid(axis="x", alpha=0.25)
    axes[0].set_yticks(y, [variant.replace("_", " ") for variant in variants])
    axes[0].invert_yaxis()
    fig.suptitle("Post-hoc matched-budget SDPO ablation effects")
    fig.text(
        0.5, 0.01, "Negative favors the full controller; * Holm-adjusted p < 0.05", ha="center"
    )
    fig.tight_layout(rect=(0, 0.05, 1, 0.95))
    for extension, kwargs in (("pdf", {}), ("svg", {}), ("png", {"dpi": 600})):
        target = FIGURES / f"fig07_ablation_effects.{extension}"
        with NamedTemporaryFile(suffix=f".{extension}", dir=target.parent, delete=False) as handle:
            temporary = Path(handle.name)
        fig.savefig(temporary, bbox_inches="tight", **kwargs)
        os.replace(temporary, target)
    (MANUSCRIPT_FIGURES / "fig07_ablation_effects.pdf").write_bytes(
        (FIGURES / "fig07_ablation_effects.pdf").read_bytes()
    )
    with Image.open(FIGURES / "fig07_ablation_effects.png") as image:
        image.convert("L").save(FIGURES / "fig07_ablation_effects_grayscale.png")
    plt.close(fig)


def main() -> None:
    config = yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    new_rows, audited = _audit(config)
    baseline_rows = _baseline_rows(config)
    medians, comparisons = _analyse(config, [*new_rows, *baseline_rows])
    METADATA.mkdir(parents=True, exist_ok=True)
    STATISTICS.mkdir(parents=True, exist_ok=True)
    TABLES.mkdir(parents=True, exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)
    atomic_csv(METADATA / "ablation_manifest_audit.csv", audited, overwrite=True)
    atomic_json(
        METADATA / "ablation_manifest_audit.json",
        {
            "verdict": "PASS",
            "expected_new_runs": len(_expected_keys(config)),
            "passed_new_runs": len(audited),
            "failed_runs": 0,
            "full_baseline_rows": len(baseline_rows),
            "analysis_status": "secondary_posthoc",
        },
        overwrite=True,
    )
    atomic_csv(STATISTICS / "ablation_function_medians.csv", medians, overwrite=True)
    atomic_csv(STATISTICS / "ablation_pairwise_wilcoxon_holm.csv", comparisons, overwrite=True)
    atomic_csv(TABLES / "ablation_summary.csv", comparisons, overwrite=True)
    atomic_csv(FIGURES / "fig07_ablation_effects_data.csv", comparisons, overwrite=True)
    _write_table(comparisons)
    _write_figure(comparisons)
    print(
        f"ablation audit/analysis PASS: {len(audited)} new runs, "
        f"{len(medians)} function medians, {len(comparisons)} comparisons"
    )


if __name__ == "__main__":
    main()
