"""Correct a metadata-only legacy label in completed SDPO-R1 validation records."""

from __future__ import annotations

import json
from pathlib import Path

from sdpo.logging_utils import atomic_json

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "results" / "raw" / "validation_bbob_largescale"
OLD = "R1 frozen before bbob-noisy validation"
NEW = "R1 frozen before untouched external validation"


def main() -> None:
    changed = 0
    for path in sorted(RAW.glob("sdpo_r1_*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        if payload.get("parameters", {}).get("revision") == OLD:
            payload["parameters"]["revision"] = NEW
            atomic_json(path, payload, overwrite=True)
            changed += 1
    print(f"normalized {changed} completed SDPO-R1 provenance labels")


if __name__ == "__main__":
    main()
