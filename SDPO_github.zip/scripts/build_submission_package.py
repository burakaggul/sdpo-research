"""Build and verify the single-manuscript MDPI source package."""

from __future__ import annotations

import hashlib
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANUSCRIPT = ROOT / "manuscript"
SUBMISSION = ROOT / "submission"
STAGE = SUBMISSION / "_stage_single_manuscript_2026-08-03"
ARCHIVE = SUBMISSION / "SDPO_single_manuscript_draft_2026-08-03.zip"

ROOT_FILES = (
    "main.tex",
    "main.pdf",
    "main.bbl",
    "references.bib",
    "submission_metadata.yaml",
    "submission_package_README.md",
    "mdpi_final_checklist.md",
    "author_input_required.md",
    "cover_letter_draft.md",
    "highlights_draft.md",
    "response_to_reviewers_template.md",
)
TREE_NAMES = ("Definitions", "sections", "tables", "figures")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    missing = [name for name in ROOT_FILES if not (MANUSCRIPT / name).is_file()]
    missing.extend(name for name in TREE_NAMES if not (MANUSCRIPT / name).is_dir())
    if missing:
        raise SystemExit(f"missing package inputs: {missing}")

    if STAGE.exists():
        resolved = STAGE.resolve()
        if resolved.parent != SUBMISSION.resolve() or not resolved.name.startswith("_stage_"):
            raise SystemExit(f"refusing to replace unsafe staging path: {resolved}")
        shutil.rmtree(resolved)
    STAGE.mkdir(parents=True)

    for name in ROOT_FILES:
        shutil.copy2(MANUSCRIPT / name, STAGE / name)
    for name in TREE_NAMES:
        ignored = (
            shutil.ignore_patterns("method_results_pending.md", "proposed_sdpo.tex")
            if name == "sections"
            else None
        )
        shutil.copytree(MANUSCRIPT / name, STAGE / name, ignore=ignored)

    excluded = [path for path in STAGE.rglob("*") if "supplement" in path.name.lower()]
    if excluded:
        raise SystemExit(f"supplementary artifact entered single-manuscript stage: {excluded}")
    pdfs = sorted(path.relative_to(STAGE).as_posix() for path in STAGE.rglob("*.pdf"))
    if "main.pdf" not in pdfs or pdfs.count("main.pdf") != 1:
        raise SystemExit("stage must contain exactly one main manuscript PDF")

    if ARCHIVE.exists():
        ARCHIVE.unlink()
    with zipfile.ZipFile(ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(item for item in STAGE.rglob("*") if item.is_file()):
            zf.write(path, path.relative_to(STAGE).as_posix())

    with zipfile.ZipFile(ARCHIVE) as zf:
        names = zf.namelist()
        bad = [name for name in names if "supplement" in name.lower()]
        if bad or names.count("main.pdf") != 1 or names.count("main.tex") != 1:
            raise SystemExit(f"archive verification failed: bad={bad}")

    manifest = SUBMISSION / "package_manifest_2026-08-03.md"
    manifest.write_text(
        "\n".join(
            [
                "# SDPO Single-Manuscript Package Manifest",
                "",
                f"- Archive: `{ARCHIVE.name}`",
                f"- SHA-256: `{_sha256(ARCHIVE)}`",
                f"- Bytes: {ARCHIVE.stat().st_size:,}",
                f"- Entries: {len(names):,}",
                f"- PDF entries: {len(pdfs):,} (one manuscript plus vector figures)",
                "- Separate supplementary artifacts: 0",
                "- Official MDPI class directory included: yes",
                "",
                "The former supplementary scientific material is integrated into the normal "
                "article flow.",
                "Author identity, repository DOI, and other author-controlled metadata remain "
                "explicit gates.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(f"built {ARCHIVE} ({len(names)} entries, sha256={_sha256(ARCHIVE)})")


if __name__ == "__main__":
    main()
