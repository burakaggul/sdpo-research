raise SystemExit("Ablation is gated until verified benchmark integrations pass their pilots.")
