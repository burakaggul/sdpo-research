"""Calibrate per-evaluation runtime and bounded trajectory storage on official BBOB."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import yaml

from sdpo.benchmark_adapters import CocoBbobAdapter
from sdpo.competitors import (
    cma_es,
    differential_evolution_rand1bin,
    random_search,
    sdpo_full,
)
from sdpo.logging_utils import atomic_csv
from sdpo.trajectory import checkpoint_evaluations, sample_best_so_far

ROOT = Path(__file__).resolve().parents[1]
ALGORITHMS = {
    "Random-Search": random_search,
    "DE-rand-1-bin": differential_evolution_rand1bin,
    "CMA-ES": cma_es,
    "SDPO-Full": sdpo_full,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config", type=Path, default=ROOT / "configs" / "cost_calibration_bbob.yaml"
    )
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = args.config if args.config.is_absolute() else ROOT / args.config
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    budget = int(config["evaluation_budget"])
    population_size = int(config["population_size"])
    policy = config["trajectory_policy"]
    checkpoints = checkpoint_evaluations(
        budget,
        dense_prefix=int(policy["dense_prefix"]),
        logarithmic_points=int(policy["logarithmic_points"]),
    )
    table_path = ROOT / "results" / "tables" / "benchmark_cost_calibration.csv"
    trajectory_root = ROOT / "results" / "trajectories" / "cost_calibration"
    expected_runs = len(config["dimensions"]) * len(config["algorithms"]) * len(config["seeds"])
    if table_path.exists() and not args.force:
        with table_path.open(encoding="utf-8", newline="") as handle:
            existing = list(csv.DictReader(handle))
        trajectories = list(trajectory_root.glob("*.csv"))
        if len(existing) != expected_runs or len(trajectories) != expected_runs:
            raise RuntimeError("incomplete calibration artifacts; inspect before using --force")
        for row in existing:
            if (
                int(row["evaluations"]) != budget
                or int(row["framework_native_evaluations"]) != budget
                or row["termination_reason"] != "evaluation_budget_exhausted"
            ):
                raise RuntimeError("incompatible calibration artifact")
        print(f"resume: verified and skipped {expected_runs} calibration runs")
        return
    rows: list[dict[str, object]] = []
    for dimension in map(int, config["dimensions"]):
        for algorithm_name in config["algorithms"]:
            algorithm = ALGORITHMS[str(algorithm_name)]
            for seed in map(int, config["seeds"]):
                adapter = CocoBbobAdapter(
                    int(config["function"]), dimension, int(config["instance"])
                )
                try:
                    result = algorithm(
                        adapter,
                        adapter.lower,
                        adapter.upper,
                        budget,
                        seed,
                        population_size=population_size,
                    )
                    if result.evaluations != budget or adapter.native_evaluations != budget:
                        raise AssertionError("calibration evaluation counters diverged")
                finally:
                    adapter.close()
                sampled = sample_best_so_far(result.trajectory, checkpoints)
                stem = f"{algorithm_name.lower().replace('-', '_')}_d{dimension}_s{seed}.csv"
                atomic_csv(trajectory_root / stem, sampled, overwrite=args.force)
                rows.append(
                    {
                        "framework": "COCO/BBOB",
                        "function": int(config["function"]),
                        "dimension": dimension,
                        "algorithm": algorithm_name,
                        "seed": seed,
                        "evaluation_budget": budget,
                        "evaluations": result.evaluations,
                        "framework_native_evaluations": budget,
                        "elapsed_seconds": result.elapsed_seconds,
                        "microseconds_per_evaluation": result.elapsed_seconds * 1e6 / budget,
                        "full_trajectory_rows": len(result.trajectory),
                        "stored_trajectory_rows": len(sampled),
                        "termination_reason": result.termination_reason,
                    }
                )
                print(f"calibrated {algorithm_name} D={dimension} seed={seed}")
    atomic_csv(
        table_path,
        rows,
        overwrite=True,
    )
    print(f"cost calibration complete: {len(rows)} exact-budget runs")


if __name__ == "__main__":
    main()
