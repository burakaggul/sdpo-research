"""Regenerate preregistered confirmatory statistics from audited BBOB results."""

from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import yaml

from sdpo.logging_utils import atomic_csv
from sdpo.statistical_analysis import aligned_friedman, holm_adjust, paired_wilcoxon

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs" / "bbob.yaml"
SUMMARY = ROOT / "results" / "tables" / "bbob_summary.csv"
AUDIT = ROOT / "results" / "metadata" / "bbob_manifest_audit.json"
OUTPUT = ROOT / "results" / "statistics"
ALPHA = 0.05
OFFSET = 1e-12


def _load_inputs() -> tuple[dict[str, Any], list[dict[str, str]]]:
    audit = json.loads(AUDIT.read_text(encoding="utf-8"))
    if audit.get("verdict") != "PASS" or audit.get("passed_runs") != audit.get("expected_runs"):
        raise SystemExit("Artifact audit is not PASS; confirmatory inference remains blocked.")
    config = yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    with SUMMARY.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    expected = (
        len(config["functions"])
        * len(config["dimensions"])
        * len(config["instances"])
        * len(config["seeds"])
        * len(config["algorithms"])
    )
    if len(rows) != expected:
        raise SystemExit(f"Expected {expected} summary rows, found {len(rows)}.")
    return config, rows


def _aggregate(config: dict[str, Any], rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[int, int, str], list[float]] = defaultdict(list)
    identities: set[tuple[int, int, int, int, str]] = set()
    for row in rows:
        identity = (
            int(row["function"]),
            int(row["dimension"]),
            int(row["instance"]),
            int(row["seed"]),
            row["algorithm"],
        )
        if identity in identities:
            raise SystemExit(f"Duplicate paired-run identity: {identity}")
        identities.add(identity)
        error = float(row["final_error"])
        if not math.isfinite(error) or error < 0:
            raise SystemExit(f"Invalid final error for {identity}: {error}")
        grouped[(identity[0], identity[1], identity[4])].append(math.log10(error + OFFSET))

    expected_repeats = len(config["instances"]) * len(config["seeds"])
    aggregated: list[dict[str, Any]] = []
    for dimension in map(int, config["dimensions"]):
        for function in map(int, config["functions"]):
            for algorithm in config["algorithms"]:
                values = grouped[(function, dimension, algorithm)]
                if len(values) != expected_repeats:
                    raise SystemExit(
                        f"Expected {expected_repeats} paired runs for "
                        f"f{function}/d{dimension}/{algorithm}, found {len(values)}."
                    )
                aggregated.append(
                    {
                        "dimension": dimension,
                        "function": function,
                        "algorithm": algorithm,
                        "n_runs": len(values),
                        "median_log10_error": float(np.median(values)),
                    }
                )
    return aggregated


def _analyse(
    config: dict[str, Any], aggregated: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    lookup = {
        (row["dimension"], row["function"], row["algorithm"]): row["median_log10_error"]
        for row in aggregated
    }
    algorithms = list(config["algorithms"])
    functions = list(map(int, config["functions"]))
    omnibus_rows: list[dict[str, Any]] = []
    pairwise_rows: list[dict[str, Any]] = []

    for dimension in map(int, config["dimensions"]):
        matrix = np.array(
            [
                [lookup[(dimension, function, algorithm)] for algorithm in algorithms]
                for function in functions
            ],
            dtype=float,
        )
        omnibus = aligned_friedman(matrix)
        omnibus_rows.append(
            {
                "dimension": dimension,
                "n_function_blocks": len(functions),
                "n_algorithms": len(algorithms),
                "statistic": omnibus.statistic,
                "degrees_of_freedom": omnibus.degrees_of_freedom,
                "p_value": omnibus.p_value,
                "alpha": ALPHA,
                "reject_null": omnibus.p_value < ALPHA,
                **{
                    f"aligned_rank_sum__{algorithm}": rank_sum
                    for algorithm, rank_sum in zip(
                        algorithms, omnibus.aligned_rank_sums_by_treatment, strict=True
                    )
                },
            }
        )
        if omnibus.p_value >= ALPHA:
            continue

        sdpo = matrix[:, algorithms.index("SDPO-Full")]
        comparisons: list[tuple[str, np.ndarray, Any]] = []
        for comparator in algorithms:
            if comparator == "SDPO-Full":
                continue
            differences = sdpo - matrix[:, algorithms.index(comparator)]
            comparisons.append((comparator, differences, paired_wilcoxon(differences)))
        adjusted = holm_adjust(np.array([item[2].p_value for item in comparisons]))
        for (comparator, differences, result), adjusted_p in zip(
            comparisons, adjusted, strict=True
        ):
            effect_direction = (
                "SDPO larger/worse"
                if result.rank_biserial > 0
                else "SDPO smaller/better"
                if result.rank_biserial < 0
                else "neutral"
            )
            pairwise_rows.append(
                {
                    "dimension": dimension,
                    "comparator": comparator,
                    "n_function_blocks": len(functions),
                    "nonzero_pairs": result.nonzero_pairs,
                    "wilcoxon_statistic": result.statistic,
                    "raw_p_value": result.p_value,
                    "holm_adjusted_p_value": float(adjusted_p),
                    "alpha": ALPHA,
                    "reject_after_holm": adjusted_p < ALPHA,
                    "median_difference_sdpo_minus_comparator": float(np.median(differences)),
                    "rank_biserial_sdpo_minus_comparator": result.rank_biserial,
                    "positive_rank_sum": result.positive_rank_sum,
                    "negative_rank_sum": result.negative_rank_sum,
                    "effect_direction": effect_direction,
                }
            )
    return omnibus_rows, pairwise_rows


def _write_report(
    aggregated: list[dict[str, Any]],
    omnibus: list[dict[str, Any]],
    pairwise: list[dict[str, Any]],
) -> None:
    lines = [
        "# Preregistered BBOB Statistical Report",
        "",
        "Status: regenerated from the artifact-audited confirmatory summary.",
        "",
        f"Primary transform: `log10(final_error + {OFFSET:g})`; alpha: {ALPHA}.",
        "Each algorithm is represented by its median over 30 runs within each of 24 function",
        "blocks per dimension. Lower values are better.",
        "",
        "## Aligned Friedman omnibus tests",
        "",
        "| d | statistic | df | p | reject |",
        "|---:|---:|---:|---:|:---:|",
    ]
    for row in omnibus:
        lines.append(
            f"| {row['dimension']} | {row['statistic']:.6g} | "
            f"{row['degrees_of_freedom']} | {row['p_value']:.6g} | "
            f"{str(row['reject_null']).lower()} |"
        )
    lines.extend(
        [
            "",
            "## SDPO pairwise Wilcoxon tests",
            "",
            "Differences and rank-biserial effects are signed as SDPO minus comparator;",
            "negative values favor SDPO because lower log-error is better.",
            "",
            "| d | comparator | raw p | Holm p | median diff. | rank-biserial | decision |",
            "|---:|:---|---:|---:|---:|---:|:---:|",
        ]
    )
    for row in pairwise:
        lines.append(
            f"| {row['dimension']} | {row['comparator']} | {row['raw_p_value']:.6g} | "
            f"{row['holm_adjusted_p_value']:.6g} | "
            f"{row['median_difference_sdpo_minus_comparator']:.6g} | "
            f"{row['rank_biserial_sdpo_minus_comparator']:.6g} | "
            f"{'reject' if row['reject_after_holm'] else 'retain'} |"
        )
    lines.extend(
        [
            "",
            "## Reproducibility boundary",
            "",
            f"The function-median file contains {len(aggregated)} rows. Wilcoxon uses the",
            "Wilcox zero convention and SciPy's deterministic `method='auto'`; Holm correction",
            "is applied to the three SDPO comparisons separately within each dimension.",
            "No across-dimension pooled inference is reported.",
            "",
        ]
    )
    (OUTPUT / "statistical_report.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    config, rows = _load_inputs()
    aggregated = _aggregate(config, rows)
    omnibus, pairwise = _analyse(config, aggregated)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    atomic_csv(OUTPUT / "function_median_log_error.csv", aggregated, overwrite=True)
    atomic_csv(OUTPUT / "aligned_friedman.csv", omnibus, overwrite=True)
    atomic_csv(OUTPUT / "pairwise_wilcoxon_holm.csv", pairwise, overwrite=True)
    _write_report(aggregated, omnibus, pairwise)
    print(
        f"statistics regenerated: {len(aggregated)} function medians, "
        f"{len(omnibus)} omnibus tests, {len(pairwise)} pairwise tests"
    )


if __name__ == "__main__":
    main()
