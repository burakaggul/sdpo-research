"""Analyse the paired modern-comparator extension and untouched validation."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from sdpo.statistical_analysis import aligned_friedman, holm_adjust, paired_wilcoxon

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "results" / "tables"
STATISTICS = ROOT / "results" / "statistics"
FIGURES = ROOT / "results" / "figures"
OFFSET = 1e-12
ALPHA = 0.05


def _require_complete(status_name: str, expected: int) -> None:
    path = ROOT / "results" / "logs" / status_name
    status = json.loads(path.read_text(encoding="utf-8"))
    if (
        status.get("state") != "complete"
        or status.get("completed_runs") != expected
        or status.get("failed_runs") != 0
        or status.get("total_runs") != expected
    ):
        raise SystemExit(f"incomplete experiment: {path.name}: {status}")


def _prepare_extension() -> pd.DataFrame:
    primary = pd.read_csv(TABLES / "bbob_summary.csv")
    primary = primary[
        primary["instance"].isin([1, 2, 3])
        & primary["seed"].isin([20260718, 20260719, 20260720, 20260721])
    ]
    extension = pd.read_csv(TABLES / "extension_bbob_summary.csv")
    combined = pd.concat([primary, extension], ignore_index=True)
    identity = ["function", "dimension", "instance", "seed", "algorithm"]
    if combined.duplicated(identity).any():
        raise SystemExit("duplicate comparator-extension identities")
    combined["log_error"] = np.log10(combined["final_error"].clip(lower=0.0) + OFFSET)
    expected_algorithms = {
        "Random-Search",
        "DE-rand-1-bin",
        "CMA-ES-Restart",
        "SDPO-Full",
        "L-SHADE",
        "RecPM-AOS-DE",
    }
    if set(combined["algorithm"]) != expected_algorithms or len(combined) != 6912:
        raise SystemExit("unexpected comparator-extension design")
    return combined


def _prepare_validation() -> pd.DataFrame:
    validation = pd.read_csv(TABLES / "validation_bbob_largescale_summary.csv")
    identity = ["function", "dimension", "instance", "seed", "algorithm"]
    expected_algorithms = {"SDPO-Full", "SDPO-R1", "L-SHADE", "RecPM-AOS-DE"}
    if (
        validation.duplicated(identity).any()
        or len(validation) != 1152
        or set(validation["algorithm"]) != expected_algorithms
        or set(validation["dimension"]) != {80}
    ):
        raise SystemExit("unexpected validation identities")
    validation["log_error"] = np.log10(validation["final_error"].clip(lower=0.0) + OFFSET)
    return validation


def _function_medians(data: pd.DataFrame, expected_runs: int) -> pd.DataFrame:
    medians = (
        data.groupby(["dimension", "function", "algorithm"], sort=True)
        .agg(n_runs=("log_error", "size"), median_log10_error=("log_error", "median"))
        .reset_index()
    )
    if not (medians["n_runs"] == expected_runs).all():
        raise SystemExit("function medians do not have the expected paired run count")
    return medians


def _nonparametric(medians: pd.DataFrame, focal: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    omnibus_rows: list[dict[str, object]] = []
    pairwise_rows: list[dict[str, object]] = []
    for dimension, dimension_data in medians.groupby("dimension", sort=True):
        matrix_frame = dimension_data.pivot(
            index="function", columns="algorithm", values="median_log10_error"
        ).sort_index()
        algorithms = sorted(matrix_frame.columns)
        matrix = matrix_frame[algorithms].to_numpy(dtype=float)
        omnibus = aligned_friedman(matrix)
        omnibus_rows.append(
            {
                "dimension": int(dimension),
                "n_function_blocks": int(matrix.shape[0]),
                "n_algorithms": int(matrix.shape[1]),
                "statistic": omnibus.statistic,
                "degrees_of_freedom": omnibus.degrees_of_freedom,
                "p_value": omnibus.p_value,
                "reject_null": omnibus.p_value < ALPHA,
            }
        )
        focal_values = matrix_frame[focal].to_numpy(dtype=float)
        comparisons = []
        for comparator in algorithms:
            if comparator == focal:
                continue
            differences = focal_values - matrix_frame[comparator].to_numpy(dtype=float)
            comparisons.append((comparator, differences, paired_wilcoxon(differences)))
        adjusted = holm_adjust(np.asarray([item[2].p_value for item in comparisons]))
        for (comparator, differences, result), adjusted_p in zip(
            comparisons, adjusted, strict=True
        ):
            pairwise_rows.append(
                {
                    "dimension": int(dimension),
                    "focal": focal,
                    "comparator": comparator,
                    "n_function_blocks": int(matrix.shape[0]),
                    "median_difference_focal_minus_comparator": float(np.median(differences)),
                    "rank_biserial_focal_minus_comparator": result.rank_biserial,
                    "raw_p_value": result.p_value,
                    "holm_adjusted_p_value": float(adjusted_p),
                    "reject_after_holm": bool(adjusted_p < ALPHA),
                }
            )
    return pd.DataFrame(omnibus_rows), pd.DataFrame(pairwise_rows)


def _plot_effects(pairwise: pd.DataFrame, path: Path, title: str, focal_label: str) -> None:
    dimensions = sorted(pairwise["dimension"].unique())
    figure, axes = plt.subplots(1, len(dimensions), figsize=(3.8 * len(dimensions), 3.8))
    axes_array = np.atleast_1d(axes)
    for axis, dimension in zip(axes_array, dimensions, strict=True):
        subset = pairwise[pairwise["dimension"] == dimension].sort_values("comparator")
        y = np.arange(len(subset))
        values = subset["rank_biserial_focal_minus_comparator"].to_numpy()
        colors = np.where(values < 0, "#2b8cbe", "#e67e22")
        axis.barh(y, values, color=colors)
        axis.axvline(0.0, color="black", linewidth=0.8)
        axis.set_yticks(y, subset["comparator"])
        axis.set_xlim(-1.0, 1.0)
        axis.set_title(f"d = {dimension}")
        for index, (_, row) in enumerate(subset.iterrows()):
            if row["reject_after_holm"]:
                axis.text(values[index], index, " *", va="center")
        axis.grid(axis="x", alpha=0.25)
    figure.suptitle(title)
    figure.supxlabel(
        f"Rank-biserial effect ({focal_label} minus comparator); negative favors focal"
    )
    figure.tight_layout()
    for suffix in ("pdf", "svg"):
        figure.savefig(path.with_suffix(f".{suffix}"), bbox_inches="tight")
    figure.savefig(path.with_suffix(".png"), dpi=600, bbox_inches="tight")
    plt.close(figure)


def _write_report(
    extension_omnibus: pd.DataFrame,
    extension_pairwise: pd.DataFrame,
    validation_omnibus: pd.DataFrame,
    validation_pairwise: pd.DataFrame,
) -> None:
    lines = [
        "# Comparator Extension and Untouched Validation",
        "",
        "The comparator extension uses the paired subset of instances 1--3 and seeds",
        "20260718--20260721 (12 runs per function/algorithm). The untouched validation",
        "uses COCO/BBOB-LargeScale at d=80, instances 1--3, four new seeds, and 2,000d",
        "evaluations. Function medians are the inferential blocks.",
        "",
        "## Omnibus tests",
        "",
        "| study | d | algorithms | statistic | p |",
        "|:--|--:|--:|--:|--:|",
    ]
    for study, frame in (
        ("extension", extension_omnibus),
        ("validation", validation_omnibus),
    ):
        for _, row in frame.iterrows():
            lines.append(
                f"| {study} | {int(row['dimension'])} | {int(row['n_algorithms'])} | "
                f"{row['statistic']:.6g} | {row['p_value']:.6g} |"
            )
    lines.extend(["", "## Holm-controlled focal comparisons", ""])
    for label, frame in (
        ("SDPO-Full extension", extension_pairwise),
        ("SDPO-R1 validation", validation_pairwise),
    ):
        lines.extend(
            [
                f"### {label}",
                "",
                "| d | comparator | median difference | rank-biserial | Holm p | decision |",
                "|--:|:--|--:|--:|--:|:--:|",
            ]
        )
        for _, row in frame.iterrows():
            lines.append(
                f"| {int(row['dimension'])} | {row['comparator']} | "
                f"{row['median_difference_focal_minus_comparator']:.6g} | "
                f"{row['rank_biserial_focal_minus_comparator']:.6g} | "
                f"{row['holm_adjusted_p_value']:.6g} | "
                f"{'reject' if row['reject_after_holm'] else 'retain'} |"
            )
        lines.append("")
    (ROOT / "reports" / "extension_validation_report.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> None:
    _require_complete("extension_bbob_status.json", 2304)
    _require_complete("validation_bbob_largescale_status.json", 1152)
    STATISTICS.mkdir(parents=True, exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)
    extension = _function_medians(_prepare_extension(), expected_runs=12)
    validation = _function_medians(_prepare_validation(), expected_runs=12)
    extension_omnibus, extension_pairwise = _nonparametric(extension, "SDPO-Full")
    validation_omnibus, validation_pairwise = _nonparametric(validation, "SDPO-R1")
    extension.to_csv(STATISTICS / "extension_function_medians.csv", index=False)
    extension_omnibus.to_csv(STATISTICS / "extension_aligned_friedman.csv", index=False)
    extension_pairwise.to_csv(STATISTICS / "extension_pairwise_holm.csv", index=False)
    validation.to_csv(STATISTICS / "validation_function_medians.csv", index=False)
    validation_omnibus.to_csv(STATISTICS / "validation_aligned_friedman.csv", index=False)
    validation_pairwise.to_csv(STATISTICS / "validation_pairwise_holm.csv", index=False)
    _plot_effects(
        extension_pairwise,
        FIGURES / "fig09_modern_comparator_effects",
        "Modern-comparator extension",
        "SDPO-Full",
    )
    _plot_effects(
        validation_pairwise,
        FIGURES / "fig10_untouched_validation_effects",
        "Untouched BBOB-LargeScale validation",
        "SDPO-R1",
    )
    _write_report(
        extension_omnibus,
        extension_pairwise,
        validation_omnibus,
        validation_pairwise,
    )
    print(f"extension/validation analysis complete: {len(extension)} + {len(validation)} medians")


if __name__ == "__main__":
    main()
