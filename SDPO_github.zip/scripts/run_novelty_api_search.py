"""Run reproducible Crossref and OpenAlex novelty searches.

The script preserves provider responses and a compact screening table. It does not infer
novelty from a zero-result query; manual title/abstract/full-text screening remains required.
"""

from __future__ import annotations

import csv
import json
import time
import urllib.parse
import urllib.request
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
QUERY_FILE = ROOT / "literature" / "novelty_queries.csv"
OUTPUT_DIR = ROOT / "literature" / "search_exports" / "2026-08-03"
USER_AGENT = "SDPO-novelty-audit/1.0 (reproducible academic search)"


def fetch_json(url: str) -> dict:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=45) as response:
        return json.load(response)


def crossref_search(query: str) -> dict:
    params = urllib.parse.urlencode(
        {
            "query.bibliographic": query,
            "rows": 10,
            "select": "DOI,title,author,published,container-title,URL,type,score",
        }
    )
    return fetch_json(f"https://api.crossref.org/works?{params}")


def openalex_search(query: str) -> dict:
    params = urllib.parse.urlencode({"search": query, "per-page": 10})
    return fetch_json(f"https://api.openalex.org/works?{params}")


def title_of(item: dict) -> str:
    title = item.get("title") or item.get("display_name") or ""
    if isinstance(title, list):
        return title[0] if title else ""
    return str(title)


def doi_of(item: dict) -> str:
    doi = item.get("DOI") or item.get("doi") or ""
    return str(doi).removeprefix("https://doi.org/")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    with QUERY_FILE.open(encoding="utf-8-sig", newline="") as handle:
        queries = list(csv.DictReader(handle))

    executed_at = datetime.now(UTC).isoformat()
    raw: dict[str, dict] = {"executed_at_utc": executed_at, "queries": {}}
    compact: list[dict[str, str | int | float]] = []

    for row in queries:
        query_id = row["query_id"]
        query = row["query"]
        record: dict[str, object] = {"query": query}
        for provider, search in (("Crossref", crossref_search), ("OpenAlex", openalex_search)):
            try:
                result = search(query)
                record[provider] = result
                items = (
                    result.get("message", {}).get("items", [])
                    if provider == "Crossref"
                    else result.get("results", [])
                )
                for rank, item in enumerate(items, start=1):
                    compact.append(
                        {
                            "query_id": query_id,
                            "query": query,
                            "provider": provider,
                            "rank": rank,
                            "title": title_of(item),
                            "doi": doi_of(item),
                            "year": (
                                item.get("publication_year", "")
                                if provider == "OpenAlex"
                                else (item.get("published", {}).get("date-parts", [[""]])[0][0])
                            ),
                            "score": item.get("score", item.get("relevance_score", "")),
                            "url": item.get("URL", item.get("id", "")),
                            "screening_decision": "pending_manual_screen",
                        }
                    )
            except Exception as exc:  # fail visibly but preserve other provider results
                record[provider] = {"error": f"{type(exc).__name__}: {exc}"}
            time.sleep(0.15)
        raw["queries"][query_id] = record

    (OUTPUT_DIR / "provider_responses.json").write_text(
        json.dumps(raw, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    fieldnames = [
        "query_id",
        "query",
        "provider",
        "rank",
        "title",
        "doi",
        "year",
        "score",
        "url",
        "screening_decision",
    ]
    with (OUTPUT_DIR / "combined_results.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(compact)

    summary = {
        "executed_at_utc": executed_at,
        "queries": len(queries),
        "providers": ["Crossref", "OpenAlex"],
        "result_rows": len(compact),
        "provider_errors": sum(
            1
            for record in raw["queries"].values()
            for provider in ("Crossref", "OpenAlex")
            if "error" in record.get(provider, {})
        ),
        "manual_screening_complete": False,
    }
    (OUTPUT_DIR / "search_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
