"""Run resumable, small-budget development functions and write traceable evidence."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import yaml

from sdpo.core import SDPOConfig, optimize
from sdpo.logging_utils import atomic_csv, atomic_json
from sdpo.objectives import DEVELOPMENT_FUNCTIONS
from sdpo.reproducibility import runtime_metadata
from sdpo.validation import validate_result

ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "laptop.yaml")
    parser.add_argument("--force", action="store_true", help="replace existing smoke outputs")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = args.config if args.config.is_absolute() else ROOT / args.config
    laptop = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    smoke = laptop["smoke"]
    dimension = int(smoke["dimension"])
    population_size = int(smoke["population_size"])
    budget = int(smoke["evaluation_budget"])
    summary: list[dict[str, object]] = []
    replay_checked = False

    for name, (objective, lower_scalar, upper_scalar) in DEVELOPMENT_FUNCTIONS.items():
        lower = np.full(dimension, lower_scalar)
        upper = np.full(dimension, upper_scalar)
        for seed in smoke["seeds"]:
            seed = int(seed)
            raw_path = ROOT / "results" / "raw" / f"smoke_{name}_d{dimension}_s{seed}.json"
            trajectory_path = (
                ROOT / "results" / "trajectories" / f"smoke_{name}_d{dimension}_s{seed}.csv"
            )
            diagnostic_path = (
                ROOT / "results" / "logs" / f"smoke_{name}_d{dimension}_s{seed}_diagnostics.csv"
            )
            if (
                raw_path.exists()
                and trajectory_path.exists()
                and diagnostic_path.exists()
                and not args.force
            ):
                existing = json.loads(raw_path.read_text(encoding="utf-8"))
                if existing["evaluations"] != budget:
                    raise RuntimeError(f"existing result has incompatible budget: {raw_path}")
                summary.append(existing["summary_row"])
                print(f"resume: verified and skipped {raw_path.name}")
                continue
            run_config = SDPOConfig(
                population_size=population_size,
                evaluation_budget=budget,
                seed=seed,
                graph_k=min(4, population_size - 1),
            )
            result = optimize(objective, lower, upper, run_config)
            validate_result(result, lower, upper, budget)
            if not replay_checked:
                replay = optimize(objective, lower, upper, run_config)
                if (
                    result.best_objective != replay.best_objective
                    or not np.array_equal(result.final_population, replay.final_population)
                    or [p.best_objective for p in result.trajectory]
                    != [p.best_objective for p in replay.trajectory]
                ):
                    raise AssertionError("same-seed deterministic replay failed")
                replay_checked = True
            operators = [str(row["operator"]) for row in result.diagnostics]
            summary_row = {
                "function": name,
                "dimension": dimension,
                "seed": seed,
                "budget": budget,
                "evaluations": result.evaluations,
                "best_objective": result.best_objective,
                "elapsed_seconds": result.elapsed_seconds,
                "operator_F": operators.count("F"),
                "operator_A": operators.count("A"),
                "operator_D": operators.count("D"),
                "termination_reason": result.termination_reason,
                "integrity": "passed",
            }
            payload = {
                "schema_version": 1,
                "run_type": "development_smoke_only",
                "metadata": runtime_metadata(ROOT),
                "function": name,
                "dimension": dimension,
                "bounds": [lower_scalar, upper_scalar],
                "seed": seed,
                "evaluations": result.evaluations,
                "best_objective": result.best_objective,
                "best_solution": result.best_solution,
                "elapsed_seconds": result.elapsed_seconds,
                "termination_reason": result.termination_reason,
                "config": result.config,
                "summary_row": summary_row,
            }
            atomic_json(raw_path, payload, overwrite=args.force)
            atomic_csv(
                trajectory_path,
                [
                    {"evaluations": point.evaluations, "best_objective": point.best_objective}
                    for point in result.trajectory
                ],
                overwrite=args.force,
            )
            atomic_csv(diagnostic_path, result.diagnostics, overwrite=args.force)
            summary.append(summary_row)
            print(f"completed: {name} seed={seed} best={result.best_objective:.8e}")

    atomic_csv(ROOT / "results" / "tables" / "smoke_summary.csv", summary, overwrite=True)
    lines = [
        "# Smoke Test Report",
        "",
        (
            "> Scope: development integrity tests only. These results support no CEC/BBOB "
            "or superiority claim."
        ),
        "",
        (
            f"Configuration: dimension {dimension}, population {population_size}, "
            f"exact budget {budget}, "
        ),
        f"seeds {list(map(int, smoke['seeds']))}.",
        "",
        (
            "All completed runs passed finite-value, closed-bound, exact-accounting, "
            "monotonic-best, and termination checks."
        ),
        (
            "Same-seed replay was checked during this execution; the unit suite performs "
            "a separate exact replay test."
        ),
        "",
        "| Function | Seed | Final best | Evaluations | F calls | A calls | D calls |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summary:
        lines.append(
            f"| {row['function']} | {row['seed']} | {float(row['best_objective']):.8e} | "
            f"{row['evaluations']} | {row['operator_F']} | {row['operator_A']} | "
            f"{row['operator_D']} |"
        )
    lines += [
        "",
        (
            "Raw values, elapsed times, metadata, solutions, trajectories, and diagnostics "
            "are stored under `results/`."
        ),
        (
            "Degradation may be absent at this small budget because its chronic-stress gate "
            "is intentionally strict."
        ),
    ]
    (ROOT / "reports" / "smoke_test_report.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
