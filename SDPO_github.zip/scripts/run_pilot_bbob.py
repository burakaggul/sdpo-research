"""Run the bounded infrastructure pilot on official COCO/BBOB problems."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import yaml

from sdpo.benchmark_adapters import CocoBbobAdapter
from sdpo.competitors import (
    PilotResult,
    cma_es,
    differential_evolution_rand1bin,
    random_search,
    sdpo_full,
)
from sdpo.logging_utils import atomic_csv, atomic_json
from sdpo.reproducibility import runtime_metadata

ROOT = Path(__file__).resolve().parents[1]
ALGORITHMS = {
    "Random-Search": random_search,
    "DE-rand-1-bin": differential_evolution_rand1bin,
    "CMA-ES": cma_es,
    "SDPO-Full": sdpo_full,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "pilot_bbob.yaml")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def result_payload(
    *,
    result: PilotResult,
    adapter: CocoBbobAdapter,
    algorithm: str,
    seed: int,
    budget: int,
    fopt: float,
) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "run_type": "infrastructure_pilot_not_confirmatory",
        "metadata": runtime_metadata(ROOT),
        "framework": "COCO/BBOB",
        "framework_version": "2.8.2",
        "problem_id": adapter.identifier,
        "function": adapter.function,
        "instance": adapter.instance,
        "dimension": adapter.dimension,
        "algorithm": algorithm,
        "seed": seed,
        "evaluation_budget": budget,
        "evaluations": result.evaluations,
        "framework_native_evaluations": adapter.native_evaluations,
        "best_objective": result.best_objective,
        "reference_fopt": fopt,
        "final_error": result.best_objective - fopt,
        "best_solution": result.best_solution,
        "elapsed_seconds": result.elapsed_seconds,
        "termination_reason": result.termination_reason,
        "parameters": result.parameters,
    }


def main() -> None:
    args = parse_args()
    config_path = args.config if args.config.is_absolute() else ROOT / args.config
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    budget = int(config["evaluation_budget"])
    dimension = int(config["dimension"])
    instance = int(config["instance"])
    population_size = int(config["population_size"])
    raw_root = ROOT / "results" / "raw" / "pilot_benchmark"
    trajectory_root = ROOT / "results" / "trajectories" / "pilot_benchmark"
    fopts = {
        int(function): CocoBbobAdapter.reference_fopt(int(function), dimension, instance)
        for function in config["functions"]
    }
    summary: list[dict[str, object]] = []
    for function in map(int, config["functions"]):
        for algorithm_name in config["algorithms"]:
            algorithm = ALGORITHMS[str(algorithm_name)]
            for seed in map(int, config["seeds"]):
                stem = (
                    f"{algorithm_name.lower().replace('-', '_')}_"
                    f"bbob_f{function:03d}_i{instance:02d}_d{dimension}_s{seed}"
                )
                raw_path = raw_root / f"{stem}.json"
                trajectory_path = trajectory_root / f"{stem}.csv"
                if raw_path.exists() and trajectory_path.exists() and not args.force:
                    payload = json.loads(raw_path.read_text(encoding="utf-8"))
                    if (
                        payload["evaluations"] != budget
                        or payload["framework_native_evaluations"] != budget
                    ):
                        raise RuntimeError(f"incompatible resumed pilot result: {raw_path}")
                    summary.append(_summary_row(payload))
                    print(f"resume: verified and skipped {raw_path.name}")
                    continue
                adapter = CocoBbobAdapter(function, dimension, instance)
                try:
                    result = algorithm(
                        adapter,
                        adapter.lower,
                        adapter.upper,
                        budget,
                        seed,
                        population_size=population_size,
                    )
                    if result.evaluations != budget or adapter.native_evaluations != budget:
                        raise AssertionError("project and COCO evaluation counters diverged")
                    payload = result_payload(
                        result=result,
                        adapter=adapter,
                        algorithm=str(algorithm_name),
                        seed=seed,
                        budget=budget,
                        fopt=fopts[function],
                    )
                finally:
                    adapter.close()
                atomic_json(raw_path, payload, overwrite=args.force)
                atomic_csv(
                    trajectory_path,
                    [
                        {"evaluations": evaluation, "best_objective": best}
                        for evaluation, best in result.trajectory
                    ],
                    overwrite=args.force,
                )
                summary.append(_summary_row(payload))
                print(
                    f"completed {payload['problem_id']} {algorithm_name} seed={seed} "
                    f"error={payload['final_error']:.6e}"
                )
    atomic_csv(
        ROOT / "results" / "tables" / "pilot_benchmark_summary.csv",
        summary,
        overwrite=True,
    )
    print(f"pilot complete: {len(summary)} exact-budget runs")


def _summary_row(payload: dict[str, Any]) -> dict[str, object]:
    return {
        "framework": payload["framework"],
        "problem_id": payload["problem_id"],
        "function": payload["function"],
        "instance": payload["instance"],
        "dimension": payload["dimension"],
        "algorithm": payload["algorithm"],
        "seed": payload["seed"],
        "evaluation_budget": payload["evaluation_budget"],
        "evaluations": payload["evaluations"],
        "framework_native_evaluations": payload["framework_native_evaluations"],
        "best_objective": payload["best_objective"],
        "reference_fopt": payload["reference_fopt"],
        "final_error": payload["final_error"],
        "elapsed_seconds": payload["elapsed_seconds"],
        "termination_reason": payload["termination_reason"],
    }


if __name__ == "__main__":
    main()
