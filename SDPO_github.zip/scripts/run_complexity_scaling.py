"""Measure algorithmic overhead components without making benchmark claims."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from statistics import median
from time import perf_counter_ns
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from sdpo.archive import StepArchive
from sdpo.graph import diffuse, sparse_transition_matrix
from sdpo.logging_utils import atomic_csv
from sdpo.neighbors import build_neighbor_graph
from sdpo.objectives import sphere
from sdpo.operators import annealing_proposals, chaperone_refold, degradation_replacement
from sdpo.stress import (
    crowding_from_neighbors,
    quality_stress,
    raw_stress,
    stagnation_stress,
)

ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repeats", type=int, default=9)
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def timed(function: Any, repeats: int) -> tuple[float, float]:
    function()  # warm-up outside recorded samples
    samples: list[float] = []
    for _ in range(repeats):
        start = perf_counter_ns()
        function()
        samples.append((perf_counter_ns() - start) / 1e9)
    q25, q75 = np.quantile(samples, [0.25, 0.75])
    return median(samples), float(q75 - q25)


def storage_bytes(sparse: Any) -> int:
    return sparse.data.nbytes + sparse.indices.nbytes + sparse.indptr.nbytes


def measure_case(
    *,
    axis: str,
    axis_value: int,
    backend: str,
    n: int,
    dimension: int,
    k: int,
    low_rank: int,
    repeats: int,
    seed: int,
) -> list[dict[str, object]]:
    rng = np.random.default_rng(seed)
    lower, upper = np.full(dimension, -5.0), np.full(dimension, 5.0)
    population = rng.uniform(lower, upper, size=(n, dimension))
    values = np.sum(population**2, axis=1)
    stagnation = rng.integers(0, 20, size=n)

    def build() -> Any:
        return build_neighbor_graph(
            population,
            lower,
            upper,
            k,
            backend=backend,
            brute_chunk_size=32,
        )

    neighbors = build()
    transition = sparse_transition_matrix(neighbors, 0.35)
    rank = quality_stress(values)
    stalled = stagnation_stress(stagnation, 10)
    crowding = crowding_from_neighbors(neighbors)
    q = raw_stress(rank, stalled, crowding, (0.4, 0.3, 0.3))
    previous = rng.uniform(size=n)
    archive = StepArchive(max_size=max(32, low_rank + 4))
    for _ in range(max(16, low_rank + 2)):
        archive.add(rng.normal(scale=0.1, size=dimension))

    components: dict[str, Any] = {
        "distance_knn_construction": build,
        "stress_computation": lambda: raw_stress(
            quality_stress(values),
            stagnation_stress(stagnation, 10),
            crowding_from_neighbors(neighbors),
            (0.4, 0.3, 0.3),
        ),
        "sparse_transition_construction": lambda: sparse_transition_matrix(neighbors, 0.35),
        "graph_diffusion": lambda: diffuse(q, previous, transition, 0.35),
        "svd_refolding": lambda: chaperone_refold(
            population[0],
            population,
            values,
            archive.matrix(),
            lower,
            upper,
            rng,
            low_rank=low_rank,
            archive_min_steps=3,
            elite_fraction=0.2,
            attraction=0.35,
            scale=0.15,
            isotropic_epsilon=0.05,
        ),
        "operator_generation": lambda: (
            annealing_proposals(
                population[0],
                population,
                0.5,
                3,
                lower,
                upper,
                rng,
                differential_scale=0.5,
                annealing_scale=0.05,
                student_t_df=3.0,
            ),
            degradation_replacement(population, lower, upper, rng, 0.1),
        ),
        "objective_evaluation": lambda: sphere(population[0]),
        "logging_serialization": lambda: json.dumps(
            {
                "n": n,
                "d": dimension,
                "k": k,
                "m": low_rank,
                "stress": float(q[0]),
                "best": float(values.min()),
            },
            sort_keys=True,
        ),
    }
    transition_bytes = storage_bytes(transition)
    population_bytes = population.nbytes
    if backend == "brute":
        working_bytes = min(32, n) * n * 8 + neighbors.storage_bytes
        memory_note = "upper estimate for configured cdist block plus retained neighbor list"
    else:
        working_bytes = population_bytes + neighbors.storage_bytes
        memory_note = "lower bound; cKDTree internal node overhead is not exposed"
    rows: list[dict[str, object]] = []
    for component, function in components.items():
        seconds, iqr = timed(function, repeats)
        rows.append(
            {
                "axis": axis,
                "axis_value": axis_value,
                "backend": backend,
                "N": n,
                "d": dimension,
                "k": k,
                "m": low_rank,
                "component": component,
                "median_seconds": seconds,
                "iqr_seconds": iqr,
                "repeats": repeats,
                "population_bytes": population_bytes,
                "neighbor_storage_bytes": neighbors.storage_bytes,
                "transition_storage_bytes": transition_bytes,
                "estimated_working_bytes": working_bytes,
                "memory_note": memory_note,
            }
        )
    return rows


def make_figure(rows: list[dict[str, object]], destination: Path) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(11, 8), constrained_layout=True)
    panels = [
        ("N", "distance_knn_construction", "Neighbor construction vs N"),
        ("d", "distance_knn_construction", "Neighbor construction vs dimension"),
        ("k", "graph_diffusion", "Sparse diffusion vs k"),
        ("m", "svd_refolding", "SVD/refolding vs retained rank"),
    ]
    for axis_plot, (axis_name, component, title) in zip(axes.ravel(), panels, strict=True):
        for backend in ("ckdtree", "brute"):
            selected = [
                row
                for row in rows
                if row["axis"] == axis_name
                and row["component"] == component
                and row["backend"] == backend
            ]
            selected.sort(key=lambda row: int(row["axis_value"]))
            axis_plot.plot(
                [int(row["axis_value"]) for row in selected],
                [float(row["median_seconds"]) * 1e3 for row in selected],
                marker="o",
                label=backend,
            )
        axis_plot.set_title(title)
        axis_plot.set_xlabel(axis_name)
        axis_plot.set_ylabel("median time (ms)")
        axis_plot.grid(alpha=0.3)
        axis_plot.legend()
    destination.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(destination, dpi=180)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    if args.repeats < 3:
        raise SystemExit("use at least three measured repeats")
    cases: list[tuple[str, int, int, int, int, int]] = []
    cases += [("N", value, value, 30, 8, 4) for value in (20, 40, 80, 160)]
    cases += [("d", value, 80, value, 8, 4) for value in (10, 30, 50, 100)]
    cases += [("k", value, 80, 30, value, 4) for value in (2, 4, 8, 16)]
    cases += [("m", value, 80, 30, 8, value) for value in (1, 2, 4, 8)]
    rows: list[dict[str, object]] = []
    for backend in ("ckdtree", "brute"):
        for index, (axis, value, n, dimension, k, low_rank) in enumerate(cases):
            rows.extend(
                measure_case(
                    axis=axis,
                    axis_value=value,
                    backend=backend,
                    n=n,
                    dimension=dimension,
                    k=k,
                    low_rank=low_rank,
                    repeats=args.repeats,
                    seed=20260718 + index,
                )
            )
    table = ROOT / "results" / "tables" / "complexity_scaling.csv"
    figure = ROOT / "results" / "figures" / "complexity_scaling.png"
    atomic_csv(table, rows, overwrite=args.force)
    make_figure(rows, figure)
    print(f"wrote {len(rows)} component measurements to {table}")
    print(f"wrote scaling figure to {figure}")


if __name__ == "__main__":
    main()
