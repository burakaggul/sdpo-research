"""Fail-closed numerical and directional audit for the SDPO manuscript.

The audit validates the frozen design, complete confirmatory artifacts, generated
tables/figure sidecars, displayed rounding, and the bounded direction statements in
the abstract and results, including the completed secondary ablation.
"""

from __future__ import annotations

import csv
import json
import math
import re
import statistics
from collections import defaultdict
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
MANUSCRIPT = ROOT / "manuscript"
RESULTS = ROOT / "results"
REPORT = ROOT / "reports" / "numerical_consistency_report.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def expanded_tex(path: Path, seen: set[Path] | None = None) -> str:
    seen = set() if seen is None else seen
    path = path.resolve()
    if path in seen:
        return ""
    seen.add(path)
    text = path.read_text(encoding="utf-8")
    pieces = [text]
    for match in re.finditer(r"\\(?:input|include)\{([^}]+)\}", text):
        child = MANUSCRIPT / match.group(1)
        if child.suffix == "":
            child = child.with_suffix(".tex")
        if child.is_file():
            pieces.append(expanded_tex(child, seen))
    return "\n".join(pieces)


def main() -> None:
    checks: list[tuple[str, bool, str]] = []

    def check(name: str, condition: bool, detail: str) -> None:
        checks.append((name, bool(condition), detail))

    config = yaml.safe_load((ROOT / "configs" / "bbob.yaml").read_text(encoding="utf-8"))
    expected_runs = math.prod(
        len(config[key]) for key in ("functions", "dimensions", "instances", "seeds", "algorithms")
    )
    audit = json.loads(
        (RESULTS / "metadata" / "bbob_manifest_audit.json").read_text(encoding="utf-8")
    )
    check("Frozen manifest arithmetic", expected_runs == 11520, f"expected={expected_runs}")
    check(
        "Artifact audit verdict and counts",
        audit["verdict"] == "PASS"
        and audit["expected_runs"] == expected_runs
        and audit["passed_runs"] == expected_runs
        and audit["failed_runs"] == 0
        and audit["raw_files"] == expected_runs
        and audit["trajectory_files"] == expected_runs
        and audit["summary_rows"] == expected_runs,
        f"verdict={audit['verdict']}; passed={audit['passed_runs']}; failed={audit['failed_runs']}",
    )

    summary = read_csv(RESULTS / "tables" / "bbob_summary.csv")
    exact_counters = all(
        int(row["evaluation_budget"])
        == int(row["evaluations"])
        == int(row["framework_native_evaluations"])
        == 10000 * int(row["dimension"])
        for row in summary
    )
    check(
        "Summary row identities and exact counters",
        len(summary) == expected_runs and exact_counters,
        f"rows={len(summary)}; all budget/project/native counters exact={exact_counters}",
    )
    keys = {
        (
            row["function"],
            row["instance"],
            row["dimension"],
            row["algorithm"],
            row["seed"],
        )
        for row in summary
    }
    check("Unique experimental units", len(keys) == expected_runs, f"unique keys={len(keys)}")

    descriptive = read_csv(RESULTS / "tables" / "descriptive_final_error.csv")
    ranks = read_csv(RESULTS / "tables" / "algorithm_ranks_by_dimension.csv")
    runtimes = read_csv(RESULTS / "tables" / "runtime_summary.csv")
    omnibus = read_csv(RESULTS / "statistics" / "aligned_friedman.csv")
    pairwise = read_csv(RESULTS / "statistics" / "pairwise_wilcoxon_holm.csv")
    cma = read_csv(RESULTS / "tables" / "cma_restart_diagnostics.csv")
    check(
        "Generated table cardinalities",
        len(descriptive) == 384
        and all(int(row["count"]) == int(row["finite_count"]) == 30 for row in descriptive)
        and len(ranks) == 16
        and all(int(row["n_function_blocks"]) == 24 for row in ranks)
        and len(runtimes) == 16
        and all(int(row["n_runs"]) == 720 for row in runtimes)
        and len(cma) == 2880,
        (
            f"descriptive={len(descriptive)}; ranks={len(ranks)}; "
            f"runtimes={len(runtimes)}; CMA={len(cma)}"
        ),
    )
    check(
        "Confirmatory inference cardinalities",
        len(omnibus) == 4
        and all(int(row["n_function_blocks"]) == 24 for row in omnibus)
        and all(row["reject_null"].lower() == "true" for row in omnibus)
        and len(pairwise) == 12
        and all(int(row["n_function_blocks"]) == 24 for row in pairwise),
        f"omnibus={len(omnibus)}; pairwise={len(pairwise)}; analysis unit=24 functions",
    )

    log_errors: dict[tuple[int, str], list[float]] = defaultdict(list)
    elapsed: dict[tuple[int, str], list[float]] = defaultdict(list)
    for row in summary:
        key = (int(row["dimension"]), row["algorithm"])
        log_errors[key].append(math.log10(float(row["final_error"]) + 1e-12))
        elapsed[key].append(float(row["elapsed_seconds"]))
    algorithms = ("CMA-ES-Restart", "DE-rand-1-bin", "SDPO-Full", "Random-Search")
    primary_tex = (MANUSCRIPT / "tables" / "primary_performance_generated.tex").read_text(
        encoding="utf-8"
    )
    runtime_tex = (MANUSCRIPT / "tables" / "runtime_generated.tex").read_text(encoding="utf-8")
    primary_rows_ok = all(
        f"{dimension} & "
        + " & ".join(
            f"{statistics.median(log_errors[(dimension, algorithm)]):.3f}"
            for algorithm in algorithms
        )
        + r" \\"
        in primary_tex
        for dimension in config["dimensions"]
    )
    runtime_rows_ok = all(
        f"{dimension} & "
        + " & ".join(
            f"{statistics.median(elapsed[(dimension, algorithm)]):.2f}" for algorithm in algorithms
        )
        + r" \\"
        in runtime_tex
        for dimension in config["dimensions"]
    )
    check(
        "Displayed descriptive rounding",
        primary_rows_ok,
        "all 16 median errors match at 3 decimals",
    )
    check(
        "Displayed runtime rounding", runtime_rows_ok, "all 16 median runtimes match at 2 decimals"
    )

    confirmatory_tex = (MANUSCRIPT / "tables" / "confirmatory_generated.tex").read_text(
        encoding="utf-8"
    )
    omnibus_ok = all(
        f"{int(row['dimension'])} & {float(row['statistic']):.3f} & "
        f"{int(row['degrees_of_freedom'])} & ${float(row['p_value']):.2e}$" in confirmatory_tex
        for row in omnibus
    )
    comparator_order = ("CMA-ES-Restart", "DE-rand-1-bin", "Random-Search")
    lookup = {(int(row["dimension"]), row["comparator"]): row for row in pairwise}
    comparator_label = {
        "CMA-ES-Restart": "CMA-ES-Restart",
        "DE-rand-1-bin": "DE-rand-1-bin",
        "Random-Search": "Random Search",
    }

    def expected_pairwise_row(dimension: int, comparator: str) -> str:
        row = lookup[(dimension, comparator)]
        adjusted_p = float(row["holm_adjusted_p_value"])
        difference = float(row["median_difference_sdpo_minus_comparator"])
        effect = float(row["rank_biserial_sdpo_minus_comparator"])
        return (
            f"{dimension} & {comparator_label[comparator]} & ${adjusted_p:.2e}$ & "
            f"{difference:.3f} & {effect:.3f}"
        )

    pairwise_ok = all(
        expected_pairwise_row(dimension, comparator) in confirmatory_tex
        for dimension in config["dimensions"]
        for comparator in comparator_order
    )
    check("Displayed omnibus rounding", omnibus_ok, "all four rows match source CSV")
    check("Displayed pairwise/effect rounding", pairwise_ok, "all 12 rows match source CSV")

    text = expanded_tex(MANUSCRIPT / "main.tex")
    required_display_tokens = (
        "11,520",
        "$10{,}000d$",
        "1.79e-6",
        "0.0194",
        "-0.540",
        "2.10e-5",
        "16.98",
        "228.76",
    )
    check(
        "Abstract source-number coverage",
        all(token in text for token in required_display_tokens),
        "run count, budget, p-values, effect, and runtime endpoints present",
    )
    direction_checks = {
        "Random Search": all(
            float(row["median_difference_sdpo_minus_comparator"]) < 0
            for row in pairwise
            if row["comparator"] == "Random-Search"
        ),
        "CMA-ES": all(
            float(row["median_difference_sdpo_minus_comparator"]) > 0
            for row in pairwise
            if row["comparator"] == "CMA-ES-Restart"
        ),
        "DE d=5": float(lookup[(5, "DE-rand-1-bin")]["median_difference_sdpo_minus_comparator"])
        > 0,
        "DE d=40": float(lookup[(40, "DE-rand-1-bin")]["median_difference_sdpo_minus_comparator"])
        < 0,
    }
    prose_ok = (
        "lower error than Random Search in every dimension" in text
        and "CMA-ES-Restart remained better in every dimension" in text
        and "worse at dimension 5" in text
        and "better at dimension 40" in text
    )
    check(
        "Better/worse direction audit",
        all(direction_checks.values()) and prose_ok,
        "; ".join(f"{name}={value}" for name, value in direction_checks.items()),
    )

    captions = read_csv(RESULTS / "figures" / "figure_caption_drafts.csv")
    metadata = json.loads(
        (RESULTS / "figures" / "figure_generation_metadata.json").read_text(encoding="utf-8")
    )
    figure_files_ok = all(
        all(
            (RESULTS / "figures" / f"{row['figure']}.{suffix}").is_file()
            for suffix in ("pdf", "svg", "png")
        )
        for row in captions
    )
    check(
        "Figure data/caption/export audit",
        len(captions) == 7
        and figure_files_ok
        and metadata.get("convergence_generated") is True
        and "generated" in metadata.get("ablation_figure_status", ""),
        f"captions={len(captions)}; seven export sets={figure_files_ok}; ablation included",
    )

    ablation_audit = json.loads(
        (RESULTS / "metadata" / "ablation_manifest_audit.json").read_text(encoding="utf-8")
    )
    ablation_rows = read_csv(RESULTS / "statistics" / "ablation_pairwise_wilcoxon_holm.csv")
    ablation_medians = read_csv(RESULTS / "statistics" / "ablation_function_medians.csv")
    ablation_tex = (MANUSCRIPT / "tables" / "ablation_generated.tex").read_text(encoding="utf-8")
    significant = [row for row in ablation_rows if row["reject_after_holm"].lower() == "true"]
    check(
        "Secondary ablation integrity and display gate",
        ablation_audit.get("verdict") == "PASS"
        and ablation_audit.get("passed_new_runs") == 2592
        and ablation_audit.get("failed_runs") == 0
        and len(ablation_medians) == 480
        and len(ablation_rows) == 18
        and len(significant) == 5
        and all(
            (
                f"{float(row['median_difference_full_minus_variant']):.3f} & "
                f"{float(row['rank_biserial_full_minus_variant']):.3f} & "
                f"${float(row['holm_adjusted_p_value']):.2e}$"
            )
            in ablation_tex
            for row in ablation_rows
        ),
        (
            f"new runs={ablation_audit.get('passed_new_runs')}; medians={len(ablation_medians)}; "
            f"comparisons={len(ablation_rows)}; Holm-significant={len(significant)}"
        ),
    )

    extension_audit = json.loads(
        (RESULTS / "metadata" / "extension_bbob_manifest_audit.json").read_text(encoding="utf-8")
    )
    validation_audit = json.loads(
        (RESULTS / "metadata" / "validation_bbob_largescale_manifest_audit.json").read_text(
            encoding="utf-8"
        )
    )
    check(
        "Modern-comparator extension integrity",
        extension_audit.get("verdict") == "PASS"
        and extension_audit.get("passed_runs") == 2304
        and extension_audit.get("failed_runs") == 0,
        (f"verdict={extension_audit.get('verdict')}; passed={extension_audit.get('passed_runs')}"),
    )
    check(
        "Untouched BBOB-LargeScale validation integrity",
        validation_audit.get("verdict") == "PASS"
        and validation_audit.get("passed_runs") == 1152
        and validation_audit.get("failed_runs") == 0,
        (
            f"verdict={validation_audit.get('verdict')}; "
            f"passed={validation_audit.get('passed_runs')}"
        ),
    )

    extension_omnibus = read_csv(RESULTS / "statistics" / "extension_aligned_friedman.csv")
    extension_pairwise = read_csv(RESULTS / "statistics" / "extension_pairwise_holm.csv")
    validation_omnibus = read_csv(RESULTS / "statistics" / "validation_aligned_friedman.csv")
    validation_pairwise = read_csv(RESULTS / "statistics" / "validation_pairwise_holm.csv")
    check(
        "Extension and validation inferential cardinalities",
        len(extension_omnibus) == 4
        and all(int(row["n_function_blocks"]) == 24 for row in extension_omnibus)
        and len(extension_pairwise) == 20
        and all(int(row["n_function_blocks"]) == 24 for row in extension_pairwise)
        and len(validation_omnibus) == 1
        and int(validation_omnibus[0]["n_function_blocks"]) == 24
        and len(validation_pairwise) == 3
        and all(int(row["n_function_blocks"]) == 24 for row in validation_pairwise),
        (
            f"extension omnibus/pairwise={len(extension_omnibus)}/{len(extension_pairwise)}; "
            f"validation={len(validation_omnibus)}/{len(validation_pairwise)}"
        ),
    )
    extension_tex = (MANUSCRIPT / "tables" / "extension_validation_generated.tex").read_text(
        encoding="utf-8"
    )

    def extension_row_present(study: str, row: dict[str, str]) -> bool:
        comparator = row["comparator"].replace("-", r"\mbox{-}")
        decision = "Reject" if row["reject_after_holm"].lower() == "true" else "Retain"
        return (
            f"{study} & {int(row['dimension'])} & {comparator} & "
            f"{float(row['median_difference_focal_minus_comparator']):.3f} & "
            f"{float(row['rank_biserial_focal_minus_comparator']):.3f}"
            in extension_tex
            and decision in extension_tex
        )

    displayed_extension = all(
        extension_row_present(study, row)
        for study, rows in (
            ("Extension", extension_pairwise),
            ("Validation", validation_pairwise),
        )
        for row in rows
    )
    check(
        "Displayed extension/validation effects",
        displayed_extension,
        "all 23 pairwise rows match generated manuscript table at displayed precision",
    )

    target_metadata = json.loads(
        (RESULTS / "metadata" / "bbob_target_analysis.json").read_text(encoding="utf-8")
    )
    target_runs = read_csv(RESULTS / "tables" / "bbob_target_attainment_runs.csv")
    target_ert = read_csv(RESULTS / "tables" / "bbob_ert_by_function.csv")
    target_ecdf = read_csv(RESULTS / "tables" / "bbob_ecdf.csv")
    check(
        "Checkpoint-resolved target analysis",
        len(target_metadata.get("targets", [])) == 51
        and len(target_runs) == 6912 * 51
        and len(target_ert) == 6 * 4 * 24 * 51
        and len(target_ecdf) == 6 * 4 * 201,
        (
            f"targets={len(target_metadata.get('targets', []))}; "
            f"attainment/ERT/ECDF rows={len(target_runs)}/{len(target_ert)}/{len(target_ecdf)}"
        ),
    )
    new_figures_ok = all(
        (RESULTS / "figures" / f"fig{number:02d}_{name}.{suffix}").is_file()
        for number, name in (
            (8, "bbob_ecdf"),
            (9, "modern_comparator_effects"),
            (10, "untouched_validation_effects"),
        )
        for suffix in ("pdf", "svg", "png")
    )
    check(
        "Extension figure export audit",
        new_figures_ok,
        "ECDF, comparator, and validation figures each have PDF/SVG/PNG exports",
    )

    forbidden_artifact_prose = re.findall(
        r"(?:results[/\\]|[A-Za-z0-9_]+\.(?:csv|json|ya?ml))",
        text,
        flags=re.IGNORECASE,
    )
    check(
        "No internal artifact paths in article prose",
        not forbidden_artifact_prose,
        f"forbidden matches={forbidden_artifact_prose}",
    )

    ledger = read_csv(MANUSCRIPT / "evidence_ledger.csv")
    inventory = read_csv(MANUSCRIPT / "numerical_token_inventory.csv")
    manual = [
        row for row in inventory if row["category"] == "manual_review_required_before_submission"
    ]
    blocked = [row for row in ledger if "block" in row["disposition"]]
    check(
        "Numeric-token and evidence-ledger gate",
        len(inventory) > 0 and not manual and not blocked,
        (
            f"tokens={len(inventory)}; manually unmatched={len(manual)}; "
            f"blocked ledger claims={len(blocked)}"
        ),
    )

    failures = [entry for entry in checks if not entry[1]]
    lines = [
        "# Numerical Consistency Report",
        "",
        "Date: 2026-08-03 (Europe/Istanbul).",
        "",
        f"Verdict: **{'PASS' if not failures else 'FAIL'}** for the completed "
        "COCO/BBOB confirmatory evidence.",
        "The secondary ablation, modern-comparator extension, target analysis, and untouched "
        "validation are included and audited from frozen artifacts.",
        "",
        "## Checks",
        "",
    ]
    for name, passed, detail in checks:
        lines.append(f"- **{'PASS' if passed else 'FAIL'} — {name}:** {detail}.")
    lines.extend(
        [
            "",
            "## Boundary",
            "",
            "This audit establishes internal numerical consistency, not novelty, external "
            "validity, causal component attribution, or submission readiness. Those gates "
            "remain independent.",
            "",
        ]
    )
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    if failures:
        names = ", ".join(name for name, _, _ in failures)
        raise SystemExit(f"numerical manuscript audit failed: {names}")
    print(f"numerical manuscript audit: PASS ({len(checks)} checks)")


if __name__ == "__main__":
    main()
