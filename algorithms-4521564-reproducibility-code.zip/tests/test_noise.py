import numpy as np
import pytest

from sdpo.noise import RelativeLognormalNoise


def test_relative_lognormal_noise_is_seed_deterministic() -> None:
    def objective(point: np.ndarray) -> float:
        return 2.0 + float(np.sum(point**2))

    first = RelativeLognormalNoise(objective, 2.0, 0.2, 91)
    second = RelativeLognormalNoise(objective, 2.0, 0.2, 91)
    point = np.array([1.0, -2.0])
    assert [first(point) for _ in range(5)] == [second(point) for _ in range(5)]
    assert first.calls == second.calls == 5


def test_relative_lognormal_noise_preserves_exact_optimum_and_validates_sigma() -> None:
    noise = RelativeLognormalNoise(lambda _: -3.5, -3.5, 0.4, 12)
    assert noise(np.zeros(2)) == pytest.approx(-3.5)
    with pytest.raises(ValueError, match="sigma"):
        RelativeLognormalNoise(lambda _: 0.0, 0.0, -0.1, 12)
