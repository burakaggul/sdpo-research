import numpy as np
import pytest

from sdpo.competitors import (
    cma_es,
    cma_es_inhouse,
    differential_evolution_rand1bin,
    lshade,
    random_search,
    recpm_aos_de,
    sdpo_configured,
    sdpo_full,
    sdpo_revised,
)
from sdpo.objectives import sphere


@pytest.mark.parametrize(
    "algorithm",
    [
        random_search,
        differential_evolution_rand1bin,
        cma_es,
        cma_es_inhouse,
        sdpo_full,
        sdpo_revised,
        lshade,
        recpm_aos_de,
    ],
)
def test_pilot_algorithms_use_exact_budget_and_monotonic_trajectory(algorithm) -> None:
    lower, upper = np.full(4, -5.0), np.full(4, 5.0)
    result = algorithm(sphere, lower, upper, 60, 123, population_size=10)
    best = np.array([value for _, value in result.trajectory])
    assert result.evaluations == len(result.trajectory) == 60
    assert np.all(np.diff(best) <= 0.0)
    assert np.all(result.best_solution >= lower)
    assert np.all(result.best_solution <= upper)


def test_lshade_reduces_population_and_records_literature_parameters() -> None:
    result = lshade(
        sphere,
        np.full(4, -5.0),
        np.full(4, 5.0),
        120,
        12,
        population_size=12,
    )
    assert result.parameters["minimum_population_size"] == 4
    assert result.parameters["p_best_rate"] == pytest.approx(0.11)


def test_recpm_aos_reports_normalized_final_probabilities() -> None:
    result = recpm_aos_de(
        sphere,
        np.full(4, -5.0),
        np.full(4, 5.0),
        120,
        12,
        population_size=12,
    )
    probabilities = np.asarray(result.parameters["final_operator_probabilities"])
    assert probabilities.sum() == pytest.approx(1.0)
    assert np.all(probabilities >= 0.0)
    assert result.parameters["F"] == pytest.approx(0.5)
    assert result.parameters["CR"] == pytest.approx(1.0)
    assert result.parameters["p_min"] == pytest.approx(0.0)
    assert result.parameters["gamma"] == pytest.approx(0.6)


@pytest.mark.parametrize("algorithm", [lshade, recpm_aos_de])
def test_modern_comparators_are_seed_deterministic(algorithm) -> None:
    lower, upper = np.full(3, -5.0), np.full(3, 5.0)
    first = algorithm(sphere, lower, upper, 90, 44, population_size=10)
    second = algorithm(sphere, lower, upper, 90, 44, population_size=10)
    assert first.best_objective == pytest.approx(second.best_objective, rel=0.0, abs=0.0)
    assert first.trajectory == second.trajectory


def test_cma_partial_final_generation_is_charged_but_not_told() -> None:
    result = cma_es(sphere, np.full(3, -5.0), np.full(3, 5.0), 65, 321, population_size=10)
    assert result.evaluations == 65
    assert result.parameters["partial_final_generation_evaluated_without_tell"] == 5


def test_cma_restarts_on_stop_and_still_exhausts_budget() -> None:
    lower, upper = np.full(3, -1.0), np.full(3, 1.0)
    result = cma_es(lambda _: 1.0, lower, upper, 600, 41, population_size=20)
    assert result.evaluations == 600
    assert result.parameters["restarts"] >= 1
    assert result.parameters["restart_reasons"]["stop"] >= 1


def test_configured_sdpo_rejects_locked_or_unknown_fields() -> None:
    with pytest.raises(ValueError, match="unknown or locked"):
        sdpo_configured(
            sphere,
            np.full(3, -5.0),
            np.full(3, 5.0),
            80,
            9,
            population_size=10,
            config_overrides={"seed": 123},
        )


def test_inhouse_cma_is_seed_deterministic() -> None:
    lower, upper = np.full(4, -5.0), np.full(4, 5.0)
    first = cma_es_inhouse(sphere, lower, upper, 123, 91, population_size=10)
    second = cma_es_inhouse(sphere, lower, upper, 123, 91, population_size=10)
    assert first.evaluations == 123
    assert first.best_objective == pytest.approx(second.best_objective, rel=0.0, abs=0.0)
    assert first.trajectory == second.trajectory
    assert first.parameters["partial_final_generation_evaluated_without_update"] == 3


def test_configured_sdpo_records_degradation_diagnostics() -> None:
    result = sdpo_configured(
        sphere,
        np.full(3, -5.0),
        np.full(3, 5.0),
        81,
        7,
        population_size=10,
        config_overrides={"diffusion_rho": 0.7, "stress_weights": [1 / 3, 1 / 3, 1 / 3]},
        include_diagnostics_summary=True,
    )
    summary = result.parameters["diagnostics_summary"]
    assert result.parameters["diffusion_rho"] == pytest.approx(0.7)
    assert result.parameters["stress_weights"] == pytest.approx((1 / 3, 1 / 3, 1 / 3))
    assert summary["decision_count"] > 0
    assert 0.0 <= summary["chronic_set_membership_rate"] <= 1.0
    assert 0.0 <= summary["degradation_evaluation_fraction"] <= 1.0
