"""Generate publication figures and sidecars from validated SDPO artifacts."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import os
from collections import defaultdict
from pathlib import Path
from tempfile import NamedTemporaryFile

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch
from PIL import Image

from sdpo.logging_utils import atomic_csv, atomic_json

matplotlib.use("Agg")

ROOT = Path(__file__).resolve().parents[1]
FIGURES = ROOT / "results" / "figures"
MANUSCRIPT_FIGURES = ROOT / "manuscript" / "figures"
SUMMARY = ROOT / "results" / "tables" / "bbob_summary.csv"
FUNCTION_MEDIANS = ROOT / "results" / "statistics" / "function_median_log_error.csv"
PAIRWISE = ROOT / "results" / "statistics" / "pairwise_wilcoxon_holm.csv"
RANKS = ROOT / "results" / "tables" / "algorithm_ranks_by_dimension.csv"
RUNTIME = ROOT / "results" / "tables" / "runtime_summary.csv"
TRAJECTORIES = ROOT / "results" / "trajectories" / "bbob"
PALETTE = {
    "CMA-ES-Restart": "#0072B2",
    "DE-rand-1-bin": "#E69F00",
    "SDPO-Full": "#009E73",
    "Random-Search": "#CC79A7",
}
LINESTYLES = {
    "CMA-ES-Restart": "-",
    "DE-rand-1-bin": "--",
    "SDPO-Full": "-.",
    "Random-Search": ":",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--skip-convergence",
        action="store_true",
        help="Regenerate all lightweight figures without rereading trajectory bundles.",
    )
    return parser.parse_args()


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _save_figure(fig: plt.Figure, stem: str) -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_FIGURES.mkdir(parents=True, exist_ok=True)
    for extension, kwargs in (
        ("pdf", {}),
        ("svg", {}),
        ("png", {"dpi": 600}),
    ):
        target = FIGURES / f"{stem}.{extension}"
        with NamedTemporaryFile(suffix=f".{extension}", dir=target.parent, delete=False) as tmp:
            temporary = Path(tmp.name)
        fig.savefig(temporary, bbox_inches="tight", **kwargs)
        os.replace(temporary, target)
    manuscript_target = MANUSCRIPT_FIGURES / f"{stem}.pdf"
    manuscript_target.write_bytes((FIGURES / f"{stem}.pdf").read_bytes())
    with Image.open(FIGURES / f"{stem}.png") as image:
        image.convert("L").save(FIGURES / f"{stem}_grayscale.png")
    plt.close(fig)


def _stem(algorithm: str, function: int, instance: int, dimension: int, seed: int) -> str:
    normalized = algorithm.lower().replace("-", "_")
    return f"{normalized}_bbob_f{function:03d}_i{instance:02d}_d{dimension}_s{seed}.csv.gz"


def architecture() -> None:
    fig, ax = plt.subplots(figsize=(10, 10))
    ax.set(xlim=(0, 10), ylim=(0, 10))
    ax.axis("off")

    def box(x, y, w, title, detail, color="#EAF2F8"):
        ax.add_patch(
            FancyBboxPatch(
                (x, y),
                w,
                0.68,
                boxstyle="round,pad=0.04",
                facecolor=color,
                edgecolor="#334155",
                linewidth=1.1,
            )
        )
        ax.text(
            x + w / 2, y + 0.45, title, ha="center", va="center", fontsize=10, weight="semibold"
        )
        ax.text(x + w / 2, y + 0.18, detail, ha="center", va="center", fontsize=8)

    def arrow(points, label=None):
        for a, b in zip(points[:-2], points[1:-1], strict=True):
            ax.plot([a[0], b[0]], [a[1], b[1]], color="#334155", lw=1)
        ax.annotate(
            "",
            xy=points[-1],
            xytext=points[-2],
            arrowprops={"arrowstyle": "-|>", "color": "#334155", "lw": 1},
        )
        if label:
            ax.text(
                *label[:2],
                label[2],
                fontsize=8,
                ha="center",
                bbox={"facecolor": "white", "edgecolor": "none", "pad": 1},
            )

    box(
        2,
        9.1,
        6,
        "Initialize",
        r"Sample and evaluate $N$ candidates; set $b=N$; initialize archives and credit",
    )
    box(
        2,
        7.95,
        6,
        "Outer iteration: construct condition state",
        r"Compute $R_i^t,S_i^t,C_i^t,q_i^t$; rebuild $P^t$; obtain $h_i^t$",
    )
    box(
        2,
        6.8,
        6,
        "Candidate i: select operator",
        r"Combine $h_i^t$ with $u_o^t$; sample $F,A,D$; apply chronic-set gate",
    )
    box(
        2,
        5.65,
        6,
        "Generate feasible proposals",
        r"$F,D$: one child; $A$: $K_i=\min(K_i^*,B-b)$ children",
        "#FFF4E5",
    )
    box(
        2,
        4.5,
        6,
        "Evaluate each child",
        r"Charge one call: $b\leftarrow b+1$; update best-so-far immediately",
        "#FDEDEC",
    )
    box(
        2,
        3.35,
        6,
        "Select and update candidate",
        r"Batch best; greedy acceptance; archives; stagnation; strict-gain list",
        "#E8F5F1",
    )
    box(
        2,
        1.9,
        6,
        "End candidate sweep",
        r"Update $u_o^{t+1}$ from $G_o^t$; retain credit if its list is empty",
        "#E8F5F1",
    )
    box(2, 0.45, 6, "Return best-so-far", r"Terminate when $b=B$")
    for y1, y2 in [(9.1, 8.63), (7.95, 7.48), (6.8, 6.33), (5.65, 5.18), (4.5, 4.03)]:
        arrow([(5, y1), (5, y2)])
    arrow([(8, 3.68), (8.65, 3.68), (8.65, 7.14), (8, 7.14)])
    ax.text(
        8.86,
        5.25,
        "Next candidate\nif i < N and b < B",
        ha="center",
        va="center",
        rotation=90,
        fontsize=9,
    )
    arrow([(5, 3.35), (5, 2.58)], (5, 2.92, "i = N or budget exhausted"))
    arrow([(2, 2.24), (0.8, 2.24), (0.8, 8.29), (2, 8.29)])
    ax.text(
        0.55,
        5.25,
        "Next outer iteration if b < B",
        ha="center",
        va="center",
        rotation=90,
        fontsize=9,
    )
    arrow([(5, 1.9), (5, 1.13)], (5, 1.48, "b = B"))
    fig.tight_layout()
    _save_figure(fig, "fig01_architecture")


def stress_responses() -> None:
    h = np.linspace(0.0, 1.0, 501)
    response_f, response_a, response_d = 1.0 - h, 4.0 * h * (1.0 - h), h
    logits = 2.0 * np.column_stack((response_f, response_a, response_d))
    logits -= logits.max(axis=1, keepdims=True)
    pre = np.exp(logits)
    pre /= pre.sum(axis=1, keepdims=True)
    ineligible = pre.copy()
    ineligible[:, :2] /= ineligible[:, :2].sum(axis=1, keepdims=True)
    ineligible[:, 2] = 0.0
    rows = []
    for index, value in enumerate(h):
        rows.append(
            {
                "stress": value,
                "response_F": response_f[index],
                "response_A": response_a[index],
                "response_D": response_d[index],
                "pre_gate_probability_F_zero_credit": pre[index, 0],
                "pre_gate_probability_A_zero_credit": pre[index, 1],
                "pre_gate_probability_D_zero_credit": pre[index, 2],
                "realized_probability_D_ineligible": 0.0,
                "realized_probability_D_long_stagnation": pre[index, 2] if value > 0.75 else 0.0,
            }
        )
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.7), sharex=True)
    labels = ("F: refolding", "A: annealing", "D: degradation")
    colors = ("#0072B2", "#E69F00", "#009E73")
    for values, label, color in zip(
        (response_f, response_a, response_d), labels, colors, strict=True
    ):
        axes[0].plot(h, values, label=label, color=color, lw=2)
    axes[0].set(title="Stress-response functions", xlabel="Diffused stress h", ylabel="Response")
    axes[0].legend(frameon=False)
    axes[1].plot(h, pre[:, 2], color="#666666", lw=1.5, ls="--", label="Pre-gate D")
    realized = np.where(h > 0.75, pre[:, 2], 0.0)
    axes[1].plot(h, realized, color="#009E73", lw=2, label=r"Realized D: $L_i>12$")
    axes[1].plot(
        h,
        ineligible[:, 2],
        color="#D55E00",
        lw=2,
        ls="--",
        label=r"Realized D: $L_i\leq12$",
    )
    axes[1].axvline(0.75, color="#666666", lw=1, ls=":", label="Stress threshold")
    axes[1].set(title="Hard chronic-state gate", xlabel="Diffused stress h", ylabel="Probability")
    axes[1].text(
        0.98,
        0.04,
        "Eligibility also requires stagnation L > 12",
        transform=axes[1].transAxes,
        ha="right",
        va="bottom",
        fontsize=8,
        color="#555555",
    )
    axes[1].legend(frameon=False)
    for ax in axes:
        ax.grid(alpha=0.2)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1.05)
    fig.tight_layout()
    _save_figure(fig, "fig02_stress_responses")
    atomic_csv(FIGURES / "fig02_stress_responses_data.csv", rows, overwrite=True)


def performance_heatmap() -> None:
    rows = _read_csv(FUNCTION_MEDIANS)
    lookup = {
        (int(row["dimension"]), int(row["function"]), row["algorithm"]): float(
            row["median_log10_error"]
        )
        for row in rows
    }
    comparators = ("CMA-ES-Restart", "DE-rand-1-bin", "Random-Search")
    dimensions = (5, 10, 20, 40)
    data_rows = []
    matrices = []
    for comparator in comparators:
        matrix = np.empty((len(dimensions), 24))
        for row_index, dimension in enumerate(dimensions):
            for function in range(1, 25):
                difference = (
                    lookup[(dimension, function, "SDPO-Full")]
                    - lookup[(dimension, function, comparator)]
                )
                matrix[row_index, function - 1] = difference
                data_rows.append(
                    {
                        "comparator": comparator,
                        "dimension": dimension,
                        "function": function,
                        "sdpo_minus_comparator_median_log10_error": difference,
                        "direction": (
                            "SDPO better"
                            if difference < 0
                            else "SDPO worse"
                            if difference > 0
                            else "tie"
                        ),
                    }
                )
        matrices.append(matrix)
    limit = float(np.quantile(np.abs(np.concatenate([m.ravel() for m in matrices])), 0.95))
    fig, axes = plt.subplots(3, 1, figsize=(11, 6.8), sharex=True)
    image = None
    for ax, comparator, matrix in zip(axes, comparators, matrices, strict=True):
        image = ax.imshow(matrix, aspect="auto", cmap="RdBu_r", vmin=-limit, vmax=limit)
        ax.set_yticks(range(4), labels=dimensions)
        ax.set_ylabel("Dimension")
        ax.set_title(f"SDPO minus {comparator}")
    axes[-1].set_xticks(range(24), labels=range(1, 25))
    axes[-1].set_xlabel("BBOB function")
    assert image is not None
    fig.subplots_adjust(left=0.08, right=0.84, top=0.94, bottom=0.09, hspace=0.36)
    color_axis = fig.add_axes((0.87, 0.16, 0.025, 0.68))
    colorbar = fig.colorbar(image, cax=color_axis)
    colorbar.set_label("Median log-error difference (negative favors SDPO)")
    _save_figure(fig, "fig03_performance_heatmap")
    atomic_csv(FIGURES / "fig03_performance_heatmap_data.csv", data_rows, overwrite=True)


def convergence() -> None:
    summary_rows = _read_csv(SUMMARY)
    groups: dict[tuple[int, str], list[dict[str, str]]] = defaultdict(list)
    for row in summary_rows:
        groups[(int(row["dimension"]), row["algorithm"])].append(row)
    sidecar = []
    curves: dict[tuple[int, str], tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]] = {}
    for dimension in (5, 10, 20, 40):
        budget = 10000 * dimension
        for algorithm in PALETTE:
            group = groups[(dimension, algorithm)]
            if len(group) != 720:
                raise AssertionError("convergence group must contain 720 paired runs")
            checkpoints: np.ndarray | None = None
            values = []
            for row in group:
                path = TRAJECTORIES / _stem(
                    algorithm,
                    int(row["function"]),
                    int(row["instance"]),
                    dimension,
                    int(row["seed"]),
                )
                with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
                    trajectory = list(csv.DictReader(handle))
                current_checkpoints = np.asarray(
                    [int(item["evaluations"]) for item in trajectory], dtype=np.int64
                )
                if checkpoints is None:
                    checkpoints = current_checkpoints
                elif not np.array_equal(checkpoints, current_checkpoints):
                    raise AssertionError("checkpoint mismatch within convergence group")
                best = np.asarray([float(item["best_objective"]) for item in trajectory])
                fopt = float(row["reference_fopt"])
                values.append(np.log10(np.maximum(best - fopt, 0.0) + 1e-12))
            assert checkpoints is not None
            matrix = np.vstack(values)
            med = np.median(matrix, axis=0)
            q1 = np.quantile(matrix, 0.25, axis=0)
            q3 = np.quantile(matrix, 0.75, axis=0)
            fraction = checkpoints / budget
            curves[(dimension, algorithm)] = (fraction, med, q1, q3)
            for index, evaluation in enumerate(checkpoints):
                sidecar.append(
                    {
                        "dimension": dimension,
                        "algorithm": algorithm,
                        "evaluations": int(evaluation),
                        "budget_fraction": fraction[index],
                        "n_runs": matrix.shape[0],
                        "median_log10_error": med[index],
                        "q1_log10_error": q1[index],
                        "q3_log10_error": q3[index],
                    }
                )
    fig, axes = plt.subplots(2, 2, figsize=(10.5, 7.2), sharex=True)
    for ax, dimension in zip(axes.ravel(), (5, 10, 20, 40), strict=True):
        for algorithm in PALETTE:
            x, med, q1, q3 = curves[(dimension, algorithm)]
            ax.plot(
                x,
                med,
                color=PALETTE[algorithm],
                ls=LINESTYLES[algorithm],
                lw=1.8,
                label=algorithm,
            )
            ax.fill_between(x, q1, q3, color=PALETTE[algorithm], alpha=0.10)
        ax.set_xscale("log")
        ax.set_title(f"d={dimension}")
        ax.set_ylabel("Median log10 absolute error")
        ax.grid(alpha=0.2)
    for ax in axes[-1]:
        ax.set_xlabel("Positive evaluation fraction (log scale)")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=4, frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    _save_figure(fig, "fig04_convergence")
    atomic_csv(FIGURES / "fig04_convergence_data.csv", sidecar, overwrite=True)


def ranks_and_effects() -> None:
    rank_rows = _read_csv(RANKS)
    pairwise = _read_csv(PAIRWISE)
    dimensions = np.asarray([5, 10, 20, 40])
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.8))
    sidecar = []
    for algorithm in PALETTE:
        rows = sorted(
            (row for row in rank_rows if row["algorithm"] == algorithm),
            key=lambda row: int(row["dimension"]),
        )
        values = [float(row["mean_rank"]) for row in rows]
        axes[0].plot(
            dimensions,
            values,
            marker="o",
            color=PALETTE[algorithm],
            ls=LINESTYLES[algorithm],
            label=algorithm,
        )
        for row in rows:
            sidecar.append(
                {
                    "panel": "mean_rank",
                    "dimension": row["dimension"],
                    "series": algorithm,
                    "estimate": row["mean_rank"],
                    "holm_adjusted_p_value": "",
                    "significant_after_holm": "",
                    "n_function_blocks": row["n_function_blocks"],
                    "direction": "lower rank is better",
                }
            )
    axes[0].invert_yaxis()
    axes[0].set(
        xlabel="Dimension",
        ylabel="Mean function rank (1 is best)",
        title="Function-block ranks",
    )
    axes[0].set_xticks(dimensions)
    axes[0].grid(alpha=0.2)
    axes[0].legend(frameon=False, fontsize=8)
    comparator_markers = {"CMA-ES-Restart": "o", "DE-rand-1-bin": "s", "Random-Search": "^"}
    for comparator, marker in comparator_markers.items():
        rows = sorted(
            (row for row in pairwise if row["comparator"] == comparator),
            key=lambda row: int(row["dimension"]),
        )
        effects = [float(row["rank_biserial_sdpo_minus_comparator"]) for row in rows]
        (line,) = axes[1].plot(dimensions, effects, label=comparator)
        significant = [row["reject_after_holm"].lower() == "true" for row in rows]
        for dimension, effect, rejected in zip(dimensions, effects, significant, strict=True):
            axes[1].scatter(
                dimension,
                effect,
                marker=marker,
                s=45,
                facecolor=line.get_color() if rejected else "white",
                edgecolor=line.get_color(),
                zorder=3,
            )
        for row in rows:
            sidecar.append(
                {
                    "panel": "rank_biserial",
                    "dimension": row["dimension"],
                    "series": comparator,
                    "estimate": row["rank_biserial_sdpo_minus_comparator"],
                    "holm_adjusted_p_value": row["holm_adjusted_p_value"],
                    "significant_after_holm": row["reject_after_holm"],
                    "n_function_blocks": row["n_function_blocks"],
                    "direction": "negative favors SDPO",
                }
            )
    axes[1].axhline(0, color="#555555", lw=1)
    axes[1].set(xlabel="Dimension", ylabel="Rank-biserial effect", title="SDPO minus comparator")
    axes[1].set_xticks(dimensions)
    axes[1].grid(alpha=0.2)
    axes[1].legend(frameon=False, fontsize=8)
    axes[1].text(
        0.02,
        0.04,
        "Filled marker: Holm-adjusted p < 0.05",
        transform=axes[1].transAxes,
        fontsize=8,
        color="#555555",
    )
    fig.tight_layout()
    _save_figure(fig, "fig05_ranks_effects")
    atomic_csv(FIGURES / "fig05_ranks_effects_data.csv", sidecar, overwrite=True)


def runtime_scaling() -> None:
    rows = _read_csv(RUNTIME)
    dimensions = np.asarray([5, 10, 20, 40])
    fig, ax = plt.subplots(figsize=(6.8, 4.3))
    for algorithm in PALETTE:
        selected = sorted(
            (row for row in rows if row["algorithm"] == algorithm),
            key=lambda row: int(row["dimension"]),
        )
        med = np.asarray([float(row["median_seconds"]) for row in selected])
        low = med - np.asarray([float(row["q1_seconds"]) for row in selected])
        high = np.asarray([float(row["q3_seconds"]) for row in selected]) - med
        ax.errorbar(
            dimensions,
            med,
            yerr=np.vstack((low, high)),
            marker="o",
            capsize=3,
            color=PALETTE[algorithm],
            ls=LINESTYLES[algorithm],
            label=algorithm,
        )
    ax.set_yscale("log")
    ax.set_xticks(dimensions)
    ax.set(
        xlabel="Dimension",
        ylabel="Wall-clock seconds (log scale)",
        title="Exact-budget runtime: median and IQR",
    )
    ax.grid(alpha=0.2)
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    _save_figure(fig, "fig06_runtime_scaling")
    atomic_csv(FIGURES / "fig06_runtime_scaling_data.csv", rows, overwrite=True)


def metadata_and_captions(convergence_generated: bool) -> None:
    script_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    captions = [
        {
            "figure": "fig01_architecture",
            "evidence_status": "method diagram",
            "caption": (
                "SDPO execution pipeline. Arrows show proposal, evaluation, state-update, "
                "and exact-budget dependencies; the graph transports condition state."
            ),
        },
        {
            "figure": "fig02_stress_responses",
            "evidence_status": "analytic method visualization",
            "caption": (
                "Implemented response functions and degradation gate at zero global credit. "
                "Outside the chronic set the realized degradation probability is exactly zero."
            ),
        },
        {
            "figure": "fig03_performance_heatmap",
            "evidence_status": "confirmatory descriptive",
            "caption": (
                "Function-level median log-error differences, SDPO minus comparator. Negative "
                "values favor SDPO; colors are clipped symmetrically at the pooled 95th "
                "absolute percentile for legibility."
            ),
        },
        {
            "figure": "fig04_convergence",
            "evidence_status": "secondary descriptive",
            "caption": (
                "Best-so-far log absolute error across 720 runs per algorithm/dimension. Curves "
                "show median and IQR; x starts at the first positive evaluation and is shown "
                "as a log-scaled fraction of the exact budget."
            ),
        },
        {
            "figure": "fig05_ranks_effects",
            "evidence_status": "confirmatory",
            "caption": (
                "Mean ranks over 24 function-median blocks and matched-pairs rank-biserial "
                "effects for SDPO minus each comparator. Lower rank is better; negative "
                "effect favors SDPO."
            ),
        },
        {
            "figure": "fig06_runtime_scaling",
            "evidence_status": "descriptive hardware-dependent",
            "caption": (
                "Median and IQR wall-clock time over 720 runs per algorithm/dimension. All runs "
                "use 10,000d calls; times reflect four-worker workstation execution and are "
                "not objective-free overhead measurements."
            ),
        },
    ]
    atomic_csv(FIGURES / "figure_caption_drafts.csv", captions, overwrite=True)
    atomic_json(
        FIGURES / "figure_generation_metadata.json",
        {
            "script": "scripts/make_figures.py",
            "script_sha256": script_hash,
            "source_summary": "results/tables/bbob_summary.csv",
            "source_statistics": "results/statistics",
            "source_trajectories": "results/trajectories/bbob",
            "palette": PALETTE,
            "line_styles": LINESTYLES,
            "raster_dpi": 600,
            "vector_formats": ["pdf", "svg"],
            "grayscale_check": "grayscale PNG emitted for every generated figure",
            "convergence_generated": convergence_generated,
            "ablation_figure_status": "blocked until all secondary ablation bundles pass integrity",
        },
        overwrite=True,
    )
    (FIGURES / "fig07_ablation_BLOCKED.md").write_text(
        "# Figure 7 blocked\n\nNo operator-use diagnostic was persisted in "
        "confirmatory raw bundles, "
        "and the matched-budget ablation is incomplete. No proxy figure is authorized.\n",
        encoding="utf-8",
    )


def main() -> None:
    args = parse_args()
    plt.rcParams.update({"font.size": 9, "axes.titlesize": 11, "axes.labelsize": 9})
    architecture()
    stress_responses()
    performance_heatmap()
    ranks_and_effects()
    runtime_scaling()
    if not args.skip_convergence:
        convergence()
    metadata_and_captions(not args.skip_convergence)
    print(
        "publication figures generated with vector, 600-dpi raster, sidecar, and grayscale outputs"
    )


if __name__ == "__main__":
    main()
