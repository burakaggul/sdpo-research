"""Fail-closed analysis of additional SDPO experiments."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import friedmanchisquare, rankdata

from sdpo.statistical_analysis import holm_adjust, paired_wilcoxon

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "results" / "tables"
RAW = ROOT / "results" / "raw"
LOGS = ROOT / "results" / "logs"
STATS = ROOT / "results" / "statistics"
FRAGMENTS = ROOT / "results" / "manuscript_fragments"
REPORTS = ROOT / "reports"
OFFSET = 1e-12
SEEDS = set(range(20260718, 20260724))


def require_complete(name: str, expected: int) -> None:
    status = json.loads((LOGS / name).read_text(encoding="utf-8"))
    observed = (
        status.get("state"),
        status.get("completed_runs"),
        status.get("failed_runs"),
        status.get("total_runs"),
    )
    if observed != ("complete", expected, 0, expected):
        raise SystemExit(f"Incomplete experiment {name}: {observed}")


def load(name: str) -> pd.DataFrame:
    frame = pd.read_csv(TABLES / name)
    frame["log_error"] = np.log10(frame["final_error"].clip(lower=0) + OFFSET)
    return frame


def subset(frame: pd.DataFrame, algorithms: set[str]) -> pd.DataFrame:
    result = frame[
        (frame["dimension"] == 20)
        & (frame["instance"] == 1)
        & frame["seed"].isin(SEEDS)
        & frame["algorithm"].isin(algorithms)
    ].copy()
    identity = ["function", "instance", "dimension", "seed", "algorithm"]
    if len(result) != 24 * 6 * len(algorithms) or result.duplicated(identity).any():
        raise SystemExit(f"Unexpected d=20 subset for {algorithms}: {len(result)}")
    return result


def medians(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.groupby(["function", "algorithm"])["log_error"].median().unstack()
    if len(result) != 24 or result.isna().any().any():
        raise SystemExit("Incomplete function-median matrix")
    return result


def p_tex(value: float) -> str:
    if value < 0.001:
        exponent = int(np.floor(np.log10(value)))
        mantissa = value / 10**exponent
        return rf"{mantissa:.2f}\times10^{{{exponent}}}"
    return f"{value:.4f}"


def quartiles(series: pd.Series) -> tuple[float, float, float]:
    q = series.quantile([0.25, 0.5, 0.75])
    return float(q.loc[0.5]), float(q.loc[0.25]), float(q.loc[0.75])


def mechanism_analysis() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    primary = subset(load("bbob_summary.csv"), {"SDPO-Full"})
    ablation = subset(
        load("ablation_bbob_summary.csv"),
        {
            "SDPO-Ablation-isotropic",
            "SDPO-Ablation-no_degradation",
            "SDPO-Ablation-no_rank_stress",
            "SDPO-Ablation-no_crowding",
            "SDPO-Ablation-no_diff",
        },
    )
    mechanism = subset(
        load("mechanism_analysis_bbob_summary.csv"),
        {
            "SDPO-Config-DegradationDiagnostics-Full",
            "SDPO-Config-DirectionalOff-DegradationOff",
            "SDPO-Config-RankOff-CrowdingOff",
            "SDPO-Config-Rho-0p70",
            "SDPO-Config-Weights-Equal",
            "SDPO-Config-Weights-RankHeavy",
            "SDPO-Config-ArchiveM-25",
            "SDPO-Config-ArchiveM-200",
        },
    )
    original = primary.sort_values(["function", "seed"])["final_error"].to_numpy()
    repeated = mechanism[
        mechanism["algorithm"] == "SDPO-Config-DegradationDiagnostics-Full"
    ].sort_values(["function", "seed"])["final_error"].to_numpy()
    if not np.array_equal(original, repeated):
        raise SystemExit("Fresh diagnostic full run does not reproduce SDPO-Full")

    all_rows = pd.concat([primary, ablation, mechanism], ignore_index=True)
    fm = medians(all_rows)
    definitions = [
        (
            "Directional archive x degradation",
            "SDPO-Config-DirectionalOff-DegradationOff",
            "SDPO-Ablation-no_degradation",
            "SDPO-Ablation-isotropic",
        ),
        (
            "Rank stress x crowding stress",
            "SDPO-Config-RankOff-CrowdingOff",
            "SDPO-Ablation-no_rank_stress",
            "SDPO-Ablation-no_crowding",
        ),
    ]
    tests = []
    for label, joint, first_off, second_off in definitions:
        contrast = fm[joint] - fm[first_off] - fm[second_off] + fm["SDPO-Full"]
        tests.append((label, contrast, paired_wilcoxon(contrast.to_numpy())))
    adjusted = holm_adjust(np.array([item[2].p_value for item in tests]))
    interactions = pd.DataFrame(
        [
            {
                "interaction": label,
                "n_functions": 24,
                "median_interaction_contrast": float(np.median(contrast)),
                "rank_biserial": result.rank_biserial,
                "raw_p": result.p_value,
                "holm_p": float(adj),
                "reject": bool(adj < 0.05),
            }
            for (label, contrast, result), adj in zip(tests, adjusted, strict=True)
        ]
    )
    interactions.to_csv(STATS / "study_interactions.csv", index=False)

    groups = {
        "Diffusion rho": [
            ("0", "SDPO-Ablation-no_diff"),
            ("0.35 (default)", "SDPO-Config-DegradationDiagnostics-Full"),
            ("0.70", "SDPO-Config-Rho-0p70"),
        ],
        "Stress weights": [
            ("(0, 0.5, 0.5)", "SDPO-Ablation-no_rank_stress"),
            ("(1/3, 1/3, 1/3)", "SDPO-Config-Weights-Equal"),
            (
                "(0.4, 0.3, 0.3) default",
                "SDPO-Config-DegradationDiagnostics-Full",
            ),
            ("(0.6, 0.2, 0.2)", "SDPO-Config-Weights-RankHeavy"),
        ],
        "Joint archive capacity M": [
            ("25", "SDPO-Config-ArchiveM-25"),
            ("100 (default)", "SDPO-Config-DegradationDiagnostics-Full"),
            ("200", "SDPO-Config-ArchiveM-200"),
        ],
    }
    rows: list[dict[str, object]] = []
    pairwise_rows: list[dict[str, object]] = []
    for parameter, settings in groups.items():
        default_algorithm = "SDPO-Config-DegradationDiagnostics-Full"
        statistic, p_value = friedmanchisquare(
            *(fm[algorithm].to_numpy() for _, algorithm in settings)
        )
        for setting, algorithm in settings:
            runtime_rows = all_rows[all_rows["algorithm"] == algorithm]
            runtime, q1, q3 = quartiles(runtime_rows["elapsed_seconds"])
            rows.append(
                {
                    "parameter": parameter,
                    "setting": setting,
                    "algorithm": algorithm,
                    "median_function_log_error": float(fm[algorithm].median()),
                    "runtime_median_seconds": runtime,
                    "runtime_q1_seconds": q1,
                    "runtime_q3_seconds": q3,
                    "friedman_statistic": statistic,
                    "friedman_p": p_value,
                }
            )
        if p_value < 0.05:
            comparisons = []
            for setting, algorithm in settings:
                if algorithm == default_algorithm:
                    continue
                diff = fm[default_algorithm].to_numpy() - fm[algorithm].to_numpy()
                comparisons.append((setting, algorithm, diff, paired_wilcoxon(diff)))
            corrections = holm_adjust(np.array([item[3].p_value for item in comparisons]))
            for (setting, algorithm, diff, result), corrected in zip(
                comparisons, corrections, strict=True
            ):
                pairwise_rows.append(
                    {
                        "parameter": parameter,
                        "contrast": f"default minus {setting}",
                        "algorithm": algorithm,
                        "median_difference": float(np.median(diff)),
                        "rank_biserial": result.rank_biserial,
                        "raw_p": result.p_value,
                        "holm_p": float(corrected),
                        "reject": bool(corrected < 0.05),
                    }
                )
    sensitivity = pd.DataFrame(rows)
    pairwise = pd.DataFrame(pairwise_rows)
    sensitivity.to_csv(STATS / "study_sensitivity.csv", index=False)
    pairwise.to_csv(STATS / "study_sensitivity_pairwise.csv", index=False)

    lines = [
        r"\begin{tabular}{llrr}",
        r"\toprule",
        r"Parameter & Setting & Median log-error & Runtime, median [IQR] (s) \\",
        r"\midrule",
    ]
    for parameter, group in sensitivity.groupby("parameter", sort=False):
        first = True
        for _, row in group.iterrows():
            label = parameter if first else ""
            runtime = (
                f"{row.runtime_median_seconds:.2f} "
                f"[{row.runtime_q1_seconds:.2f}, {row.runtime_q3_seconds:.2f}]"
            )
            lines.append(
                f"{label} & {row.setting} & {row.median_function_log_error:.3f} & {runtime} \\\\"
            )
            first = False
        omnibus_p = p_tex(float(group.iloc[0].friedman_p))
        lines.append(f"\\multicolumn{{4}}{{r}}{{Friedman \\(p={omnibus_p}\\)}} \\\\"
        )
        lines.append(r"\addlinespace")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (FRAGMENTS / "study_sensitivity_generated.tex").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )

    lines = [
        r"\begin{tabular}{lrrrr}",
        r"\toprule",
        r"Interaction & Median contrast & \(r_{rb}\) & Raw \(p\) & Holm \(p\) \\",
        r"\midrule",
    ]
    for _, row in interactions.iterrows():
        lines.append(
            f"{row.interaction} & {row.median_interaction_contrast:.3f} & "
            f"{row.rank_biserial:.3f} & \\({p_tex(row.raw_p)}\\) & "
            f"\\({p_tex(row.holm_p)}\\) \\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (FRAGMENTS / "study_interactions_generated.tex").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    return interactions, sensitivity, pairwise


def degradation_analysis() -> pd.DataFrame:
    paths = sorted(
        (RAW / "mechanism_analysis_bbob").glob(
            "sdpo_config_degradationdiagnostics_full_*.json"
        )
    )
    if len(paths) != 144:
        raise SystemExit(f"Expected 144 diagnostic records, found {len(paths)}")
    frame = pd.DataFrame(
        [
            json.loads(path.read_text(encoding="utf-8"))["parameters"]["diagnostics_summary"]
            for path in paths
        ]
    )
    totals = frame.sum(numeric_only=True)
    definitions = [
        (
            "Chronic-set membership",
            "chronic_set_membership",
            "decision",
            "chronic_set_membership_rate",
        ),
        (
            "Degradation selections",
            "degradation_selected",
            "decision",
            "degradation_selection_rate",
        ),
        (
            "Evaluations spent on degradation",
            "degradation_evaluations",
            "post_initialization_evaluations",
            "degradation_evaluation_fraction",
        ),
        (
            "Accepted degradation children",
            "degradation_accepted",
            "degradation_evaluations",
            "degradation_accepted_rate",
        ),
        (
            "Gate fallbacks",
            "degradation_gate_fallback",
            "decision",
            "degradation_gate_fallback_rate",
        ),
    ]
    rows = []
    for label, numerator, denominator, rate_key in definitions:
        count_key = numerator if numerator.endswith("evaluations") else f"{numerator}_count"
        denominator_key = (
            denominator if denominator.endswith("evaluations") else f"{denominator}_count"
        )
        count = int(totals[count_key])
        denom = int(totals[denominator_key])
        rows.append(
            {
                "measure": label,
                "count": count,
                "denominator": denom,
                "pooled_rate": count / denom,
                "run_median_rate": frame[rate_key].median(),
            }
        )
    output = pd.DataFrame(rows)
    output.to_csv(STATS / "study_degradation_diagnostics.csv", index=False)
    lines = [
        r"\begin{tabular}{lrrr}",
        r"\toprule",
        r"Measure & Count/denominator & Pooled rate (\%) & Median run rate (\%) \\",
        r"\midrule",
    ]
    for _, row in output.iterrows():
        lines.append(
            f"{row.measure} & {row['count']:,}/{row.denominator:,} & "
            f"{100 * row.pooled_rate:.3f} & {100 * row.run_median_rate:.3f} \\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (FRAGMENTS / "study_degradation_generated.tex").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    return output


def implementation_analysis() -> pd.DataFrame:
    full = subset(
        load("mechanism_analysis_bbob_summary.csv"),
        {"SDPO-Config-DegradationDiagnostics-Full"},
    )
    inhouse = subset(load("implementation_audit_bbob_summary.csv"), {"CMA-ES-InHouse"})
    pycma = subset(load("bbob_summary.csv"), {"CMA-ES-Restart"})
    fm = medians(pd.concat([full, inhouse, pycma], ignore_index=True))
    focal = "SDPO-Config-DegradationDiagnostics-Full"
    comparisons = []
    for comparator in ("CMA-ES-Restart", "CMA-ES-InHouse"):
        diff = fm[focal].to_numpy() - fm[comparator].to_numpy()
        comparisons.append((comparator, diff, paired_wilcoxon(diff)))
    corrections = holm_adjust(np.array([item[2].p_value for item in comparisons]))
    rows = []
    for (comparator, diff, result), corrected in zip(comparisons, corrections, strict=True):
        rows.append(
            {
                "comparison": f"SDPO-Full minus {comparator}",
                "median_difference": float(np.median(diff)),
                "rank_biserial": result.rank_biserial,
                "raw_p": result.p_value,
                "holm_p": float(corrected),
                "functions_sdpo_worse": int(np.sum(diff > 0)),
                "functions_sdpo_better": int(np.sum(diff < 0)),
            }
        )
    gap = fm["CMA-ES-Restart"].to_numpy() - fm["CMA-ES-InHouse"].to_numpy()
    result = paired_wilcoxon(gap)
    rows.append(
        {
            "comparison": "pycma CMA-ES minus in-house CMA-ES",
            "median_difference": float(np.median(gap)),
            "rank_biserial": result.rank_biserial,
            "raw_p": result.p_value,
            "holm_p": np.nan,
            "functions_sdpo_worse": np.nan,
            "functions_sdpo_better": np.nan,
        }
    )
    output = pd.DataFrame(rows)
    output.to_csv(STATS / "implementation_audit_audit.csv", index=False)
    lines = [
        r"\begin{tabular}{lrrrr}",
        r"\toprule",
        r"Comparison & Median difference & \(r_{rb}\) & Holm \(p\) & SDPO worse/better \\",
        r"\midrule",
    ]
    for _, row in output.iloc[:2].iterrows():
        lines.append(
            f"{row.comparison} & {row.median_difference:.3f} & {row.rank_biserial:.3f} & "
            f"\\({p_tex(row.holm_p)}\\) & "
            f"{int(row.functions_sdpo_worse)}/{int(row.functions_sdpo_better)} \\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (FRAGMENTS / "implementation_audit_generated.tex").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    return output


def modern_comparator_table() -> None:
    extension = pd.read_csv(STATS / "extension_pairwise_holm.csv")
    extension = extension[extension["comparator"].isin(["L-SHADE", "RecPM-AOS-DE"])]
    validation = pd.read_csv(STATS / "validation_pairwise_holm.csv")
    validation = validation[
        validation["comparator"].isin(["L-SHADE", "RecPM-AOS-DE", "SDPO-Full"])
    ]
    lines = [
        r"\begin{tabular}{lrlrrr}",
        r"\toprule",
        r"Study & \(d\) & Comparator & Median difference & \(r_{rb}\) & Holm \(p\) \\",
        r"\midrule",
    ]
    for study, frame in (("Extension", extension), ("Validation", validation)):
        for _, row in frame.sort_values(["dimension", "comparator"]).iterrows():
            lines.append(
                f"{study} & {int(row.dimension)} & {row.comparator} & "
                f"{row.median_difference_focal_minus_comparator:.3f} & "
                f"{row.rank_biserial_focal_minus_comparator:.3f} & "
                f"\\({p_tex(row.holm_adjusted_p_value)}\\) \\\\"
            )
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (FRAGMENTS / "study_modern_comparators_generated.tex").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def noise_analysis() -> tuple[pd.DataFrame, pd.DataFrame]:
    require_complete("official_noise_analysis_bbob_status.json", 96)
    data = load("official_noise_analysis_bbob_summary.csv")
    algorithms = {"SDPO-Full", "SDPO-Config-NoDiff", "L-SHADE", "CMA-ES-Restart"}
    identity = ["function", "instance", "dimension", "seed", "algorithm"]
    if (
        len(data) != 96
        or set(data["algorithm"]) != algorithms
        or set(data["function"]) != {101, 102, 103, 128, 129, 130}
        or data.duplicated(identity).any()
        or not (data["evaluations"] == 200000).all()
        or not (data["framework_native_evaluations"] == 200000).all()
    ):
        raise SystemExit("Official noisy BBOB design or counters are incomplete")
    fm = data.groupby(["function", "algorithm"])["log_error"].median().unstack()
    ordered = sorted(algorithms)
    statistic, omnibus_p = friedmanchisquare(*(fm[name].to_numpy() for name in ordered))
    ranks = pd.DataFrame(
        np.vstack([rankdata(row, method="average") for row in fm[ordered].to_numpy()]),
        columns=ordered,
    ).mean()
    summary = pd.DataFrame(
        [
            {
                "algorithm": algorithm,
                "median_function_log_error": float(fm[algorithm].median()),
                "mean_rank": float(ranks[algorithm]),
                "friedman_statistic": statistic,
                "friedman_p": omnibus_p,
            }
            for algorithm in ordered
        ]
    )
    tests = []
    for comparator in ("SDPO-Config-NoDiff", "L-SHADE", "CMA-ES-Restart"):
        diff = fm["SDPO-Full"].to_numpy() - fm[comparator].to_numpy()
        tests.append((comparator, diff, paired_wilcoxon(diff)))
    corrections = holm_adjust(np.array([item[2].p_value for item in tests]))
    pairwise = pd.DataFrame(
        [
            {
                "comparison": f"SDPO-Full minus {comparator}",
                "median_difference": float(np.median(diff)),
                "rank_biserial": result.rank_biserial,
                "raw_p": result.p_value,
                "holm_p": float(corrected),
                "reject": bool(corrected < 0.05),
            }
            for (comparator, diff, result), corrected in zip(tests, corrections, strict=True)
        ]
    )
    summary.to_csv(STATS / "official_noise_analysis_summary.csv", index=False)
    pairwise.to_csv(STATS / "official_noise_analysis_pairwise.csv", index=False)
    lines = [
        r"\begin{tabular}{lrr}",
        r"\toprule",
        r"Algorithm & Median log-error & Mean rank \\",
        r"\midrule",
    ]
    for _, row in summary.sort_values("mean_rank").iterrows():
        lines.append(
            f"{row.algorithm} & {row.median_function_log_error:.3f} & {row.mean_rank:.3f} \\\\"
        )
    lines.append(r"\midrule")
    lines.append(
        f"\\multicolumn{{3}}{{r}}{{Friedman \\(p={p_tex(float(omnibus_p))}\\)}} \\\\"
    )
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (FRAGMENTS / "controlled_noise_analysis_summary_generated.tex").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    return summary, pairwise


def main() -> None:
    require_complete("mechanism_analysis_bbob_status.json", 1296)
    require_complete("implementation_audit_bbob_status.json", 144)
    STATS.mkdir(parents=True, exist_ok=True)
    FRAGMENTS.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    interactions, sensitivity, sensitivity_pairwise = mechanism_analysis()
    degradation = degradation_analysis()
    implementation = implementation_analysis()
    modern_comparator_table()
    noise_summary, noise_pairwise = noise_analysis()
    sections = [
        ("Two-factor interactions", interactions),
        ("Sensitivity", sensitivity),
        ("Conditional sensitivity pairwise tests", sensitivity_pairwise),
        ("Degradation diagnostics", degradation),
        ("CMA implementation audit", implementation),
        ("Official noisy BBOB subset", noise_summary),
        ("Official noisy BBOB pairwise tests", noise_pairwise),
    ]
    lines = [
        "# Additional experiments",
        "",
        "All additional experiments completed without failed runs. Function medians are",
        "the inferential blocks; lower log-error is better.",
    ]
    for title, frame in sections:
        lines.extend(["", f"## {title}", "", frame.to_markdown(index=False)])
    (REPORTS / "study_experiments_report.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print("Additional analysis and manuscript fragments written.")


if __name__ == "__main__":
    main()
