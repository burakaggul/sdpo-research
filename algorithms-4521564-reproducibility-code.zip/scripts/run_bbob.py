"""Run resumable, exact-budget COCO/BBOB experiments with bounded trajectory storage."""

from __future__ import annotations

import argparse
import json
import os
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from pathlib import Path
from typing import Any

import yaml

from sdpo.benchmark_adapters import CocoBbobAdapter
from sdpo.competitors import (
    cma_es,
    cma_es_inhouse,
    differential_evolution_rand1bin,
    lshade,
    random_search,
    recpm_aos_de,
    sdpo_ablation,
    sdpo_configured,
    sdpo_full,
    sdpo_revised,
)
from sdpo.logging_utils import atomic_csv, atomic_gzip_csv, atomic_json
from sdpo.noise import RelativeLognormalNoise
from sdpo.reproducibility import runtime_metadata
from sdpo.trajectory import checkpoint_evaluations, sample_best_so_far

ROOT = Path(__file__).resolve().parents[1]
ALGORITHMS = {
    "Random-Search": random_search,
    "DE-rand-1-bin": differential_evolution_rand1bin,
    "CMA-ES-Restart": cma_es,
    "CMA-ES-InHouse": cma_es_inhouse,
    "SDPO-Full": sdpo_full,
    "SDPO-R1": sdpo_revised,
    "L-SHADE": lshade,
    "RecPM-AOS-DE": recpm_aos_de,
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "configs" / "bbob.yaml")
    parser.add_argument("--workers", type=int)
    parser.add_argument("--max-runs", type=int)
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def _stem(spec: dict[str, Any]) -> str:
    algorithm = str(spec["algorithm"]).lower().replace("-", "_")
    suite_tag = str(spec.get("suite_name", "bbob")).replace("-", "_")
    return (
        f"{algorithm}_{suite_tag}_f{spec['function']:03d}_i{spec['instance']:02d}_"
        f"d{spec['dimension']}_s{spec['seed']}"
    )


def _run_one(spec: dict[str, Any]) -> dict[str, Any]:
    algorithm_name = str(spec["algorithm"])
    variant_prefix = "SDPO-Ablation-"
    configured_prefix = "SDPO-Config-"
    if algorithm_name.startswith(variant_prefix):
        algorithm = sdpo_ablation
    elif algorithm_name.startswith(configured_prefix):
        algorithm = sdpo_configured
    else:
        algorithm = ALGORITHMS[algorithm_name]
    adapter = CocoBbobAdapter(
        spec["function"],
        spec["dimension"],
        spec["instance"],
        suite_name=spec.get("suite_name", "bbob"),
    )
    try:
        noise_sigma = float(spec.get("observation_noise_sigma", 0.0))
        objective: Any = adapter
        noisy_objective: RelativeLognormalNoise | None = None
        if noise_sigma > 0.0:
            noisy_objective = RelativeLognormalNoise(
                adapter,
                float(spec["fopt"]),
                noise_sigma,
                int(spec["noise_seed"]),
            )
            objective = noisy_objective
        kwargs: dict[str, Any] = dict(spec.get("algorithm_kwargs", {}))
        kwargs.setdefault("population_size", spec["population_size"])
        if algorithm is sdpo_ablation:
            kwargs["variant"] = algorithm_name.removeprefix(variant_prefix)
        result = algorithm(
            objective, adapter.lower, adapter.upper, spec["budget"], spec["seed"], **kwargs
        )
        if result.evaluations != spec["budget"] or adapter.native_evaluations != spec["budget"]:
            raise AssertionError("project and COCO evaluation counters diverged")
        shadow_best_objective: float | None = None
        if noisy_objective is not None or "shadow_function" in spec:
            if noisy_objective is not None and noisy_objective.calls != spec["budget"]:
                raise AssertionError("noise wrapper and optimizer evaluation counters diverged")
            shadow_function = int(spec.get("shadow_function", spec["function"]))
            shadow_suite_name = str(
                spec.get("shadow_suite_name", spec.get("suite_name", "bbob"))
            )
            shadow = CocoBbobAdapter(
                shadow_function,
                spec["dimension"],
                spec["instance"],
                suite_name=shadow_suite_name,
            )
            try:
                shadow_best_objective = shadow(result.best_solution)
                if shadow.native_evaluations != 1:
                    raise AssertionError("shadow evaluator must receive exactly one call")
            finally:
                shadow.close()
        checkpoints = checkpoint_evaluations(
            spec["budget"],
            dense_prefix=spec["dense_prefix"],
            logarithmic_points=spec["logarithmic_points"],
        )
        sampled = sample_best_so_far(result.trajectory, checkpoints)
        parameters = dict(result.parameters)
        if noisy_objective is not None:
            parameters["controlled_observation_noise"] = {
                "model": "fopt + max(f-fopt,0) * exp(sigma*Z), Z~N(0,1)",
                "sigma": noise_sigma,
                "noise_seed": int(spec["noise_seed"]),
                "common_random_numbers_by_evaluation_index": True,
                "selection_objective": "noisy observation",
                "reported_final_error": "independent noiseless shadow evaluation",
            }
        elif shadow_best_objective is not None:
            parameters["official_noisy_bbob_evaluation"] = {
                "optimization_suite": str(spec["suite_name"]),
                "noiseless_shadow_suite": str(spec["shadow_suite_name"]),
                "noiseless_shadow_function": int(spec["shadow_function"]),
                "shared_optimum_verified": True,
                "reported_final_error": "one noiseless shadow evaluation of returned solution",
            }
        error_objective = (
            shadow_best_objective
            if shadow_best_objective is not None
            else result.best_objective
        )
        payload = {
            "schema_version": 1,
            "run_type": spec["run_type"],
            "metadata": spec["metadata"],
            "framework": spec.get("framework_label", "COCO/BBOB"),
            "framework_version": "2.8.2",
            "problem_id": adapter.identifier,
            "function": spec["function"],
            "instance": spec["instance"],
            "dimension": spec["dimension"],
            "algorithm": spec["algorithm"],
            "seed": spec["seed"],
            "evaluation_budget": spec["budget"],
            "evaluations": result.evaluations,
            "framework_native_evaluations": adapter.native_evaluations,
            "best_objective": result.best_objective,
            "reference_fopt": spec["fopt"],
            "final_error": max(error_objective - spec["fopt"], 0.0),
            "best_solution": result.best_solution,
            "elapsed_seconds": result.elapsed_seconds,
            "termination_reason": result.termination_reason,
            "parameters": parameters,
            "trajectory_policy": {
                "dense_prefix": spec["dense_prefix"],
                "logarithmic_points": spec["logarithmic_points"],
                "stored_rows": len(sampled),
                "compression": "gzip",
            },
        }
        if shadow_best_objective is not None:
            payload["observed_best_objective"] = result.best_objective
            payload["observed_final_error"] = max(
                result.best_objective - spec["fopt"], 0.0
            )
            payload["shadow_best_objective"] = shadow_best_objective
            payload["shadow_native_evaluations_not_charged_to_optimizer"] = 1
    finally:
        adapter.close()
    stem = _stem(spec)
    atomic_json(Path(spec["raw_root"]) / f"{stem}.json", payload, overwrite=spec["force"])
    atomic_gzip_csv(
        Path(spec["trajectory_root"]) / f"{stem}.csv.gz",
        sampled,
        overwrite=spec["force"],
    )
    return payload


def _summary_row(payload: dict[str, Any]) -> dict[str, object]:
    keys = (
        "framework",
        "problem_id",
        "function",
        "instance",
        "dimension",
        "algorithm",
        "seed",
        "evaluation_budget",
        "evaluations",
        "framework_native_evaluations",
        "best_objective",
        "reference_fopt",
        "final_error",
        "elapsed_seconds",
        "termination_reason",
    )
    row = {key: payload[key] for key in keys}
    for key in (
        "observed_best_objective",
        "observed_final_error",
        "shadow_best_objective",
        "shadow_native_evaluations_not_charged_to_optimizer",
    ):
        if key in payload:
            row[key] = payload[key]
    return row


def _validate_resumed(raw_path: Path, trajectory_path: Path, budget: int) -> None:
    if raw_path.exists() != trajectory_path.exists():
        raise RuntimeError(f"incomplete result bundle: {raw_path.stem}")
    payload = json.loads(raw_path.read_text(encoding="utf-8"))
    if (
        payload["evaluation_budget"] != budget
        or payload["evaluations"] != budget
        or payload["framework_native_evaluations"] != budget
        or payload["termination_reason"] != "evaluation_budget_exhausted"
    ):
        raise RuntimeError(f"incompatible resumed result: {raw_path}")


def _reference_fopts(config: dict[str, Any]) -> dict[str, float]:
    suite_name = str(config.get("suite_name", "bbob"))
    reference_suite_name = str(config.get("reference_suite_name", suite_name))
    reference_function_map = {
        str(key): int(value) for key, value in config.get("reference_function_map", {}).items()
    }
    cache_tag = str(config.get("reference_cache_tag", suite_name)).replace("-", "_")
    cache_name = f"{cache_tag}_reference_fopt.json"
    path = ROOT / "results" / "metadata" / cache_name
    cache = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    changed = False
    for function in map(int, config["functions"]):
        for dimension in map(int, config["dimensions"]):
            for instance in map(int, config["instances"]):
                key = f"f{function:03d}_d{dimension}_i{instance:02d}"
                if key not in cache:
                    reference_function = reference_function_map.get(str(function), function)
                    cache[key] = CocoBbobAdapter.reference_fopt(
                        reference_function,
                        dimension,
                        instance,
                        suite_name=reference_suite_name,
                    )
                    changed = True
    if changed:
        atomic_json(path, cache, overwrite=True)
    return {str(key): float(value) for key, value in cache.items()}


def _write_status(path: Path, *, total: int, complete: int, failed: int, state: str) -> None:
    atomic_json(
        path,
        {
            "total_runs": total,
            "completed_runs": complete,
            "failed_runs": failed,
            "state": state,
            "runner_pid": os.getpid(),
        },
        overwrite=True,
    )


def main() -> None:
    args = parse_args()
    config_path = args.config if args.config.is_absolute() else ROOT / args.config
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    experiment_mode = str(config.get("experiment_mode", ""))
    if experiment_mode not in {
        "shakedown",
        "confirmatory",
        "ablation_shakedown",
        "secondary_ablation",
        "comparative_extension",
        "untouched_validation",
        "extension_shakedown",
        "validation_shakedown",
        "mechanism_analysis",
        "controlled_noise_analysis",
        "implementation_audit",
        "official_noise_analysis",
    }:
        raise ValueError(
            "experiment_mode must be shakedown, confirmatory, ablation_shakedown, "
            "secondary_ablation, comparative_extension, untouched_validation, "
            "extension_shakedown, validation_shakedown, mechanism_analysis, "
            "controlled_noise_analysis, implementation_audit, or official_noise_analysis"
        )
    is_shakedown = experiment_mode == "shakedown"
    is_ablation_shakedown = experiment_mode == "ablation_shakedown"
    is_ablation = experiment_mode == "secondary_ablation"
    if experiment_mode == "extension_shakedown":
        namespace, run_type = (
            "extension_shakedown_bbob",
            "comparator_extension_pipeline_shakedown_not_evidence",
        )
    elif experiment_mode == "validation_shakedown":
        namespace, run_type = (
            "validation_shakedown_bbob_largescale",
            "untouched_validation_pipeline_shakedown_not_evidence",
        )
    elif experiment_mode == "mechanism_analysis":
        namespace, run_type = (
            "mechanism_analysis_bbob",
            "supplemental_mechanism_sensitivity_and_implementation_audit",
        )
    elif experiment_mode == "controlled_noise_analysis":
        namespace, run_type = (
            "controlled_noise_analysis_bbob",
            "supplemental_controlled_noise_robustness",
        )
    elif experiment_mode == "implementation_audit":
        namespace, run_type = (
            "implementation_audit_bbob",
            "supplemental_comparable_inhouse_cma_audit",
        )
    elif experiment_mode == "official_noise_analysis":
        namespace, run_type = (
            "official_noise_analysis_bbob",
            "supplemental_official_bbob_noisy_subset",
        )
    elif is_shakedown:
        namespace, run_type = "shakedown_bbob", "pipeline_shakedown_not_evidence"
    elif is_ablation_shakedown:
        namespace, run_type = (
            "ablation_shakedown_bbob",
            "ablation_pipeline_shakedown_not_evidence",
        )
    elif is_ablation:
        namespace, run_type = "ablation_bbob", "secondary_posthoc_ablation"
    elif experiment_mode == "comparative_extension":
        namespace, run_type = "extension_bbob", "secondary_comparator_extension"
    elif experiment_mode == "untouched_validation":
        namespace, run_type = "validation_bbob_largescale", "untouched_external_validation"
    else:
        namespace, run_type = "bbob", "confirmatory_benchmark"
    raw_root = ROOT / "results" / "raw" / namespace
    trajectory_root = ROOT / "results" / "trajectories" / namespace
    table_path = ROOT / "results" / "tables" / f"{namespace}_summary.csv"
    status_path = ROOT / "results" / "logs" / f"{namespace}_status.json"
    workers = int(args.workers or config["workers"])
    if workers < 1:
        raise ValueError("workers must be positive")
    metadata = runtime_metadata(ROOT)
    fopts = _reference_fopts(config)
    suite_name = str(config.get("suite_name", "bbob"))
    framework_label = str(config.get("framework_label", "COCO/BBOB"))
    algorithm_parameters = config.get("algorithm_parameters", {})
    policy = config["trajectory_policy"]
    specs: list[dict[str, Any]] = []
    complete = 0
    for function in map(int, config["functions"]):
        for dimension in map(int, config["dimensions"]):
            budget = int(
                config.get(
                    "evaluation_budget",
                    int(config.get("evaluation_budget_multiplier", 0)) * dimension,
                )
            )
            if budget < int(config["population_size"]):
                raise ValueError("budget must cover algorithm initialization")
            for instance in map(int, config["instances"]):
                key = f"f{function:03d}_d{dimension}_i{instance:02d}"
                for seed in map(int, config["seeds"]):
                    for algorithm in config["algorithms"]:
                        spec = {
                            "function": function,
                            "dimension": dimension,
                            "instance": instance,
                            "seed": seed,
                            "algorithm": str(algorithm),
                            "algorithm_kwargs": dict(algorithm_parameters.get(str(algorithm), {})),
                            "budget": budget,
                            "population_size": int(config["population_size"]),
                            "dense_prefix": int(policy["dense_prefix"]),
                            "logarithmic_points": int(policy["logarithmic_points"]),
                            "fopt": fopts[key],
                            "metadata": metadata,
                            "run_type": run_type,
                            "suite_name": suite_name,
                            "framework_label": framework_label,
                            "raw_root": str(raw_root),
                            "trajectory_root": str(trajectory_root),
                            "force": args.force,
                        }
                        if "observation_noise_sigma" in config:
                            spec["observation_noise_sigma"] = float(
                                config["observation_noise_sigma"]
                            )
                            spec["noise_seed"] = int(config["noise_seed_base"]) + (
                                1_000_003 * function + 10_007 * dimension + 101 * instance + seed
                            )
                        shadow_map = config.get("shadow_function_map", {})
                        if str(function) in shadow_map:
                            spec["shadow_function"] = int(shadow_map[str(function)])
                            spec["shadow_suite_name"] = str(config["shadow_suite_name"])
                        stem = _stem(spec)
                        raw_path = raw_root / f"{stem}.json"
                        trajectory_path = trajectory_root / f"{stem}.csv.gz"
                        if raw_path.exists() and trajectory_path.exists() and not args.force:
                            _validate_resumed(raw_path, trajectory_path, budget)
                            complete += 1
                        else:
                            specs.append(spec)
    total = complete + len(specs)
    if args.max_runs is not None:
        if args.max_runs < 0:
            raise ValueError("max-runs cannot be negative")
        specs = specs[: args.max_runs]
    _write_status(status_path, total=total, complete=complete, failed=0, state="running")
    failed = 0
    if specs:
        with ProcessPoolExecutor(max_workers=workers) as executor:
            iterator = iter(specs)
            active = {
                executor.submit(_run_one, spec)
                for spec in [next(iterator, None) for _ in range(workers)]
                if spec is not None
            }
            while active:
                done, active = wait(active, return_when=FIRST_COMPLETED)
                for future in done:
                    try:
                        payload = future.result()
                    except Exception:
                        failed += 1
                        _write_status(
                            status_path,
                            total=total,
                            complete=complete,
                            failed=failed,
                            state="failed",
                        )
                        raise
                    complete += 1
                    print(
                        f"completed {complete}/{total}: {payload['problem_id']} "
                        f"{payload['algorithm']} seed={payload['seed']}"
                    )
                    next_spec = next(iterator, None)
                    if next_spec is not None:
                        active.add(executor.submit(_run_one, next_spec))
                    _write_status(
                        status_path,
                        total=total,
                        complete=complete,
                        failed=failed,
                        state="running",
                    )
    rows = [
        _summary_row(json.loads(path.read_text(encoding="utf-8")))
        for path in sorted(raw_root.glob("*.json"))
    ]
    if rows:
        atomic_csv(table_path, rows, overwrite=True)
    state = "complete" if complete == total else "partial"
    _write_status(status_path, total=total, complete=complete, failed=failed, state=state)
    print(f"{namespace}: state={state} complete={complete}/{total} failed={failed}")


if __name__ == "__main__":
    main()
