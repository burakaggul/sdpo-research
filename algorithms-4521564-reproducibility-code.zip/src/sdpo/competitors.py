"""Small-pilot competitors with explicit seed and evaluation accounting."""

from __future__ import annotations

from dataclasses import dataclass, fields
from time import perf_counter

import numpy as np
from numpy.typing import NDArray

from .ablations import ablation_config
from .boundary import reflect
from .core import EvaluationBudget, Objective, SDPOConfig, optimize

FloatArray = NDArray[np.float64]


@dataclass
class PilotResult:
    best_solution: FloatArray
    best_objective: float
    evaluations: int
    elapsed_seconds: float
    termination_reason: str
    trajectory: list[tuple[int, float]]
    parameters: dict[str, object]


def _evaluate_population(
    evaluator: EvaluationBudget,
    population: FloatArray,
    trajectory: list[tuple[int, float]],
    best_value: float,
) -> tuple[FloatArray, float, FloatArray]:
    values = np.empty(population.shape[0], dtype=np.float64)
    best_solution = population[0].copy()
    for index, candidate in enumerate(population):
        value = evaluator.evaluate(candidate)
        values[index] = value
        if value < best_value:
            best_value = value
            best_solution = candidate.copy()
        trajectory.append((evaluator.count, best_value))
    return values, best_value, best_solution


def random_search(
    objective: Objective,
    lower: FloatArray,
    upper: FloatArray,
    budget: int,
    seed: int,
    *,
    population_size: int = 20,
) -> PilotResult:
    start = perf_counter()
    rng = np.random.default_rng(seed)
    evaluator = EvaluationBudget(objective, budget)
    trajectory: list[tuple[int, float]] = []
    best_value = np.inf
    best_solution = np.asarray(lower, dtype=np.float64).copy()
    while evaluator.remaining:
        candidate = rng.uniform(lower, upper)
        value = evaluator.evaluate(candidate)
        if value < best_value:
            best_value, best_solution = value, candidate.copy()
        trajectory.append((evaluator.count, best_value))
    return PilotResult(
        best_solution,
        float(best_value),
        evaluator.count,
        perf_counter() - start,
        "evaluation_budget_exhausted",
        trajectory,
        {"sampling": "independent uniform", "population_size": "not applicable"},
    )


def differential_evolution_rand1bin(
    objective: Objective,
    lower: FloatArray,
    upper: FloatArray,
    budget: int,
    seed: int,
    *,
    population_size: int = 20,
    differential_weight: float = 0.5,
    crossover_probability: float = 0.9,
) -> PilotResult:
    """Explicit DE/rand/1/bin following Storn--Price with reflected bounds."""
    if population_size < 4 or budget < population_size:
        raise ValueError("DE requires population >=4 and a budget covering initialization")
    start = perf_counter()
    rng = np.random.default_rng(seed)
    evaluator = EvaluationBudget(objective, budget)
    population = rng.uniform(lower, upper, size=(population_size, lower.size))
    trajectory: list[tuple[int, float]] = []
    values, best_value, best_solution = _evaluate_population(
        evaluator, population, trajectory, np.inf
    )
    indices = np.arange(population_size)
    while evaluator.remaining:
        for target in range(population_size):
            if not evaluator.remaining:
                break
            pool = indices[indices != target]
            r1, r2, r3 = rng.choice(pool, size=3, replace=False)
            mutant = population[r1] + differential_weight * (population[r2] - population[r3])
            mask = rng.random(lower.size) < crossover_probability
            mask[int(rng.integers(lower.size))] = True
            trial = reflect(np.where(mask, mutant, population[target]), lower, upper)
            value = evaluator.evaluate(trial)
            if value <= values[target]:
                population[target], values[target] = trial, value
            if value < best_value:
                best_value, best_solution = value, trial.copy()
            trajectory.append((evaluator.count, best_value))
    return PilotResult(
        best_solution,
        float(best_value),
        evaluator.count,
        perf_counter() - start,
        "evaluation_budget_exhausted",
        trajectory,
        {
            "strategy": "DE/rand/1/bin",
            "population_size": population_size,
            "F": differential_weight,
            "CR": crossover_probability,
            "boundary": "reflection",
        },
    )


def _midpoint_repair(
    mutant: FloatArray, parent: FloatArray, lower: FloatArray, upper: FloatArray
) -> FloatArray:
    """L-SHADE boundary correction from Tanabe--Fukunaga."""
    repaired = mutant.copy()
    below = repaired < lower
    above = repaired > upper
    repaired[below] = (lower[below] + parent[below]) / 2.0
    repaired[above] = (upper[above] + parent[above]) / 2.0
    return repaired


def lshade(
    objective: Objective,
    lower: FloatArray,
    upper: FloatArray,
    budget: int,
    seed: int,
    *,
    population_size: int | None = None,
    memory_size: int = 5,
    p_best_rate: float = 0.11,
    archive_rate: float = 1.4,
    minimum_population_size: int = 4,
) -> PilotResult:
    """Independent L-SHADE 1.0.1-style implementation with exact accounting.

    The implementation follows current-to-pbest/1, success-history memories,
    an external archive, and linear population-size reduction. It is written
    from the paper rather than copied from the authors' source distribution.
    """
    dimension = int(lower.size)
    initial_size = int(population_size or max(minimum_population_size, 18 * dimension))
    if initial_size < 4 or minimum_population_size < 4:
        raise ValueError("L-SHADE requires population sizes of at least four")
    if budget < initial_size or memory_size < 1:
        raise ValueError("L-SHADE budget must cover initialization and H must be positive")
    start = perf_counter()
    rng = np.random.default_rng(seed)
    evaluator = EvaluationBudget(objective, budget)
    population = rng.uniform(lower, upper, size=(initial_size, dimension))
    trajectory: list[tuple[int, float]] = []
    values, best_value, best_solution = _evaluate_population(
        evaluator, population, trajectory, np.inf
    )
    archive = np.empty((0, dimension), dtype=np.float64)
    memory_f = np.full(memory_size, 0.5, dtype=np.float64)
    memory_cr = np.full(memory_size, 0.5, dtype=np.float64)
    memory_index = 0

    while evaluator.remaining:
        size = population.shape[0]
        successful_f: list[float] = []
        successful_cr: list[float] = []
        improvements: list[float] = []
        accepted_parents: list[FloatArray] = []
        next_population = population.copy()
        next_values = values.copy()
        order = np.argsort(values, kind="stable")
        p_count = min(size, max(2, int(np.ceil(p_best_rate * size))))

        for target in range(size):
            if not evaluator.remaining:
                break
            slot = int(rng.integers(memory_size))
            cr = float(np.clip(rng.normal(memory_cr[slot], 0.1), 0.0, 1.0))
            f = -1.0
            while f <= 0.0:
                f = float(memory_f[slot] + 0.1 * rng.standard_cauchy())
            f = min(f, 1.0)
            pbest = int(rng.choice(order[:p_count]))
            candidates = np.arange(size)
            candidates = candidates[(candidates != target) & (candidates != pbest)]
            r1 = int(rng.choice(candidates))
            union = np.vstack((population, archive)) if archive.size else population
            forbidden = {target, pbest, r1}
            union_choices = np.array(
                [idx for idx in range(union.shape[0]) if idx >= size or idx not in forbidden],
                dtype=np.int64,
            )
            r2 = int(rng.choice(union_choices))
            mutant = population[target] + f * (population[pbest] - population[target])
            mutant += f * (population[r1] - union[r2])
            mutant = _midpoint_repair(mutant, population[target], lower, upper)
            mask = rng.random(dimension) <= cr
            mask[int(rng.integers(dimension))] = True
            trial = np.where(mask, mutant, population[target])
            trial_value = evaluator.evaluate(trial)
            if trial_value < best_value:
                best_value, best_solution = trial_value, trial.copy()
            trajectory.append((evaluator.count, best_value))
            if trial_value <= values[target]:
                next_population[target] = trial
                next_values[target] = trial_value
            if trial_value < values[target]:
                accepted_parents.append(population[target].copy())
                successful_f.append(f)
                successful_cr.append(cr)
                improvements.append(float(values[target] - trial_value))

        population, values = next_population, next_values
        if accepted_parents:
            archive = np.vstack((archive, np.asarray(accepted_parents)))
            weights = np.asarray(improvements, dtype=np.float64)
            weights /= weights.sum()
            sf = np.asarray(successful_f, dtype=np.float64)
            scr = np.asarray(successful_cr, dtype=np.float64)
            memory_f[memory_index] = float(np.sum(weights * sf * sf) / np.sum(weights * sf))
            memory_cr[memory_index] = float(np.sum(weights * scr))
            memory_index = (memory_index + 1) % memory_size

        planned_size = int(
            round(
                initial_size + (minimum_population_size - initial_size) * evaluator.count / budget
            )
        )
        planned_size = max(minimum_population_size, min(planned_size, population.shape[0]))
        if planned_size < population.shape[0]:
            keep = np.argsort(values, kind="stable")[:planned_size]
            population, values = population[keep], values[keep]
        archive_capacity = int(round(archive_rate * population.shape[0]))
        if archive.shape[0] > archive_capacity:
            chosen = rng.choice(archive.shape[0], size=archive_capacity, replace=False)
            archive = archive[chosen]

    return PilotResult(
        best_solution,
        float(best_value),
        evaluator.count,
        perf_counter() - start,
        "evaluation_budget_exhausted",
        trajectory,
        {
            "strategy": "L-SHADE/current-to-pbest/1/bin",
            "implementation": "independent paper-based L-SHADE 1.0.1-style",
            "initial_population_size": initial_size,
            "minimum_population_size": minimum_population_size,
            "memory_size": memory_size,
            "p_best_rate": p_best_rate,
            "archive_rate": archive_rate,
            "boundary": "parent-bound midpoint repair",
        },
    )


def recpm_aos_de(
    objective: Objective,
    lower: FloatArray,
    upper: FloatArray,
    budget: int,
    seed: int,
    *,
    population_size: int = 200,
    differential_weight: float = 0.5,
    crossover_probability: float = 1.0,
    minimum_probability: float = 0.0,
    discount_rate: float = 0.6,
) -> PilotResult:
    """DE with four-strategy Recursive Probability Matching AOS.

    Defaults are the paper's untuned/default RecPM3 setting. Operator rewards
    use offspring survival rate and the Bellman-style quality system.
    """
    if population_size < 6 or budget < population_size:
        raise ValueError("RecPM-AOS-DE requires NP>=6 and budget covering initialization")
    if not 0.0 <= minimum_probability <= 0.25 or not 0.0 <= discount_rate < 1.0:
        raise ValueError("invalid RecPM probability or discount setting")
    start = perf_counter()
    rng = np.random.default_rng(seed)
    evaluator = EvaluationBudget(objective, budget)
    dimension = int(lower.size)
    population = rng.uniform(lower, upper, size=(population_size, dimension))
    trajectory: list[tuple[int, float]] = []
    values, best_value, best_solution = _evaluate_population(
        evaluator, population, trajectory, np.inf
    )
    operator_count = 4
    probabilities = np.full(operator_count, 1.0 / operator_count)
    rewards = np.zeros(operator_count, dtype=np.float64)
    untried = list(range(operator_count))
    generations = 0

    while evaluator.remaining:
        next_population = population.copy()
        next_values = values.copy()
        applications = np.zeros(operator_count, dtype=np.int64)
        survivals = np.zeros(operator_count, dtype=np.int64)
        best_index = int(np.argmin(values))

        for target in range(population_size):
            if not evaluator.remaining:
                break
            if untried:
                pick = int(rng.integers(len(untried)))
                operator = untried.pop(pick)
            else:
                operator = int(rng.choice(operator_count, p=probabilities))
            applications[operator] += 1
            pool = np.arange(population_size)
            pool = pool[pool != target]
            needed = 5 if operator in {1, 2} else 3
            chosen = rng.choice(pool, size=needed, replace=False)
            f = differential_weight
            if operator == 0:  # rand/1
                r1, r2, r3 = chosen[:3]
                mutant = population[r1] + f * (population[r2] - population[r3])
            elif operator == 1:  # rand/2
                r1, r2, r3, r4, r5 = chosen
                mutant = population[r1] + f * (
                    population[r2] - population[r3] + population[r4] - population[r5]
                )
            elif operator == 2:  # rand-to-best/2
                r1, r2, r3, r4, r5 = chosen
                mutant = population[r1] + f * (
                    population[best_index]
                    - population[r1]
                    + population[r2]
                    - population[r3]
                    + population[r4]
                    - population[r5]
                )
            else:  # current-to-rand/1
                r1, r2, r3 = chosen[:3]
                mutant = population[target] + f * (
                    population[r1] - population[target] + population[r2] - population[r3]
                )
            mutant = reflect(mutant, lower, upper)
            mask = rng.random(dimension) < crossover_probability
            mask[int(rng.integers(dimension))] = True
            trial = np.where(mask, mutant, population[target])
            trial_value = evaluator.evaluate(trial)
            if trial_value < best_value:
                best_value, best_solution = trial_value, trial.copy()
            trajectory.append((evaluator.count, best_value))
            if trial_value <= values[target]:
                next_population[target], next_values[target] = trial, trial_value
            if trial_value < values[target]:
                survivals[operator] += 1

        population, values = next_population, next_values
        immediate = survivals.astype(np.float64) / population_size
        rewards = 0.5 * rewards + immediate
        transition = probabilities[:, None] + probabilities[None, :]
        system = np.eye(operator_count) - discount_rate * transition
        try:
            quality = np.linalg.solve(system, rewards)
        except np.linalg.LinAlgError:
            quality = rewards.copy()
        quality -= np.max(quality)
        softmax = np.exp(np.clip(quality, -700.0, 0.0))
        softmax /= softmax.sum()
        probabilities = minimum_probability + (1.0 - operator_count * minimum_probability) * softmax
        probabilities /= probabilities.sum()
        generations += 1

    return PilotResult(
        best_solution,
        float(best_value),
        evaluator.count,
        perf_counter() - start,
        "evaluation_budget_exhausted",
        trajectory,
        {
            "strategy": "DE-RecPM-AOS four mutation strategies",
            "implementation": "independent from Sharma et al. equations",
            "population_size": population_size,
            "F": differential_weight,
            "CR": crossover_probability,
            "p_min": minimum_probability,
            "gamma": discount_rate,
            "reward": "offspring survival rate with 0.5 reward decay",
            "operators": ["rand/1", "rand/2", "rand-to-best/2", "current-to-rand/1"],
            "boundary": "reflection",
            "generations": generations,
            "final_operator_probabilities": probabilities.tolist(),
            "operator_applications_last_generation": applications.tolist(),
        },
    )


def cma_es(
    objective: Objective,
    lower: FloatArray,
    upper: FloatArray,
    budget: int,
    seed: int,
    *,
    population_size: int = 20,
) -> PilotResult:
    """Run pycma with deterministic restarts and an exact evaluation budget."""
    try:
        import cma
    except ImportError as error:  # pragma: no cover - optional environment gate
        raise RuntimeError("CMA-ES pilot requires cma==4.4.4") from error
    if budget < population_size:
        raise ValueError("CMA-ES budget must cover one full generation")
    start = perf_counter()
    evaluator = EvaluationBudget(objective, budget)
    midpoint = (lower + upper) / 2.0
    sigma = 0.3 * float(np.mean(upper - lower))

    def new_strategy(mean: FloatArray, restart: int):
        restart_seed = int((seed + 104729 * restart) % (2**31 - 1)) or 1
        return cma.CMAEvolutionStrategy(
            mean,
            sigma,
            {
                "bounds": [lower.tolist(), upper.tolist()],
                "popsize": population_size,
                "seed": restart_seed,
                "verbose": -9,
                "verb_log": 0,
            },
        )

    strategy = new_strategy(midpoint, 0)
    trajectory: list[tuple[int, float]] = []
    best_value = np.inf
    best_solution = midpoint.copy()
    partial_final = 0
    restarts = 0
    restart_reasons = {"stop": 0, "numerical_failure": 0}
    while evaluator.remaining:
        if strategy.stop():
            restarts += 1
            restart_reasons["stop"] += 1
            strategy = new_strategy(best_solution, restarts)
        count = min(population_size, evaluator.remaining)
        try:
            candidates = [np.asarray(row, dtype=np.float64) for row in strategy.ask(count)]
        except (AssertionError, FloatingPointError, np.linalg.LinAlgError):
            restarts += 1
            restart_reasons["numerical_failure"] += 1
            if restarts > 1000:
                raise RuntimeError("CMA-ES exceeded 1000 deterministic restarts") from None
            strategy = new_strategy(best_solution, restarts)
            continue
        values: list[float] = []
        for candidate in candidates:
            value = evaluator.evaluate(candidate)
            values.append(value)
            if value < best_value:
                best_value, best_solution = value, candidate.copy()
            trajectory.append((evaluator.count, best_value))
        if count == population_size:
            strategy.tell(candidates, values)
        else:
            partial_final = count
    return PilotResult(
        best_solution,
        float(best_value),
        evaluator.count,
        perf_counter() - start,
        "evaluation_budget_exhausted",
        trajectory,
        {
            "library": "cma 4.4.4",
            "population_size": population_size,
            "initial_mean": "box midpoint",
            "initial_sigma": sigma,
            "boundary": "pycma BoundTransform",
            "partial_final_generation_evaluated_without_tell": partial_final,
            "restart_policy": "deterministic restart on pycma stop or numerical sampler failure",
            "restarts": restarts,
            "restart_reasons": restart_reasons,
        },
    )


def cma_es_inhouse(
    objective: Objective,
    lower: FloatArray,
    upper: FloatArray,
    budget: int,
    seed: int,
    *,
    population_size: int = 20,
) -> PilotResult:
    """Transparent rank-mu CMA-ES reference implemented inside this project.

    This deliberately compact reference is used to audit whether conclusions depend
    on the mature pycma implementation.  It uses the canonical cumulative step-size
    and rank-one/rank-mu covariance updates, reflected box constraints, no restart,
    and the same exact-budget gateway as every other in-house method.
    """
    dimension = int(lower.size)
    if population_size < 4 or budget < population_size:
        raise ValueError("CMA-ES requires population >=4 and budget covering initialization")
    start = perf_counter()
    rng = np.random.default_rng(seed)
    evaluator = EvaluationBudget(objective, budget)
    mean = (lower + upper) / 2.0
    sigma = 0.3 * float(np.mean(upper - lower))
    mu = population_size // 2
    weights = np.log(mu + 0.5) - np.log(np.arange(1, mu + 1, dtype=np.float64))
    weights /= weights.sum()
    mu_eff = float(1.0 / np.sum(weights**2))
    c_c = float((4.0 + mu_eff / dimension) / (dimension + 4.0 + 2.0 * mu_eff / dimension))
    c_s = float((mu_eff + 2.0) / (dimension + mu_eff + 5.0))
    c_1 = float(2.0 / ((dimension + 1.3) ** 2 + mu_eff))
    c_mu = float(
        min(
            1.0 - c_1,
            2.0 * (mu_eff - 2.0 + 1.0 / mu_eff) / ((dimension + 2.0) ** 2 + mu_eff),
        )
    )
    damping = float(
        1.0 + 2.0 * max(0.0, np.sqrt((mu_eff - 1.0) / (dimension + 1.0)) - 1.0) + c_s
    )
    expected_norm = float(
        np.sqrt(dimension) * (1.0 - 1.0 / (4.0 * dimension) + 1.0 / (21.0 * dimension**2))
    )
    covariance = np.eye(dimension)
    eigenvectors = np.eye(dimension)
    scales = np.ones(dimension)
    inverse_sqrt = np.eye(dimension)
    path_covariance = np.zeros(dimension)
    path_sigma = np.zeros(dimension)
    trajectory: list[tuple[int, float]] = []
    best_value = np.inf
    best_solution = mean.copy()
    generations = 0
    partial_final = 0

    while evaluator.remaining:
        count = min(population_size, evaluator.remaining)
        normal = rng.normal(size=(count, dimension))
        steps = normal @ (eigenvectors * scales).T
        candidates = reflect(mean + sigma * steps, lower, upper)
        values = np.empty(count, dtype=np.float64)
        for index, candidate in enumerate(candidates):
            value = evaluator.evaluate(candidate)
            values[index] = value
            if value < best_value:
                best_value, best_solution = value, candidate.copy()
            trajectory.append((evaluator.count, best_value))
        if count < population_size:
            partial_final = count
            break

        order = np.argsort(values)
        selected = candidates[order[:mu]]
        old_mean = mean.copy()
        mean = np.sum(weights[:, None] * selected, axis=0)
        selected_steps = (selected - old_mean) / sigma
        weighted_step = np.sum(weights[:, None] * selected_steps, axis=0)
        path_sigma = (1.0 - c_s) * path_sigma + np.sqrt(
            c_s * (2.0 - c_s) * mu_eff
        ) * (inverse_sqrt @ weighted_step)
        normalization = np.sqrt(1.0 - (1.0 - c_s) ** (2.0 * (generations + 1)))
        h_sigma = float(
            np.linalg.norm(path_sigma) / max(normalization, np.finfo(float).tiny)
            < (1.4 + 2.0 / (dimension + 1.0)) * expected_norm
        )
        path_covariance = (1.0 - c_c) * path_covariance + h_sigma * np.sqrt(
            c_c * (2.0 - c_c) * mu_eff
        ) * weighted_step
        rank_mu = sum(
            weight * np.outer(step, step)
            for weight, step in zip(weights, selected_steps, strict=True)
        )
        covariance = (
            (1.0 - c_1 - c_mu) * covariance
            + c_1
            * (
                np.outer(path_covariance, path_covariance)
                + (1.0 - h_sigma) * c_c * (2.0 - c_c) * covariance
            )
            + c_mu * rank_mu
        )
        covariance = (covariance + covariance.T) / 2.0
        eigenvalues, eigenvectors = np.linalg.eigh(covariance)
        eigenvalues = np.maximum(eigenvalues, 1e-30)
        scales = np.sqrt(eigenvalues)
        inverse_sqrt = (eigenvectors * (1.0 / scales)) @ eigenvectors.T
        log_sigma = np.log(sigma) + (c_s / damping) * (
            np.linalg.norm(path_sigma) / expected_norm - 1.0
        )
        sigma = float(np.exp(np.clip(log_sigma, np.log(1e-14), np.log(1e14))))
        generations += 1

    return PilotResult(
        best_solution,
        float(best_value),
        evaluator.count,
        perf_counter() - start,
        "evaluation_budget_exhausted",
        trajectory,
        {
            "implementation": "transparent in-house canonical rank-mu CMA-ES",
            "population_size": population_size,
            "parents": mu,
            "initial_mean": "box midpoint",
            "initial_sigma": 0.3 * float(np.mean(upper - lower)),
            "boundary": "reflection",
            "restart_policy": "none",
            "generations_updated": generations,
            "partial_final_generation_evaluated_without_update": partial_final,
        },
    )


def _summarize_sdpo_diagnostics(rows: list[dict[str, object]]) -> dict[str, object]:
    """Aggregate degradation activation and success without storing huge row logs."""
    decisions = len(rows)
    if decisions == 0:
        return {"decision_count": 0}
    degradation = [row for row in rows if row["operator"] == "D"]
    eligible = sum(bool(row["degradation_eligible"]) for row in rows)
    gate_fallbacks = sum(bool(row["degradation_gate_fallback"]) for row in rows)
    post_initial_evaluations = sum(int(row["operator_evaluations"]) for row in rows)
    degradation_evaluations = sum(int(row["operator_evaluations"]) for row in degradation)
    degradation_accepted = sum(bool(row["accepted"]) for row in degradation)
    degradation_strict = sum(bool(row["strict_improvement"]) for row in degradation)
    selected = len(degradation)
    return {
        "decision_count": decisions,
        "chronic_set_membership_count": eligible,
        "chronic_set_membership_rate": eligible / decisions,
        "degradation_selected_count": selected,
        "degradation_selection_rate": selected / decisions,
        "degradation_evaluations": degradation_evaluations,
        "post_initialization_evaluations": post_initial_evaluations,
        "degradation_evaluation_fraction": degradation_evaluations
        / post_initial_evaluations,
        "degradation_accepted_count": degradation_accepted,
        "degradation_accepted_rate": degradation_accepted / selected if selected else 0.0,
        "degradation_strict_success_count": degradation_strict,
        "degradation_strict_success_rate": degradation_strict / selected if selected else 0.0,
        "degradation_gate_fallback_count": gate_fallbacks,
        "degradation_gate_fallback_rate": gate_fallbacks / decisions,
        "mean_unmasked_probability_D": float(
            np.mean([float(row["probability_D"]) for row in rows])
        ),
    }


def sdpo_configured(
    objective: Objective,
    lower: FloatArray,
    upper: FloatArray,
    budget: int,
    seed: int,
    *,
    population_size: int = 20,
    config_overrides: dict[str, object] | None = None,
    include_diagnostics_summary: bool = False,
) -> PilotResult:
    """Run SDPO with audited, serializable overrides for additional experiments."""
    base = SDPOConfig(
        population_size=population_size,
        evaluation_budget=budget,
        seed=seed,
        graph_k=min(4, population_size - 1),
        neighbor_backend="ckdtree",
    )
    locked = {"population_size", "evaluation_budget", "seed"}
    allowed = {item.name for item in fields(SDPOConfig)} - locked
    overrides = dict(config_overrides or {})
    unknown = set(overrides) - allowed
    if unknown:
        raise ValueError(f"unknown or locked SDPO config overrides: {sorted(unknown)}")
    if "stress_weights" in overrides:
        overrides["stress_weights"] = tuple(overrides["stress_weights"])
    values = {item.name: getattr(base, item.name) for item in fields(SDPOConfig)}
    values.update(overrides)
    result = optimize(objective, lower, upper, SDPOConfig(**values))
    parameters = dict(result.config)
    parameters["config_overrides"] = overrides
    if include_diagnostics_summary:
        parameters["diagnostics_summary"] = _summarize_sdpo_diagnostics(result.diagnostics)
    return PilotResult(
        result.best_solution,
        result.best_objective,
        result.evaluations,
        result.elapsed_seconds,
        result.termination_reason,
        [(point.evaluations, point.best_objective) for point in result.trajectory],
        parameters,
    )


def sdpo_full(
    objective: Objective,
    lower: FloatArray,
    upper: FloatArray,
    budget: int,
    seed: int,
    *,
    population_size: int = 20,
) -> PilotResult:
    result = optimize(
        objective,
        lower,
        upper,
        SDPOConfig(
            population_size=population_size,
            evaluation_budget=budget,
            seed=seed,
            graph_k=min(4, population_size - 1),
            neighbor_backend="ckdtree",
        ),
    )
    return PilotResult(
        result.best_solution,
        result.best_objective,
        result.evaluations,
        result.elapsed_seconds,
        result.termination_reason,
        [(point.evaluations, point.best_objective) for point in result.trajectory],
        result.config,
    )


def sdpo_revised(
    objective: Objective,
    lower: FloatArray,
    upper: FloatArray,
    budget: int,
    seed: int,
    *,
    population_size: int = 20,
) -> PilotResult:
    """Frozen R1 redesign derived before untouched external validation.

    R1 removes the empirically adverse degradation and rank-stress components
    and shrinks the adaptive portfolio probabilities 75% toward uniform. The
    successful-step archive, stagnation/crowding state, graph diffusion, and
    evaluation-normalized credit remain active.
    """
    result = optimize(
        objective,
        lower,
        upper,
        SDPOConfig(
            population_size=population_size,
            evaluation_budget=budget,
            seed=seed,
            stress_weights=(0.0, 0.5, 0.5),
            graph_k=min(4, population_size - 1),
            neighbor_backend="ckdtree",
            policy_adaptive_weight=0.25,
            degradation_stress_threshold=1.0,
        ),
    )
    parameters = dict(result.config)
    parameters["revision"] = "R1 frozen before untouched external validation"
    return PilotResult(
        result.best_solution,
        result.best_objective,
        result.evaluations,
        result.elapsed_seconds,
        result.termination_reason,
        [(point.evaluations, point.best_objective) for point in result.trajectory],
        parameters,
    )


def sdpo_ablation(
    objective: Objective,
    lower: FloatArray,
    upper: FloatArray,
    budget: int,
    seed: int,
    *,
    variant: str,
    population_size: int = 20,
) -> PilotResult:
    """Run a frozen one-factor SDPO ablation with otherwise identical defaults."""
    base = SDPOConfig(
        population_size=population_size,
        evaluation_budget=budget,
        seed=seed,
        graph_k=min(4, population_size - 1),
        neighbor_backend="ckdtree",
    )
    result = optimize(objective, lower, upper, ablation_config(base, variant))
    parameters = dict(result.config)
    parameters["ablation_variant"] = variant
    return PilotResult(
        result.best_solution,
        result.best_objective,
        result.evaluations,
        result.elapsed_seconds,
        result.termination_reason,
        [(point.evaluations, point.best_objective) for point in result.trajectory],
        parameters,
    )
