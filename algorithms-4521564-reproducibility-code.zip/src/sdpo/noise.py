"""Controlled observation-noise models for reproducible robustness experiments."""

from __future__ import annotations

from collections.abc import Callable

import numpy as np

from .core import FloatArray


class RelativeLognormalNoise:
    """Apply independent multiplicative noise to nonnegative objective error.

    For true objective ``f`` and known optimum value ``f_opt``, the observed value is
    ``f_opt + max(f-f_opt, 0) * exp(sigma Z)``, with ``Z`` standard normal.  A common
    seed gives algorithms the same noise sequence by evaluation index while a separate
    noiseless shadow evaluation can assess the returned solution.
    """

    def __init__(
        self,
        objective: Callable[[FloatArray], float],
        reference_fopt: float,
        sigma: float,
        seed: int,
    ) -> None:
        if not np.isfinite(reference_fopt):
            raise ValueError("reference optimum must be finite")
        if not np.isfinite(sigma) or sigma < 0.0:
            raise ValueError("noise sigma must be finite and nonnegative")
        self.objective = objective
        self.reference_fopt = float(reference_fopt)
        self.sigma = float(sigma)
        self.seed = int(seed)
        self.rng = np.random.default_rng(seed)
        self.calls = 0

    def __call__(self, candidate: FloatArray) -> float:
        true_value = float(self.objective(candidate))
        error = max(true_value - self.reference_fopt, 0.0)
        observed = self.reference_fopt + error * float(
            np.exp(self.sigma * self.rng.normal())
        )
        self.calls += 1
        return observed
