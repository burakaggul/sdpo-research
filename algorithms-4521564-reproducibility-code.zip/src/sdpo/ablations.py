"""Frozen, one-factor SDPO ablations used by the secondary mechanism study."""

from __future__ import annotations

from dataclasses import replace

from .core import SDPOConfig

ABLATION_VARIANTS = (
    "no_diff",
    "no_credit",
    "isotropic",
    "no_degradation",
    "random_policy",
    "no_stagnation",
    "no_crowding",
    "no_rank_stress",
    "uniform_restart",
    "isotropic_no_degradation",
    "no_rank_no_crowding",
)


def ablation_config(base: SDPOConfig, variant: str) -> SDPOConfig:
    """Return the frozen one-factor modification of ``base``.

    Zeroing one raw-stress component renormalizes the remaining default weights so
    raw stress stays a convex combination. The isotropic variant forces the existing
    insufficient-archive branch instead of introducing a fourth proposal operator.
    """
    if variant == "no_diff":
        return replace(base, diffusion_rho=0.0)
    if variant == "no_credit":
        return replace(base, eta=0.0)
    if variant == "isotropic":
        return replace(base, archive_min_steps=base.archive_max_steps + 1)
    if variant == "no_degradation":
        return replace(base, degradation_stress_threshold=1.0)
    if variant == "random_policy":
        return replace(base, eta=0.0, beta=0.0)
    if variant == "no_stagnation":
        return replace(base, stress_weights=(4.0 / 7.0, 0.0, 3.0 / 7.0))
    if variant == "no_crowding":
        return replace(base, stress_weights=(4.0 / 7.0, 3.0 / 7.0, 0.0))
    if variant == "no_rank_stress":
        return replace(base, stress_weights=(0.0, 0.5, 0.5))
    if variant == "uniform_restart":
        return replace(base, uniform_restart_weight=1.0)
    if variant == "isotropic_no_degradation":
        return replace(
            base,
            archive_min_steps=base.archive_max_steps + 1,
            degradation_stress_threshold=1.0,
        )
    if variant == "no_rank_no_crowding":
        return replace(base, stress_weights=(0.0, 1.0, 0.0))
    raise ValueError(f"unknown SDPO ablation variant: {variant}")
