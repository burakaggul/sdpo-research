"""Thin accounting adapters around externally sourced benchmark frameworks."""

from __future__ import annotations

import importlib.util
import os
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory
from types import ModuleType
from typing import Any

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]

CEC2022_BIASES = {
    1: 300.0,
    2: 400.0,
    3: 600.0,
    4: 800.0,
    5: 900.0,
    6: 1800.0,
    7: 2000.0,
    8: 2200.0,
    9: 2300.0,
    10: 2400.0,
    11: 2600.0,
    12: 2700.0,
}


@contextmanager
def _working_directory(path: Path) -> Iterator[None]:
    previous = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(previous)


class CocoBbobAdapter:
    """A public-call wrapper that cross-checks COCO's native evaluation counter."""

    def __init__(
        self,
        function: int,
        dimension: int,
        instance: int = 1,
        *,
        suite_name: str = "bbob",
    ) -> None:
        try:
            import cocoex
        except ImportError as error:  # pragma: no cover - optional environment gate
            raise RuntimeError(
                "COCO requires coco-experiment; use the documented Python 3.12 environment"
            ) from error
        if suite_name not in {"bbob", "bbob-largescale", "bbob-noisy"}:
            raise ValueError(
                "supported COCO suites are bbob, bbob-largescale, and bbob-noisy"
            )
        self.suite_name = suite_name
        function_index = function - 100 if suite_name == "bbob-noisy" else function
        self._suite = cocoex.Suite(
            suite_name,
            f"instances: {instance}",
            f"dimensions: {dimension} function_indices: {function_index}",
        )
        self.problem = self._suite.get_problem_by_function_dimension_instance(
            function, dimension, instance
        )
        self.calls = 0
        self.function = function
        self.dimension = dimension
        self.instance = instance
        self.lower = np.asarray(self.problem.lower_bounds, dtype=np.float64)
        self.upper = np.asarray(self.problem.upper_bounds, dtype=np.float64)
        self.identifier = str(self.problem.id)

    def __call__(self, candidate: FloatArray) -> float:
        before = int(self.problem.evaluations)
        value = float(self.problem(np.asarray(candidate, dtype=np.float64)))
        after = int(self.problem.evaluations)
        if after != before + 1:
            raise RuntimeError("COCO native evaluation counter did not advance by exactly one")
        self.calls += 1
        if self.calls != after:
            raise RuntimeError("adapter and COCO native evaluation counters diverged")
        return value

    @property
    def native_evaluations(self) -> int:
        return int(self.problem.evaluations)

    def close(self) -> None:
        self.problem.free()
        self._suite.free()

    @staticmethod
    def reference_fopt(
        function: int,
        dimension: int,
        instance: int = 1,
        *,
        suite_name: str = "bbob",
    ) -> float:
        """Obtain fopt from COCO's diagnostic optimum export on a separate problem.

        COCO 2.8.2 does not expose fopt through a documented public Python property.
        The private export is therefore isolated in a temporary directory and never
        charged to an algorithm run. This method is an audit workaround, not a stable API.
        """
        reference = CocoBbobAdapter(function, dimension, instance, suite_name=suite_name)
        try:
            with TemporaryDirectory(prefix="sdpo-coco-fopt-") as temporary:
                with _working_directory(Path(temporary)):
                    reference.problem._best_parameter("print")
                    optimum = np.loadtxt("._bbob_problem_best_parameter.txt")
            return reference(optimum)
        finally:
            reference.close()


class CEC2022Adapter:
    """Local adapter for the organizers' unmodified Python archive.

    The source is not vendored because its repository has no explicit license. The
    adapter calls ``cec22_test_func`` directly because the archive's convenience class
    relies on deprecated array-to-scalar conversion and fails with NumPy 2.x.
    """

    def __init__(self, source_root: Path, function: int, dimension: int) -> None:
        self.source_root = Path(source_root).resolve()
        source = self.source_root / "CEC2022.py"
        data = self.source_root / "input_data"
        if not source.is_file() or not data.is_dir():
            raise FileNotFoundError("CEC 2022 source root must contain CEC2022.py and input_data/")
        if function not in CEC2022_BIASES or dimension not in {2, 10, 20}:
            raise ValueError("official Python archive supports functions 1..12 and D=2,10,20")
        specification = importlib.util.spec_from_file_location("sdpo_external_cec2022", source)
        if specification is None or specification.loader is None:
            raise ImportError(f"cannot load official CEC 2022 source from {source}")
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        self._module: ModuleType = module
        self.function = function
        self.dimension = dimension
        self.lower = np.full(dimension, -100.0)
        self.upper = np.full(dimension, 100.0)
        self.calls = 0
        self.identifier = f"cec2022_f{function:02d}_d{dimension}"

    def __call__(self, candidate: FloatArray) -> float:
        x = np.asarray(candidate, dtype=np.float64)
        if x.shape != (self.dimension,):
            raise ValueError(f"CEC 2022 candidate must have shape ({self.dimension},)")
        with _working_directory(self.source_root):
            values: Any = self._module.cec22_test_func(x, self.dimension, 1, self.function)
        value = float(np.asarray(values).reshape(-1)[0])
        self.calls += 1
        if not np.isfinite(value):
            raise FloatingPointError("CEC 2022 returned a non-finite value")
        return value

    @property
    def bias(self) -> float:
        return CEC2022_BIASES[self.function]
